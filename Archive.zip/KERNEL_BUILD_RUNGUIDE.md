# Jetson Kernel Build Monitoring & Troubleshooting Guide

## 🔍 Monitoring Build Progress

### 1. Find Current Build Directory
The build creates timestamped directories. Find the active one:

```bash
# Find newest build directory
ssh nanos2 "ls -lart /home/ansible/jetson-nvgpu-* | tail -1"

# Find directories created in last hour
ssh nanos2 "find /home/ansible -name 'jetson-nvgpu-*' -newermt '1 hour ago' -type d"

# Current active build (example)
BUILD_DIR="/home/ansible/jetson-nvgpu-20250810T171905"
```

### 2. Monitor Live Build Progress

#### **Primary Method: Tail Build Log**
```bash
# Real-time build output
ssh nanos2 "tail -f $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log"

# Last 50 lines of build log
ssh nanos2 "tail -50 $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log"

# Search for specific patterns (errors, warnings)
ssh nanos2 "tail -100 $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log | grep -i error"
```

#### **Check Build Process Status**
```bash
# Check if build process is still running
ssh nanos2 "ps aux | grep make | grep -v grep"

# Check PID file and process
ssh nanos2 "cat $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.pid 2>/dev/null"
ssh nanos2 "ps -p \$(cat $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.pid 2>/dev/null) 2>/dev/null"

# Check build completion marker
ssh nanos2 "ls -la $BUILD_DIR/Linux_for_Tegra/source/build/.build_done 2>/dev/null"
```

#### **Progress Estimation**
```bash
# Check if kernel Image is built (final stage)
ssh nanos2 "ls -la $BUILD_DIR/Linux_for_Tegra/source/build/arch/arm64/boot/Image"

# Count compiled object files (rough progress indicator)
ssh nanos2 "find $BUILD_DIR/Linux_for_Tegra/source/build -name '*.o' | wc -l"

# Check build directory size (grows during compilation)
ssh nanos2 "du -sh $BUILD_DIR/Linux_for_Tegra/source/build"
```

### 3. System Resource Monitoring
```bash
# CPU and memory usage during build
ssh nanos2 "top -b -n1 | head -20"

# Check thermal throttling (important for Jetson)
ssh nanos2 "cat /sys/class/thermal/thermal_zone*/temp"

# Check available disk space
ssh nanos2 "df -h /home/ansible"
```

## 🛠️ Ansible Command Reference

### Basic Playbook Commands

#### **Start Fresh Build**
```bash
# Complete build from scratch
ansible-playbook playbooks/site.yml -l jetson1 --ask-become-pass

# Build with specific strategy
ansible-playbook playbooks/site.yml -l jetson1 --extra-vars "install_strategy=byok" --ask-become-pass

# Skip installation phase
ansible-playbook playbooks/site.yml -l jetson1 --extra-vars "skip_install=true" --ask-become-pass
```

#### **Resume/Retry Commands**
```bash
# Resume from last failure point
ansible-playbook playbooks/site.yml -l jetson1 --limit @/tmp/ansible-retry/site.retry --ask-become-pass

# Resume specific phase with tags
ansible-playbook playbooks/site.yml -l jetson1 -t build,install --ask-become-pass
ansible-playbook playbooks/site.yml -l jetson1 -t config,build --ask-become-pass
ansible-playbook playbooks/site.yml -l jetson1 -t install,validate --ask-become-pass
```

#### **Tag-Based Execution**
```bash
# Available tags
# prerequisites, workspace, sources, patches, config, build, install, hwpm, netfilter, validate

# Run only configuration phase
ansible-playbook playbooks/site.yml -l jetson1 -t config --ask-become-pass

# Skip configuration, start from build
ansible-playbook playbooks/site.yml -l jetson1 --skip-tags=config --ask-become-pass

# Only install and validate
ansible-playbook playbooks/site.yml -l jetson1 -t install,validate --ask-become-pass

# Run validation only
ansible-playbook playbooks/site.yml -l jetson1 -t validate --ask-become-pass
```

### Debugging and Verbose Output

#### **Verbose Execution**
```bash
# Standard verbose
ansible-playbook playbooks/site.yml -l jetson1 -v --ask-become-pass

# Very verbose (shows task details)
ansible-playbook playbooks/site.yml -l jetson1 -vv --ask-become-pass

# Maximum verbosity (debug level)
ansible-playbook playbooks/site.yml -l jetson1 -vvv --ask-become-pass
```

#### **Syntax and Dry-Run Checks**
```bash
# Check playbook syntax
ansible-playbook --syntax-check playbooks/site.yml

# Dry run (what would be done)
ansible-playbook playbooks/site.yml -l jetson1 --check --ask-become-pass

# List tasks that would run
ansible-playbook playbooks/site.yml -l jetson1 --list-tasks
```

## 🔧 Troubleshooting Common Issues

### Build Failures

#### **Build Timeout (240+ retries exceeded)**
```bash
# Check if build is actually still running
ssh nanos2 "ps aux | grep make | grep -v grep"

# Increase timeout in 06_build.yml: retries: 360 (3 hours)
# Or resume with current state:
ansible-playbook playbooks/site.yml -l jetson1 -t build --ask-become-pass
```

#### **Config Merge Failures**
```bash
# Check config fragment files exist
ssh nanos2 "ls -la $BUILD_DIR/files01/kconfig/40-k8s-hardening.cfg"
ssh nanos2 "ls -la $BUILD_DIR/*-k8s-*.cfg"

# Check kernel.release mismatch
ssh nanos2 "cat $BUILD_DIR/Linux_for_Tegra/source/build/include/config/kernel.release | od -c"

# Manual config verification
ssh nanos2 "cd $BUILD_DIR/Linux_for_Tegra/source/build && grep CONFIG_NETFILTER .config"
```

#### **Compilation Errors**
```bash
# Search for compilation errors
ssh nanos2 "grep -i 'error:' $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log | tail -10"

# Check for missing dependencies
ssh nanos2 "grep -i 'no such file' $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log"

# Look for make errors
ssh nanos2 "grep 'make.*Error' $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log"
```

### Resume Strategies

#### **Manual Build Resume**
```bash
# Check build completion markers
ssh nanos2 "ls -la $BUILD_DIR/Linux_for_Tegra/source/build/.build_done"

# If build completed but Ansible failed, just do install:
ansible-playbook playbooks/site.yml -l jetson1 -t install,validate --ask-become-pass

# Resume from specific failure point
ansible-playbook playbooks/site.yml -l jetson1 --limit @/tmp/ansible-retry/site.retry --ask-become-pass
```

#### **Clean Restart Options**
```bash
# Keep sources, rebuild from config phase
ssh nanos2 "rm -rf $BUILD_DIR/Linux_for_Tegra/source/build/.build_done $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.pid"
ansible-playbook playbooks/site.yml -l jetson1 -t config,build,install --ask-become-pass

# Complete clean restart (removes everything)
ssh nanos2 "rm -rf /home/ansible/jetson-nvgpu-$(date +%Y%m%d)*"
ansible-playbook playbooks/site.yml -l jetson1 --ask-become-pass
```

### Installation Issues

#### **BYOK Installation Problems**
```bash
# Check kernel SHA256 verification
ssh nanos2 "sudo sha256sum /boot/5.15.148-tegra"
ssh nanos2 "sudo cat /boot/.byok-kernel-sha256"

# Manual BYOK marker creation
EXPECTED_SHA="7be6e5de0ac9b8b3a1abb3b90e6c2a4b77b7b1403cb1d1f7d7e9b6d5bf378a01"
ssh nanos2 "sudo sh -c 'echo \"$EXPECTED_SHA\" > /boot/.byok-kernel-sha256'"

# Check /boot space
ssh nanos2 "df -h /boot"
```

#### **Module Installation Issues**
```bash
# Check modules directory
ssh nanos2 "ls -la /lib/modules/5.15.148-tegra/"

# Verify depmod worked
ssh nanos2 "ls -la /lib/modules/5.15.148-tegra/modules.dep"

# Manual module install and depmod
ssh nanos2 "cd $BUILD_DIR/Linux_for_Tegra/source/build && sudo make modules_install && sudo depmod -a"
```

## 📊 Build Progress Indicators

### Phase Completion Checklist

#### **Phase 1: Setup & Sources (5-10 minutes)**
- [ ] Archives extracted to workspace
- [ ] Kernel sources synced
- [ ] Patches applied
- [ ] Config fragments merged

#### **Phase 2: Compilation (90-120 minutes)**  
- [ ] Build process started (PID file created)
- [ ] Core kernel compiling (mm/, fs/, kernel/)
- [ ] Device drivers compiling (drivers/)
- [ ] Modules linking (*.ko files)
- [ ] Final Image created

#### **Phase 3: Installation (2-5 minutes)**
- [ ] Modules installed to /lib/modules/
- [ ] Kernel Image copied to /boot/
- [ ] Initrd updated
- [ ] BYOK marker created

### Time Estimates by Hardware
- **Jetson Orin Nano 8GB**: ~2-3 hours total
- **Jetson AGX Orin**: ~1.5-2 hours total  
- **Jetson Xavier NX**: ~3-4 hours total

### Build Log Patterns to Watch For

#### **Normal Progress Indicators**
```
CC      drivers/net/ethernet/...     # Network drivers
CC [M]  net/netfilter/...           # Your K8s networking features
AR      net/built-in.a              # Archive creation
LD      vmlinux                     # Final kernel linking
```

#### **Warning Signs**
```
make: *** [target] Error 2          # Compilation failure
fatal error: file not found         # Missing dependencies
warning: function defined but not used  # Usually OK, just warnings
```

#### **Success Indicators**
```
Kernel: arch/arm64/boot/Image is ready   # Build complete
INSTALL_MOD_PATH=... modules_install     # Module installation
depmod -a                                # Module dependencies updated
```

## 🚨 Emergency Commands

### Stop Runaway Build
```bash
# Kill build process
ssh nanos2 "pkill -f 'make.*Image.*modules'"

# Kill by PID
ssh nanos2 "kill -9 \$(cat $BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.pid 2>/dev/null)"
```

### Disk Space Emergency  
```bash
# Clean old build directories (keep newest 2)
ssh nanos2 "ls -dt /home/ansible/jetson-nvgpu-* | tail -n +3 | xargs rm -rf"

# Clean build temp files
ssh nanos2 "find $BUILD_DIR -name '*.o' -delete"
```

### Quick Validation After Build
```bash
# Verify new kernel installed
ssh nanos2 "uname -r && sudo sha256sum /boot/5.15.148-tegra"

# Check K8s networking features
ssh nanos2 "grep CONFIG_NETFILTER_XT_MATCH_OWNER /boot/config-5.15.148-tegra"
ssh nanos2 "grep CONFIG_IP_VS /boot/config-5.15.148-tegra"

# Test bridge netfilter
ssh nanos2 "ls -la /proc/sys/net/bridge/bridge-nf-call-iptables"
```

---

## 📁 Current Build Directory Structure
```
/home/ansible/jetson-nvgpu-YYYYMMDDTHHMMSS/
├── Linux_for_Tegra/source/
│   ├── build/                      # Main build directory
│   │   ├── kernel_build.log        # 🔍 PRIMARY MONITORING FILE
│   │   ├── kernel_build.pid        # Build process PID
│   │   ├── .build_done             # Completion marker
│   │   ├── arch/arm64/boot/Image   # Final kernel binary
│   │   └── .config                 # Merged kernel configuration
│   └── kernel-jammy-src/           # Kernel source code
└── files01/
    └── kconfig/
        └── 40-k8s-hardening.cfg    # Your K8s networking configs
```

**Key Monitoring File:** `$BUILD_DIR/Linux_for_Tegra/source/build/kernel_build.log`