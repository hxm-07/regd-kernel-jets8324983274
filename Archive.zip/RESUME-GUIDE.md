# Jetson Kernel Build Resume Guide

## Resume Mechanism

The kernel build now supports intelligent resume after failures:

### 1. Resume-Friendly Workspace
- **Default**: Timestamped workspace (`jetson-nvgpu-20250809T123456`)
- **Resume Mode**: Static workspace (`jetson-nvgpu-resume`)

### 2. Usage

**For new builds:**
```bash
ansible-playbook playbooks/build-kernel.yml --ask-become-pass
```

**For resuming failed builds:**
```bash
ansible-playbook playbooks/build-kernel-resume.yml --ask-become-pass
```

### 3. Resume Features

**Skip completed phases:**
- ✅ Archives only copied if missing
- ✅ Extraction skipped if directories exist (`creates:` parameters)
- ✅ Source sync skipped if kernel Makefile exists
- ✅ Configuration skipped if `.config` exists
- ✅ Compilation resumes from last built object files

**Resume workspace:**
```bash
# Set resume flag to use static workspace
resume_build: true  # Uses /home/ansible/jetson-nvgpu-resume
resume_build: false # Uses /home/ansible/jetson-nvgpu-TIMESTAMP (default)
```

### 4. Manual Resume

**Check existing workspaces:**
```bash
ssh ansible@nanos2 "ls -la /home/ansible/jetson-nvgpu-*"
```

**Resume from specific workspace:**
```bash
# Edit group_vars/jetsons.yml:
work_root: "/home/ansible/jetson-nvgpu-20250809T203859"  # Existing workspace
```

### 5. Progress Indicators

**Build phases that can be resumed:**
1. **Archive copying** - Skipped if files exist
2. **BSP extraction** - Skipped if `Linux_for_Tegra/` exists  
3. **Source extraction** - Skipped if `kernel-jammy-src/Makefile` exists
4. **GPU patching** - Skipped if patch marker files exist
5. **Configuration** - Skipped if `.config` exists
6. **Compilation** - Resumed from existing `.o` files
7. **Installation** - Skipped if kernel installed

### 6. Cleanup

**Remove failed workspace:**
```bash
ssh ansible@nanos2 "rm -rf /home/ansible/jetson-nvgpu-*"
```

**Reset for fresh build:**
```bash
# Remove resume workspace
ssh ansible@nanos2 "rm -rf /home/ansible/jetson-nvgpu-resume"
```