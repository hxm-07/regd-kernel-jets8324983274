# Jetson Kernel Build Situation Overview & Timeline

## Executive Summary

**Current Status**: CRITICAL NETWORK DRIVER ISSUE - Kernel builds successfully with K8s features but strips essential network drivers during config merge, resulting in no network connectivity after reboot.

**Impact**: System requires console access to recover, SSH connectivity lost, deployment pipeline broken.

**Root Cause**: `olddefconfig` command in `05_config.yml` aggressively removes network drivers when merging netfilter configuration fragments.

---

## Timeline of Events

### 🏁 **Initial State (Pre-August 2025)**
- Working jetson-edge-k8s Ansible deployment system
- Stable kernel builds with basic functionality
- Network connectivity maintained post-deployment

### 📅 **August 10-11, 2025: Critical Issue Discovery**

#### **Phase 1: Documentation Review**
- User requested comprehensive documentation update for jetson-l4t-ansible
- Found severely outdated `all.yml.bak.md` (3188 lines) with incorrect structure
- Documentation showed wrong file paths, missing tasks, corrupted YAML sections

#### **Phase 2: Kernel Build Failure**
```
PLAY [Build and Deploy Jetson L4T R36.4.4 Kernel] 
...
TASK [jetson_kernel : Validate K8s features] 
fatal: [jetson1]: FAILED! 
❌ Missing K8s features: CONFIG_NETFILTER_XTABLES=y CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y CONFIG_NETFILTER_XT_MATCH_OWNER=y CONFIG_IP_VS=y CONFIG_BRIDGE_NETFILTER=y
```

#### **Phase 3: Root Cause Analysis**
**Build Configuration Check**:
- Built kernel config (`.config`): ✅ All netfilter features enabled as `=y`
- Running kernel: ❌ Features missing or as modules `=m`
- Network drivers: ❌ Completely absent from `/lib/modules/$(uname -r)/kernel/net/`

**Kernel Version Mismatch**:
- Expected: `5.15.148-tegra` (newly built)
- Running: `5.15.148-ciliumtest` (old working kernel)
- System not rebooted after build OR network drivers missing

#### **Phase 4: Network Connectivity Lost**
**Post-Reboot State**:
- Kernel: `5.15.148-tegra` ✅ (correct)
- K8s Features: ✅ All netfilter capabilities present
- Network Interfaces: ❌ ZERO network connectivity
- Module Directory: ❌ `/lib/modules/5.15.148-tegra/kernel/net/` missing
- Recovery: ✅ Fallback to `5.15.148-ciliumtest` via console

---

## Technical Deep Dive

### 🔍 **Root Cause: olddefconfig Stripping Network Drivers**

**Location**: `roles/jetson_kernel/tasks/05_config.yml:388`
```yaml
- name: Merge config fragments
  shell: |
    set -eu
    mkdir -p "{{ kbuild }}"
    "{{ ksources }}/scripts/kconfig/merge_config.sh" -m -O "{{ kbuild }}" {{ merge_configs }}
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig  # ← PROBLEM LINE
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_prepare
```

**Config Fragments Being Merged**:
1. `/proc/config.gz` (base working kernel config)
2. `25-k8s-container-deps.cfg` (container dependencies)
3. `20-k8s-netfilter-builtins.cfg` (netfilter as built-ins)
4. `kconfig/40-k8s-hardening.cfg` (K8s hardening options)

**What Happens**:
1. ✅ Base config has network drivers: `CONFIG_RTW88=m`, `CONFIG_R8169=y`
2. ✅ Fragments add netfilter features: `CONFIG_NETFILTER_XT_MATCH_OWNER=y`
3. ❌ `olddefconfig` resolves conflicts by DISABLING network drivers
4. ✅ Build succeeds with netfilter but WITHOUT network drivers
5. ❌ System boots with K8s capabilities but NO NETWORK ACCESS

### 🔧 **Current Working Configuration**

**Target System**: Jetson Orin Nano 8GB
- **OS**: Ubuntu 22.04.5 LTS
- **Working Kernel**: `5.15.148-ciliumtest` (network ✅, some netfilter ❌)
- **Problem Kernel**: `5.15.148-tegra` (netfilter ✅, network ❌)
- **JetPack**: R36.4.4

**Network Status (when working)**:
```
enP8p1s0: 192.168.87.196/24 (Ethernet)
wlP1p1s0: 192.168.1.18/24   (WiFi)  
tailscale0: 100.107.10.3/32  (VPN)
```

**Boot Configuration**:
- **extlinux.conf**: `DEFAULT 5.15.148-tegra` (broken kernel)
- **Fallback**: Boot `ciliumtest` label for connectivity
- **Issue**: `dyndbg="module rtw88_core +p; module cfg80211 +p"` causes boot delays

---

## Solutions Analysis

### 🎯 **Option 1: Network Driver Preservation Fragment (RECOMMENDED)**
```yaml
# Create: roles/jetson_kernel/templates/kernel_config_fragments/10-essential-networking.cfg.j2
CONFIG_NET=y
CONFIG_NETDEVICES=y
CONFIG_NET_ETHERNET=y
CONFIG_R8169=y           # Realtek Ethernet
CONFIG_WLAN=y
CONFIG_RTW88=m           # Realtek WiFi
CONFIG_RTW88_CORE=m
CONFIG_RTW88_PCI=m
CONFIG_CFG80211=m        # Wireless configuration
CONFIG_MAC80211=m        # Wireless MAC layer
```

**Pros**: 
- ✅ Preserves essential drivers explicitly
- ✅ Works with existing merge strategy
- ✅ No changes to build logic

**Cons**: 
- ⚠️ Requires maintaining driver list
- ⚠️ May need updates for new hardware

### 🔄 **Option 2: Modified Config Merge Strategy**
```yaml
# Change in 05_config.yml:
make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} oldconfig < /dev/null
# Instead of:
make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig
```

**Pros**: 
- ✅ Less aggressive config resolution
- ✅ Preserves more existing config

**Cons**: 
- ❌ May prompt for user input
- ❌ Less predictable build results

### 🛡️ **Option 3: Conservative Config Base**
```yaml
# Use working kernel as base:
cp /boot/config-5.15.148-ciliumtest "{{ kbuild }}/.config"
# Instead of:
zcat /proc/config.gz > "{{ kbuild }}/.config"
```

**Pros**: 
- ✅ Guaranteed network driver compatibility
- ✅ Known working base configuration

**Cons**: 
- ❌ Less portable across different kernels
- ❌ May not include latest optimizations

---

## Impact Assessment

### 🚨 **Critical Issues**
1. **Deployment Pipeline Broken**: Cannot deploy kernels without manual console recovery
2. **Network Connectivity Lost**: SSH access requires fallback kernel boot
3. **Production Risk**: Could brick remote Jetson devices without console access
4. **K8s Cluster Impact**: Nodes would lose network connectivity after kernel upgrades

### ⚡ **Immediate Actions Required**
1. **Remove `dyndbg` boot parameter** from extlinux.conf (causes delays)
2. **Implement network driver preservation** in config fragments
3. **Test build with both netfilter AND network functionality**
4. **Update extlinux.conf default** to working kernel once fixed

### 📋 **Verification Checklist**
- [ ] Build completes successfully
- [ ] All K8s netfilter features present: `CONFIG_NETFILTER_XT_MATCH_OWNER=y`
- [ ] Network drivers preserved: `CONFIG_RTW88=m`, `CONFIG_R8169=y`
- [ ] Post-reboot network connectivity maintained
- [ ] SSH access functional
- [ ] K8s networking validation passes

---

## Documentation Status

### ✅ **Completed Fixes**
1. **File Structure**: Updated `all.yml.bak.md` with correct project structure (3188 → 2308 lines)
2. **Task Documentation**: All current task files accurately documented
3. **Template Sections**: All templates and config fragments properly documented
4. **Path Corrections**: Fixed incorrect section headers and file paths
5. **Critical Issue Documentation**: Comprehensive problem description and solutions

### 🎯 **Key Deliverables**
- ✅ Accurate jetson-l4t-ansible structure documentation
- ✅ Critical network driver issue analysis
- ✅ Three viable solution approaches
- ✅ Clear impact assessment and action plan
- ✅ Complete technical timeline and root cause analysis

---

## Next Steps

### 🔧 **Implementation Priority**
1. **IMMEDIATE**: Implement Option 1 (Network Driver Preservation Fragment)
2. **TEST**: Build and deploy on test Jetson device
3. **VALIDATE**: Confirm both network and K8s functionality
4. **DEPLOY**: Update production systems once validated

### 🔍 **Long-term Considerations**
- Monitor kernel config merge conflicts in future builds
- Consider automated network driver detection
- Implement pre-deployment validation for critical drivers
- Document recovery procedures for console-only access scenarios

---

**Status**: Documentation complete, solution ready for implementation
**Risk Level**: HIGH (network connectivity critical for remote devices)
**Estimated Fix Time**: 2-4 hours (implementation + testing)