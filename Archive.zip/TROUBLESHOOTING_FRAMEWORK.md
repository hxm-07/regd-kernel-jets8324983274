# RIGOROUS TROUBLESHOOTING FRAMEWORK
## Jetson L4T Kernel Build Automation - Fact-Checking Protocol

### 🎯 **PROBLEM DEFINITION FRAMEWORK**

#### Step 1: Evidence-Based Problem Statement
- **What exactly failed?** (specific error messages, return codes)
- **When did it fail?** (exact point in build pipeline) 
- **What was expected vs actual?** (measurable outcomes)
- **Reproducible?** (consistent failure pattern)

#### Step 2: Claim Verification Protocol
- **NEVER assume** - verify every statement with system evidence
- **SSH verification required** for all system state claims
- **Log analysis mandatory** for all failure analysis
- **File existence checks** for all path-related claims

### 🔍 **EVIDENCE COLLECTION FRAMEWORK**

#### System State Verification Checklist
```bash
# 1. MODULE STATUS VERIFICATION
lsmod | grep -E "(nvgpu|nvmap|nvsciipc|mc_utils|nvhwpm)"
find /lib/modules/$(uname -r) -name "*.ko" | grep -E "(nvgpu|nvmap|nvsciipc|mc_utils|nvhwpm)"

# 2. BUILD ARTIFACT VERIFICATION  
ls -la {{ kbuild }}/nvidia-oot/drivers/*/
ls -la {{ src_root }}/nvgpu/drivers/gpu/nvgpu/nvgpu.ko
stat -c%s {{ kbuild }}/nvidia-oot/drivers/*/*.ko

# 3. DEPENDENCY VERIFICATION
ls -la {{ kbuild }}/nvidia-oot/drivers/*/Module.symvers
ls -la {{ files01_dir }}/hwpm-Module.symvers

# 4. KERNEL HEADER VERIFICATION
ls -la {{ ksources }}/include/linux/dma-buf-map.h
find {{ ksources }} -name "dma-buf-map.h" -type f

# 5. CONFTEST VERIFICATION
ls -la {{ kbuild }}/out/nvidia-conftest/nvidia/conftest/
grep -r "dma.*buf.*map" {{ kbuild }}/out/nvidia-conftest/ || echo "NOT FOUND"
```

#### Log Analysis Requirements
```bash
# 1. ACTUAL ERROR EXTRACTION
journalctl -u ansible --since "1 hour ago" | grep -A5 -B5 "fatal error"

# 2. BUILD TIMELINE ANALYSIS
grep -E "(Building|OK:|ERROR:|FAILED)" /var/log/ansible.log

# 3. COMPILATION PROGRESS VERIFICATION  
grep -c "CC \[M\]" {{ build_logs }} # Count compiled objects
grep -E "(nvgpu|dma-buf)" {{ build_logs }} # Specific failures
```

### 🧪 **ROOT CAUSE ANALYSIS FRAMEWORK**

#### Hypothesis Testing Protocol
1. **State the hypothesis clearly**
2. **Define testable evidence requirements**  
3. **Collect evidence via SSH/system verification**
4. **Accept/reject based on evidence only**

#### Common False Assumptions to Avoid
- ❌ "Build succeeded because no error shown"
- ❌ "NVGPU compiled because task completed" 
- ❌ "Dependencies work because modules found"
- ❌ "Header missing means simple fix needed"

### 🎯 **SOLUTION VERIFICATION FRAMEWORK**

#### Solution Proof Requirements
1. **Before/After state comparison** (measurable)
2. **Repeatable test procedure** (documented steps)
3. **Success criteria definition** (specific outcomes)
4. **Failure scenario handling** (what if it doesn't work)

#### Solution Categories
- **ARCHITECTURE FIX**: Changes build system/dependencies  
- **COMPATIBILITY FIX**: Addresses KAPI/version mismatches
- **CONFIGURATION FIX**: Adjusts parameters/settings
- **WORKAROUND**: Bypasses issue without solving root cause

### 📋 **FACT-CHECKING CHECKLIST**

Before making ANY claim in documentation:
- [ ] SSH verified system state
- [ ] Log analysis completed  
- [ ] File existence confirmed
- [ ] Error messages exact quoted
- [ ] Timing/performance measured
- [ ] Dependencies actually verified
- [ ] Solution actually tested

### 🚨 **RED FLAGS - IMMEDIATE FACT-CHECK REQUIRED**
- Claims about "successful" builds without evidence
- Assumptions about module loading/functionality
- Performance claims without measurements
- Dependency claims without verification
- Any "probably" or "should" statements