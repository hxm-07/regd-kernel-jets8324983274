# Jetson L4T R36.4.4 Kernel Build Ansible Playbook Documentation
## Overview

This Ansible playbook automates the build and deployment of custom kernels for Jetson devices running L4T R36.4.4. It provides Kubernetes-ready kernels with enhanced netfilter capabilities, regulatory domain fixes, and optional GPU compute features.

**Target Platform**: Jetson Orin Nano 8GB  
**L4T Version**: R36.4.4  
**Kernel Version**: 5.15.148-tegra  
**Ubuntu Version**: 22.04 LTS  

## ACTUAL Project Structure (2025-08-11)

```
jetson-l4t-ansible/
├── ansible.cfg                                    # Ansible configuration
├── inventory/
│   ├── hosts.yml                                  # Target host definitions
│   └── group_vars/
│       └── jetsons.yml                           # Group variables for jetson hosts
├── playbooks/
│   ├── site.yml                                  # Main deployment playbook
│   ├── build-kernel.yml                          # Build-only playbook
│   ├── build-kernel-resume.yml                   # Resume interrupted builds
│   └── validate.yml                              # Validation playbook
├── roles/
│   └── jetson_kernel/
│       ├── defaults/main.yml                    # Role default variables
│       ├── handlers/main.yml                     # Event handlers
│       ├── tasks/
│       │   ├── main.yml                         # Main task orchestration
│       │   ├── 00_select_overlays.yml           # Select config overlay variants
│       │   ├── 01_prerequisites.yml             # Install build dependencies
│       │   ├── 01_artifact_install.yml          # Pre-built artifact installation
│       │   ├── 02_workspace.yml                 # Setup build workspace
│       │   ├── 03_extract_sources.yml           # Extract kernel sources
│       │   ├── 04_patches.yml                   # Apply patches and fixes
│       │   ├── 05_config.yml                    # Configure kernel ⚠️ CRITICAL ISSUE
│       │   ├── 06_build.yml                     # Build kernel
│       │   ├── 07_install.yml                   # Legacy install method
│       │   ├── 07_install_byok.yml              # BYOK atomic install (default)
│       │   ├── 08_hwpm.yml                      # Hardware Power Management
│       │   ├── 09_netfilter_modules.yml         # Build netfilter modules
│       │   ├── 10_validate.yml                  # Basic kernel validation
│       │   └── 11_k8s_validation.yml            # Kubernetes features validation
│       ├── templates/
│       │   ├── kernel_config_fragments/
│       │   │   ├── 20-k8s-netfilter-builtins.cfg.j2    # Netfilter built-ins
│       │   │   ├── 20-k8s-netfilter-modules.cfg.j2     # Netfilter modules
│       │   │   └── 25-k8s-container-deps.cfg.j2        # Container dependencies
│       │   ├── kernel-receipt.json.j2           # Installation receipt
│       │   └── dma-buf-map.h.j2                # DMA buffer mapping header
│       └── files/
│           └── README.md                        # Role documentation
├── files01/
│   ├── index.yml                                # Files index matrix
│   ├── source_sync.sh                          # Source synchronization script
│   ├── fix-regdom.sh                           # Regulatory domain fix script
│   ├── kconfig/                                # Kernel configuration fragments
│   │   ├── 20-k8s-netfilter-builtins.cfg      # Static netfilter config
│   │   ├── 25-k8s-container-deps.cfg          # Container dependencies config
│   │   ├── 40-k8s-hardening.cfg               # Kubernetes hardening options
│   │   └── nvgpu-Kconfig                       # NVGPU configuration
│   └── patches/                                # Kernel patches
│       ├── ath9k-regd.c                        # Atheros regulatory fix
│       ├── rtw88-regd.c                        # Realtek regulatory fix  
│       ├── gpu-Kconfig-patched                 # GPU Kconfig patch
│       ├── gpu-Makefile-patched                # GPU Makefile patch
│       ├── init.c.adjusted                     # Init.c adjustments
│       ├── hwpm-modified-makefile              # HWPM Makefile modifications
│       ├── hwpmanalysis.h.mod                  # HWPM analysis header
│       └── tegra-soc-hwpm-uapi.h              # HWPM UAPI header
└── jetson-build-documentation/                 # Extensive build documentation
    ├── FULL-GUIDE-COMPLETE-NVGPU-BUILD.md     # Complete build guide
    ├── TROUBLESHOOTING-CHECKLIST.md           # Troubleshooting procedures
    └── ansible-docs/                          # Ansible-specific documentation
```

## Main Playbook Files

### playbooks/site.yml
```yaml
---
- name: Build and Deploy Jetson L4T R36.4.4 Kernel
  hosts: jetsons
  become: yes
  gather_facts: yes
  serial: 1
  max_fail_percentage: 0
  
  vars_prompt:
    - name: "resume_build"
      prompt: "Resume previous build? (true/false)"
      default: "false"
      private: no
    - name: "build_hwpm"  
      prompt: "Build HWPM module? (true/false)"
      default: "true"
      private: no
    - name: "skip_reboot"
      prompt: "Skip reboot after install? (true/false)" 
      default: "false"
      private: no
  
  pre_tasks:
    - name: Verify target system
      assert:
        that:
          - ansible_architecture == "aarch64"
          - ansible_distribution == "Ubuntu"
          - ansible_distribution_version == "22.04"
        fail_msg: "This playbook requires Ubuntu 22.04 on aarch64"
    
    - name: Check current kernel version
      command: uname -r
      register: current_kernel
      changed_when: false
      
    - name: Display current kernel
      debug:
        msg: "Current kernel: {{ current_kernel.stdout }}"
  
  roles:
    - jetson_kernel
  
  post_tasks:
    - name: Final validation
      command: uname -r
      register: final_kernel
      changed_when: false
      
    - name: Verify kernel upgrade
      assert:
        that:
          - final_kernel.stdout == kernel_release_expected
        fail_msg: "Kernel version mismatch: expected {{ kernel_release_expected }}, got {{ final_kernel.stdout }}"
```

### playbooks/build-kernel.yml
```yaml
- name: Build Kernel Only (No Install)
  hosts: jetsons
  become: yes
  gather_facts: yes
  
  vars:
    skip_install: true
    skip_reboot: true
  
  roles:
    - jetson_kernel
```

### playbooks/validate.yml
```yaml
- name: Validate Jetson Kernel Build
  hosts: jetsons
  become: yes
  gather_facts: yes
  
  tasks:
    - name: Include validation tasks
      include_role:
        name: jetson_kernel
        tasks_from: 10_validate.yml
```

### roles/jetson_kernel/defaults/main.yml
```yaml
# Default variables for jetson_kernel role
work_root: "/home/{{ ansible_user }}/jetson-nvgpu-{{ ansible_date_time.iso8601_basic_short }}"
src_root: "{{ work_root }}/Linux_for_Tegra/source"
ksources: "{{ src_root }}/kernel-jammy-src"
kbuild: "{{ src_root }}/build"
arch: "arm64"
cross: "aarch64-linux-gnu-"
files01_dir: "{{ work_root }}/files01"
profile_netfilter: "builtins"
reboot_wait: 180
skip_install: false
skip_reboot: false
build_hwpm: true
enable_vxlan: false
apply_regdom_fixes: true
```

### roles/jetson_kernel/tasks/main.yml
```yaml
- name: Prerequisites
  include_tasks: 01_prerequisites.yml
  tags: [prerequisites]

- name: Artifact Mode Installation
  include_tasks: 01_artifact_install.yml
  when: not (build_on_target | bool)
  tags: [install, artifact]

- name: Setup workspace
  include_tasks: 02_workspace.yml
  when: build_on_target | bool
  tags: [workspace]

- name: Select overlay variants
  include_tasks: 00_select_overlays.yml
  when: build_on_target | bool
  tags: [select]

- name: Extract sources
  include_tasks: 03_extract_sources.yml
  when: build_on_target | bool
  tags: [sources]

- name: Apply patches
  include_tasks: 04_patches.yml
  when: build_on_target | bool
  tags: [patches]

- name: Configure kernel
  include_tasks: 05_config.yml
  when: build_on_target | bool
  tags: [config]

- name: Build kernel
  include_tasks: 06_build.yml
  when: build_on_target | bool
  tags: [build]

- name: Install kernel (BYOK atomic, no-bootloader-change)
  include_tasks: 07_install_byok.yml
  when: (build_on_target | bool) and not (skip_install | bool) and (install_strategy | default('byok')) == 'byok'
  tags: [install]

- name: Install kernel (legacy method)
  include_tasks: 07_install.yml
  when: (build_on_target | bool) and not (skip_install | bool) and (install_strategy | default('byok')) != 'byok'
  tags: [install]

- name: Build HWPM module
  include_tasks: 08_hwpm.yml
  when: (build_hwpm | default(false)) | bool
  tags: [hwpm]

- name: HWPM build status notice
  debug:
    msg: |
      ℹ️  HWPM module build was requested but may have compatibility issues with L4T {{ l4t_version }}.
      This is typically due to API differences between NVIDIA HWPM code and the L4T kernel version.
      The core K8s kernel is fully functional without HWPM.
  when: build_hwpm | bool
  tags: [hwpm]

- name: Build netfilter modules
  include_tasks: 09_netfilter_modules.yml
  when: profile_netfilter == 'modules'
  tags: [netfilter]

- name: Validate build
  include_tasks: 10_validate.yml
  tags: [validate]

- name: Validate K8s features
  include_tasks: 11_k8s_validation.yml
  tags: [validate, k8s]
```

### roles/jetson_kernel/tasks/00_select_overlays.yml
```yaml
- name: Fetch files01 index from target
  slurp:
    src: "{{ files01_dir }}/index.yml"
  register: files01_index_raw

- name: Parse files01 index (matrix)
  set_fact:
    files01_index: "{{ files01_index_raw.content | b64decode | from_yaml }}"

- name: Select overlay filenames for this L4T
  set_fact:
    _matrix: "{{ files01_index.l4t_matrix.get(l4t_version, {}) }}"
    gpu_kconfig_src: "{{ _matrix.gpu_kconfig | default(files01_index.fallback.gpu_kconfig) }}"
    gpu_makefile_src: "{{ _matrix.gpu_makefile | default(files01_index.fallback.gpu_makefile) }}"
    hwpm_makefile_src: "{{ _matrix.hwpm_makefile | default(files01_index.fallback.hwpm_makefile) }}"
```

### roles/jetson_kernel/tasks/01_prerequisites.yml
```yaml
- name: Fix any broken package installations first
  shell: |
    dpkg --configure -a || true
    apt-get -f install -y || true
  ignore_errors: yes
  become: yes

- name: Install required packages
  apt:
    name:
      - build-essential
      - bc
      - bison
      - flex
      - libssl-dev
      - libncurses-dev
      - dwarves
      - ccache
      - libelf-dev
      - python3
      - rsync
      - gcc-aarch64-linux-gnu
      - g++-aarch64-linux-gnu
    state: present
    update_cache: yes
    cache_valid_time: 3600
  register: package_install
  failed_when: false
  become: yes

- name: Handle package installation issues
  shell: |
    dpkg --configure -a || true
    apt-get -f install -y || true
  when: package_install.failed
  ignore_errors: yes
  become: yes

- name: Verify archives exist on target
  stat:
    path: "{{ item }}"
  loop:
    - "{{ jetson_linux_archive }}"
    - "{{ public_sources_archive }}"
  register: archive_checks
  become: no

- name: Assert archives present
  assert:
    that: "{{ archive_checks.results | map(attribute='stat.exists') | list | min }}"
    fail_msg: "One or more archives are missing on the target."
  become: no

- name: Check available disk space
  shell: df -BG {{ work_root | dirname }} | awk 'NR==2 {print $4}' | sed 's/G//'
  register: disk_space
  changed_when: false
  become: no

- name: Verify sufficient disk space (20GB minimum)
  assert:
    that:
      - disk_space.stdout | int >= 20
    fail_msg: "Insufficient disk space: {{ disk_space.stdout }}GB available, 20GB required"
```

### roles/jetson_kernel/tasks/01_artifact_install.yml
```yaml
---
# Artifact Mode: Install pre-built kernel artifacts (fast deployment)
# Alternative to building on-target for faster node provisioning

- name: Assert artifact mode configuration
  assert:
    that:
      - artifact_mode.kernel_image_url | length > 0
      - artifact_mode.sha256 | length > 0
    fail_msg: "Artifact mode requires kernel_image_url and sha256"
  tags: [install, artifact]

- name: Create artifacts directory
  file:
    path: "{{ work_root }}/artifacts"
    state: directory
    mode: '0755'
  tags: [install, artifact]

- name: Download pre-built kernel image
  get_url:
    url: "{{ artifact_mode.kernel_image_url }}"
    dest: "{{ work_root }}/artifacts/Image"
    mode: '0644'
    checksum: "sha256:{{ artifact_mode.sha256 }}"
  tags: [install, artifact]

- name: Download kernel modules (if provided)
  get_url:
    url: "{{ artifact_mode.modules_tar_url }}"
    dest: "{{ work_root }}/artifacts/modules.tar.gz"
    mode: '0644'
  when: artifact_mode.modules_tar_url | length > 0
  tags: [install, artifact]

- name: Download DTBs (if provided)  
  get_url:
    url: "{{ artifact_mode.dtb_tar_url }}"
    dest: "{{ work_root }}/artifacts/dtb.tar.gz"
    mode: '0644'
  when: artifact_mode.dtb_tar_url | length > 0
  tags: [install, artifact]

- name: Extract kernel modules
  unarchive:
    src: "{{ work_root }}/artifacts/modules.tar.gz"
    dest: "{{ work_root }}/artifacts/"
    remote_src: yes
  when: artifact_mode.modules_tar_url | length > 0
  become: yes
  tags: [install, artifact]

- name: Install kernel modules
  shell: |
    set -eu
    if [ -d "{{ work_root }}/artifacts/lib/modules" ]; then
      rsync -a "{{ work_root }}/artifacts/lib/modules/" /lib/modules/
      depmod -a "{{ kernel_release_expected }}"
    fi
  become: yes
  when: artifact_mode.modules_tar_url | length > 0
  tags: [install, artifact]

- name: Extract and install DTBs
  shell: |
    set -eu
    if [ -f "{{ work_root }}/artifacts/dtb.tar.gz" ]; then
      mkdir -p /boot/dtb
      tar -xzf "{{ work_root }}/artifacts/dtb.tar.gz" -C /boot/dtb/ --strip-components=1
    fi
  become: yes
  when: artifact_mode.dtb_tar_url | length > 0
  tags: [install, artifact]

# Use the same BYOK installation logic from 07_install_byok.yml
- name: Set artifact paths for BYOK installation
  set_fact:
    _artifact_image: "{{ work_root }}/artifacts/Image"
  tags: [install, artifact]

- name: Get artifact Image size and SHA256
  shell: |
    set -eu
    stat -c %s "{{ _artifact_image }}"
    sha256sum "{{ _artifact_image }}" | awk '{print $1}'
  register: artifact_meta
  changed_when: false
  tags: [install, artifact]

- name: Split artifact size/SHA  
  set_fact:
    _built_size: "{{ (artifact_meta.stdout_lines[0] | int) }}"
    _built_sha:  "{{ artifact_meta.stdout_lines[1] }}"
  tags: [install, artifact]

# Include the rest of BYOK installation steps
- include_tasks: 07_install_byok.yml
  vars:
    kbuild: "{{ work_root }}/artifacts"
  tags: [install, artifact]

---
# Artifact Mode: Install pre-built kernel artifacts (fast deployment)
# Alternative to building on-target for faster node provisioning

- name: Assert artifact mode configuration
  assert:
    that:
      - artifact_mode.kernel_image_url | length > 0
      - artifact_mode.sha256 | length > 0
    fail_msg: "Artifact mode requires kernel_image_url and sha256"
  tags: [install, artifact]

- name: Create artifacts directory
  file:
    path: "{{ work_root }}/artifacts"
    state: directory
    mode: '0755'
  tags: [install, artifact]

- name: Download pre-built kernel image
  get_url:
    url: "{{ artifact_mode.kernel_image_url }}"
    dest: "{{ work_root }}/artifacts/Image"
    mode: '0644'
    checksum: "sha256:{{ artifact_mode.sha256 }}"
  tags: [install, artifact]

- name: Download kernel modules (if provided)
  get_url:
    url: "{{ artifact_mode.modules_tar_url }}"
    dest: "{{ work_root }}/artifacts/modules.tar.gz"
    mode: '0644'
  when: artifact_mode.modules_tar_url | length > 0
  tags: [install, artifact]

- name: Download DTBs (if provided)  
  get_url:
    url: "{{ artifact_mode.dtb_tar_url }}"
    dest: "{{ work_root }}/artifacts/dtb.tar.gz"
    mode: '0644'
  when: artifact_mode.dtb_tar_url | length > 0
  tags: [install, artifact]

- name: Extract kernel modules
  unarchive:
    src: "{{ work_root }}/artifacts/modules.tar.gz"
    dest: "{{ work_root }}/artifacts/"
    remote_src: yes
  when: artifact_mode.modules_tar_url | length > 0
  become: yes
  tags: [install, artifact]

- name: Install kernel modules
  shell: |
    set -eu
    if [ -d "{{ work_root }}/artifacts/lib/modules" ]; then
      rsync -a "{{ work_root }}/artifacts/lib/modules/" /lib/modules/
      depmod -a "{{ kernel_release_expected }}"
    fi
  become: yes
  when: artifact_mode.modules_tar_url | length > 0
  tags: [install, artifact]

- name: Extract and install DTBs
  shell: |
    set -eu
    if [ -f "{{ work_root }}/artifacts/dtb.tar.gz" ]; then
      mkdir -p /boot/dtb
      tar -xzf "{{ work_root }}/artifacts/dtb.tar.gz" -C /boot/dtb/ --strip-components=1
    fi
  become: yes
  when: artifact_mode.dtb_tar_url | length > 0
  tags: [install, artifact]

# Use the same BYOK installation logic from 07_install_byok.yml
- name: Set artifact paths for BYOK installation
  set_fact:
    _artifact_image: "{{ work_root }}/artifacts/Image"
  tags: [install, artifact]

- name: Get artifact Image size and SHA256
  shell: |
    set -eu
    stat -c %s "{{ _artifact_image }}"
    sha256sum "{{ _artifact_image }}" | awk '{print $1}'
  register: artifact_meta
  changed_when: false
  tags: [install, artifact]

- name: Split artifact size/SHA  
  set_fact:
    _built_size: "{{ (artifact_meta.stdout_lines[0] | int) }}"
    _built_sha:  "{{ artifact_meta.stdout_lines[1] }}"
  tags: [install, artifact]

# Include the rest of BYOK installation steps
- include_tasks: 07_install_byok.yml
  vars:
    kbuild: "{{ work_root }}/artifacts"
  tags: [install, artifact]
```
### roles/jetson_kernel/tasks/02_workspace.yml
```yaml
- name: Create workspace directory
  file:
    path: "{{ work_root }}"
    state: directory
    mode: '0755'
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
  become: no

- name: Create current workspace symlink
  file:
    src: "{{ work_root }}"
    dest: "/home/{{ ansible_user }}/jetson-kernel-current"
    state: link
    force: yes
  become: no

- name: Check if archives already exist in workspace
  stat:
    path: "{{ work_root }}/{{ item | basename }}"
  loop:
    - "{{ jetson_linux_archive }}"
    - "{{ public_sources_archive }}"
  register: workspace_archives
  become: no

- name: Copy archives to workspace (files already on target)
  copy:
    src: "{{ item.item }}"
    dest: "{{ work_root }}/"
    remote_src: yes
  loop: "{{ workspace_archives.results }}"
  when: not item.stat.exists
  become: no

- name: Create files01 directory on target
  file:
    path: "{{ files01_dir }}"
    state: directory
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
    mode: '0755'
  become: no

- name: Copy files01 folder to target (recursive)
  copy:
    src: "{{ playbook_dir }}/../files01/"
    dest: "{{ files01_dir }}/"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
    mode: '0644'
  become: no


```
### roles/jetson_kernel/tasks/03_extract_sources.yml
```yaml
- name: Extract L4T BSP
  unarchive:
    src: "{{ work_root }}/Jetson_Linux_R36.4.4_aarch64.tbz2"
    dest: "{{ work_root }}"
    remote_src: yes
    creates: "{{ work_root }}/Linux_for_Tegra"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"

- name: Extract public sources
  unarchive:
    src: "{{ work_root }}/public_sources.tbz2"
    dest: "{{ work_root }}"
    remote_src: yes
    creates: "{{ work_root }}/Linux_for_Tegra/source/kernel_src.tbz2"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"

- name: Create kernel directories
  file:
    path: "{{ item }}"
    state: directory
    mode: '0755'
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
  loop:
    - "{{ src_root }}/kernel"
    - "{{ src_root }}/kernel/nvidia"

- name: Extract kernel source
  unarchive:
    src: "{{ src_root }}/kernel_src.tbz2"
    dest: "{{ src_root }}/kernel"
    remote_src: yes
    creates: "{{ src_root }}/kernel/kernel-jammy-src/Makefile"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"

- name: Extract OOT modules source
  unarchive:
    src: "{{ src_root }}/kernel_oot_modules_src.tbz2"
    dest: "{{ src_root }}/kernel/nvidia"
    remote_src: yes
    creates: "{{ src_root }}/kernel/nvidia/nvidia-oot/Makefile"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"

- name: Replace source_sync.sh with patched version
  copy:
    src: "{{ files01_dir }}/source_sync.sh"
    dest: "{{ src_root }}/source_sync.sh"
    mode: '0755'
    remote_src: yes

- name: Check if kernel sources already synced
  stat:
    path: "{{ ksources }}/Makefile"
  register: kernel_synced

- name: Sync kernel sources
  shell: |
    export SRC={{ src_root }}
    export ARCH={{ arch }}
    export CROSS_COMPILE={{ cross }}
    ./source_sync.sh -t {{ jetson_tag }}
  args:
    chdir: "{{ src_root }}"
    creates: "{{ ksources }}/Makefile"
  environment:
    SRC: "{{ src_root }}"
    ARCH: "{{ arch }}"
    CROSS_COMPILE: "{{ cross }}"
  become: no
  become_user: "{{ ansible_user }}"
  when: not kernel_synced.stat.exists

- name: Verify kernel source extracted
  stat:
    path: "{{ ksources }}/Makefile"
  register: kernel_makefile

- name: Assert kernel source exists
  assert:
    that:
      - kernel_makefile.stat.exists
    fail_msg: "Kernel source sync failed - Makefile not found"

- name: Fix ownership of entire workspace after extraction
  file:
    path: "{{ work_root }}"
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
    recurse: yes
  become: yes

```

### tasks/04_patches.yml
```yaml
- name: Create build directory
  file:
    path: "{{ kbuild }}"
    state: directory
    mode: '0755'
    owner: "{{ ansible_user }}"
    group: "{{ ansible_user }}"
  become: no

- name: Apply GPU Kconfig patch
  copy:
    src: "{{ files01_dir }}/patches/{{ gpu_kconfig_src }}"
    dest: "{{ ksources }}/drivers/gpu/Kconfig"
    mode: '0644'
    remote_src: yes
  become: no

- name: Apply GPU Makefile patch
  copy:
    src: "{{ files01_dir }}/patches/{{ gpu_makefile_src }}"
    dest: "{{ ksources }}/drivers/gpu/Makefile"
    mode: '0644'
    remote_src: yes

- name: Check if init.c.adjusted exists
  stat:
    path: "{{ files01_dir }}/patches/init.c.adjusted"
  register: init_c_check

- name: Apply init.c patch
  copy:
    src: "{{ files01_dir }}/patches/init.c.adjusted"
    dest: "{{ ksources }}/arch/arm64/mm/init.c"
    mode: '0644'
    remote_src: yes
  when: init_c_check.stat.exists

- name: Apply wireless regulatory fixes
  copy:
    src: "{{ files01_dir }}/patches/{{ item.src }}"
    dest: "{{ ksources }}/{{ item.dest }}"
    mode: '0644'
    remote_src: yes
  loop:
    - { src: "rtw88-regd.c", dest: "drivers/net/wireless/realtek/rtw88/regd.c" }
    - { src: "ath9k-regd.c", dest: "drivers/net/wireless/ath/ath9k/regd.c" }
  when: apply_regdom_fixes

- name: Make fix-regdom.sh executable
  file:
    path: "{{ files01_dir }}/fix-regdom.sh"
    mode: '0755'
  when: apply_regdom_fixes

- name: Run fix-regdom.sh
  shell: |
    if [ ! -f .regdom_patched ]; then
      bash "{{ files01_dir }}/fix-regdom.sh"
      touch .regdom_patched
    fi
  args:
    chdir: "{{ ksources }}"
  when: apply_regdom_fixes

- name: Apply HWPM Makefile override
  copy:
    src: "{{ files01_dir }}/patches/{{ hwpm_makefile_src }}"
    dest: "{{ src_root }}/hwpm/drivers/tegra/hwpm/Makefile"
    mode: '0644'
    remote_src: yes
  when: build_hwpm | bool

- name: Copy HWPM UAPI header
  copy:
    src: "{{ files01_dir }}/patches/tegra-soc-hwpm-uapi.h"
    dest: "{{ ksources }}/include/uapi/linux/tegra-soc-hwpm-uapi.h"
    mode: '0644'
    remote_src: yes
  when: build_hwpm | bool




```

### tasks/05_config.yml
```yaml

- name: Seed config from reference or running kernel
  shell: |
    set -eu
    if [ -f "{{ files01_dir }}/.config-5aug" ]; then
      cp -f "{{ files01_dir }}/.config-5aug" "{{ kbuild }}/.config"
    elif zcat /proc/config.gz >/dev/null 2>&1; then
      zcat /proc/config.gz > "{{ kbuild }}/.config"
    else
      echo "No config source found"; exit 1
    fi
  args:
    executable: /bin/bash
  become: no

- name: Create container deps config fragment
  template:
    src: kernel_config_fragments/25-k8s-container-deps.cfg.j2
    dest: "{{ files01_dir }}/25-k8s-container-deps.cfg"
    mode: '0644'
  become: no

- name: Create netfilter config fragment
  template:
    src: "kernel_config_fragments/20-k8s-netfilter-{{ profile_netfilter }}.cfg.j2"
    dest: "{{ files01_dir }}/20-k8s-netfilter-{{ profile_netfilter }}.cfg"
    mode: '0644'
  become: no

# VXLAN configs now included in 40-k8s-hardening.cfg - no separate fragment needed

- name: Build merge command
  set_fact:
    merge_configs: >-
      "{{ kbuild }}/.config"
      "{{ files01_dir }}/25-k8s-container-deps.cfg"
      "{{ files01_dir }}/20-k8s-netfilter-{{ profile_netfilter }}.cfg"
      "{{ files01_dir }}/kconfig/40-k8s-hardening.cfg"
  become: no

- name: Merge config fragments
  shell: |
    set -eu
    mkdir -p "{{ kbuild }}"
    "{{ ksources }}/scripts/kconfig/merge_config.sh" -m -O "{{ kbuild }}" {{ merge_configs }}
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_prepare
  args:
    executable: /bin/bash
  become: no

- name: Preflight kernelrelease (fast)
  shell: |
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} -s kernelrelease >/dev/null
    cat "{{ kbuild }}/include/config/kernel.release" | tr -d '\n'
  register: pre_krel
  changed_when: false
  become: no

- name: Check preflight kernelrelease cleanliness
  assert:
    that:
      - "'+' not in pre_krel.stdout"
      - pre_krel.stdout.strip() == kernel_release_expected
    fail_msg: "Preflight kernelrelease mismatch: {{ pre_krel.stdout }} vs {{ kernel_release_expected }}"

- name: Guard must-have features
  shell: |
    set -eu
    grep -q '^CONFIG_NETFILTER_XTABLES=y' "{{ kbuild }}/.config"
    grep -q '^CONFIG_IP_VS=y' "{{ kbuild }}/.config"
    grep -q '^CONFIG_RTW88=m' "{{ kbuild }}/.config"
  args: { executable: /bin/bash }
  changed_when: false
  become: no

- name: Verify critical config options
  shell: |
    set -e
    grep -q '^CONFIG_BRIDGE=y' "{{ kbuild }}/.config"
    grep -q '^CONFIG_BRIDGE=y' "{{ kbuild }}/include/config/auto.conf" 
    grep -q '^#define CONFIG_BRIDGE 1' "{{ kbuild }}/include/generated/autoconf.h"
    grep -q '^CONFIG_LOCALVERSION="-tegra"' "{{ kbuild }}/.config"
  changed_when: false
  become: no





```


### tasks/06_build.yml
```yaml


- name: Check build sentinel
  stat:
    path: "{{ kbuild }}/.build_done"
  register: build_done

- name: Start kernel build (async)
  shell: |
    nohup bash -c \
      "export PATH=/usr/lib/ccache:$PATH; \
       make -C '{{ ksources }}' O='{{ kbuild }}' ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
       -j{{ build_jobs }} Image modules dtbs" \
      > "{{ kbuild }}/kernel_build.log" 2>&1 & echo $! > "{{ kbuild }}/kernel_build.pid"
  when: not build_done.stat.exists
  async: 14400
  poll: 0
  register: kernel_build
  become: no
  become_user: "{{ ansible_user }}"

- name: Wait for kernel build to complete
  shell: |
    if [ -f "{{ kbuild }}/.build_done" ]; then
      echo DONE; exit 0; fi
    pid=$(cat "{{ kbuild }}/kernel_build.pid" 2>/dev/null || true)
    if [ -n "$pid" ] && ps -p "$pid" >/dev/null 2>&1; then
      echo RUNNING; exit 100; fi
    if [ -f "{{ kbuild }}/arch/arm64/boot/Image" ]; then
      echo DONE; exit 0; fi
    echo FAILED; exit 1
  register: build_status
  until: build_status.rc == 0
  retries: 300
  delay: 30
  failed_when: build_status.stdout == "FAILED"
  changed_when: false

- name: Check kernel release string
  shell: |
    cat "{{ kbuild }}/include/config/kernel.release"
  register: kernel_release
  changed_when: false

- name: Verify clean kernel release
  assert:
    that:
      - "'+' not in kernel_release.stdout"
      - kernel_release.stdout == kernel_release_expected
    fail_msg: "Kernel release incorrect: {{ kernel_release.stdout }}"

- name: Mark build done
  file:
    path: "{{ kbuild }}/.build_done"
    state: touch

- name: Remove build PID file
  file:
    path: "{{ kbuild }}/kernel_build.pid"
    state: absent
```

### tasks/07_install_byok.yml
```yaml

---
# Preflights — space, writability, and target path detection

- name: Get built Image size and SHA256
  shell: |
    set -eu
    stat -c %s "{{ kbuild }}/arch/arm64/boot/Image"
    sha256sum "{{ kbuild }}/arch/arm64/boot/Image" | awk '{print $1}'
  args: { executable: /bin/bash }
  register: built_meta
  changed_when: false

- name: Split size/SHA
  set_fact:
    _built_size: "{{ (built_meta.stdout_lines[0] | int) }}"
    _built_sha:  "{{ built_meta.stdout_lines[1] }}"

- name: Ensure /boot is writable (creates then removes a temp file)
  block:
    - tempfile:
        state: file
        prefix: ".byok_writecheck."
        path: /boot
      register: _boot_tmp
      become: yes
    - file:
        path: "{{ _boot_tmp.path }}"
        state: absent
      become: yes

- name: Gather mount facts (to read free space for /boot)
  setup:
    filter: ansible_mounts
  changed_when: false

- name: Compute free bytes on /boot
  set_fact:
    _boot_free: "{{ (ansible_mounts | selectattr('mount','equalto','/boot') | list).0.size_available | default((ansible_mounts | selectattr('mount','equalto','/') | list).0.size_available) }}"

- name: Assert enough free space (needs built size + 8MB headroom)
  assert:
    that:
      - _boot_free | int >= (_built_size | int + 8*1024*1024)
    fail_msg: "Not enough free space on /boot (free={{ _boot_free }} bytes, need >= {{ (_built_size | int) + (8*1024*1024) }})"

# Discover where the DEFAULT boot entry loads its kernel from
- name: Read extlinux.conf (for path discovery only)
  slurp:
    path: /boot/extlinux/extlinux.conf
  register: _extlinux
  become: yes
  failed_when: false

- name: Derive target LINUX path from DEFAULT label (fallback to /boot/{{ kernel_release_expected }})
  shell: |
    set -eu
    f=/boot/extlinux/extlinux.conf
    [ -s "$f" ] || { echo "/boot/{{ kernel_release_expected }}"; exit 0; }
    awk '
      /^DEFAULT[[:space:]]+/ {def=$2}
      /^LABEL[[:space:]]+/   {lbl=$2; inblock=(lbl==def)}
      inblock && /^[[:space:]]*LINUX[[:space:]]+/ {print $2; exit}
      END { if (NR>0 && !seen) {} }
    ' "$f" | awk 'NR==1{print; exit}'
  args: { executable: /bin/bash }
  register: _linux_dst
  changed_when: false
  become: yes

- name: Set target image path (safe fallback)
  set_fact:
    _dst_image: "{{ (_linux_dst.stdout | trim) if (_linux_dst.stdout | trim) else '/boot/' ~ kernel_release_expected }}"

# Atomic install + provenance

- name: Backup current image if present
  shell: |
    set -eu
    if [ -f "{{ _dst_image }}" ]; then
      cp -a "{{ _dst_image }}" "{{ _dst_image }}.backup.$(date +%s)"
    fi
  args: { executable: /bin/bash }
  become: yes

- name: Atomic install of built Image to {{ _dst_image }}
  shell: |
    set -eu
    tmp="$(mktemp /boot/.Image.$(basename '{{ _dst_image }}').XXXXXX)"
    install -m0644 "{{ kbuild }}/arch/arm64/boot/Image" "$tmp"
    sync
    mv -f "$tmp" "{{ _dst_image }}"
    sync
  args: { executable: /bin/bash }
  become: yes

- name: Verify installed image SHA256 matches built
  shell: "sha256sum '{{ _dst_image }}' | awk '{print $1}'"
  register: _dst_sha
  changed_when: false
  become: yes

- assert:
    that: _dst_sha.stdout == _built_sha
    fail_msg: "Installed image SHA mismatch! expected={{ _built_sha }} got={{ _dst_sha.stdout }}"

- name: Persist expected SHA for post-reboot provenance
  copy:
    content: "{{ _built_sha }}\n"
    dest: /boot/.byok-kernel-sha256
    mode: '0644'
  become: yes

# Modules + initrd for the same release string (no bootloader edits)
- name: Install modules and depmod
  shell: |
    set -eu
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_install
    depmod -a
  args: { executable: /bin/bash }
  become: yes

- name: Create or update initrd for {{ kernel_release_expected }}
  command: "update-initramfs -c -k {{ kernel_release_expected }}"
  register: _mkinitrd
  failed_when: false
  become: yes

- name: Fallback update existing initrd
  command: "update-initramfs -u -k {{ kernel_release_expected }}"
  when: _mkinitrd.rc != 0
  become: yes

- name: Create kernel receipt directory
  file:
    path: /var/lib/jetson-kernel
    state: directory
    mode: '0755'
  become: yes

- name: Write kernel installation receipt
  template:
    src: kernel-receipt.json.j2
    dest: /var/lib/jetson-kernel/receipt.json
    mode: '0644'
  become: yes

- name: Show extlinux DEFAULT LINUX target (for provenance)
  debug:
    msg: "BYOK installed Image to {{ _dst_image }}"

# Reboot to the newly installed kernel (BYOK)
- name: Reboot system
  reboot:
    reboot_timeout: "{{ reboot_wait }}"
    msg: "Rebooting to new kernel (BYOK)"
    pre_reboot_delay: 5
    post_reboot_delay: "{{ post_reboot_delay }}"
  when: not skip_reboot
  become: yes

- name: Verify new kernel version after reboot
  command: uname -r
  register: new_kernel
  changed_when: false

- name: Assert correct kernel running
  assert:
    that:
      - new_kernel.stdout == kernel_release_expected
    fail_msg: "Kernel mismatch after reboot: {{ new_kernel.stdout }} vs {{ kernel_release_expected }}"
  when: not skip_reboot
```

### tasks07_install.yml
```yaml

- name: Install kernel modules
  shell: |
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_install
  become: yes

- name: Rebuild module dependency indexes
  command: depmod -a
  become: yes

- name: Backup existing kernel
  copy:
    src: /boot/Image
    dest: "/boot/Image.backup-{{ ansible_date_time.epoch }}"
    remote_src: yes
    backup: yes
  become: yes

- name: Install new kernel image
  copy:
    src: "{{ kbuild }}/arch/arm64/boot/Image"
    dest: /boot/Image
    mode: '0644'
    remote_src: yes
  become: yes

- name: Install DTBs to /boot/dtb
  shell: |
    set -eu
    mkdir -p /boot/dtb
    rsync -a --delete "{{ kbuild }}/arch/arm64/boot/dts/" /boot/dtb/
  args:
    executable: /bin/bash
  become: yes

- name: Create br_netfilter module-load config (modules profile only)
  copy:
    content: "br_netfilter"
    dest: /etc/modules-load.d/br_netfilter.conf
    mode: '0644'
  when: profile_netfilter == 'modules'
  become: yes

- name: Ensure bridge netfilter sysctls are present
  copy:
    dest: /etc/sysctl.d/99-bridge-nf.conf
    content: |
      net.bridge.bridge-nf-call-iptables = 1
      net.bridge.bridge-nf-call-ip6tables = 1
      net.ipv4.ip_forward = 1
    mode: '0644'
  notify: reload sysctl
  become: yes

- name: Build initrd for target kernel (failsafe approach)
  command: update-initramfs -c -k {{ kernel_release_expected }}
  when: ansible_distribution == "Ubuntu"
  become: yes
  ignore_errors: yes

- name: Update initramfs for running kernel (fallback)
  command: update-initramfs -u
  become: yes
  when: ansible_distribution == "Ubuntu"

- name: Install versioned kernel image for extlinux compatibility
  copy:
    src: "{{ kbuild }}/arch/arm64/boot/Image"
    dest: "/boot/{{ kernel_release_expected }}"
    mode: '0644'
    remote_src: yes
  become: yes

- name: Ensure /boot/initrd points to the new initrd (failsafe symlink)
  file:
    src: "/boot/initrd.img-{{ kernel_release_expected }}"
    dest: "/boot/initrd"
    state: link
    force: yes
  become: yes
  ignore_errors: yes

- name: Verify extlinux.conf exists
  stat:
    path: /boot/extlinux/extlinux.conf
  register: extlinux
  become: yes

- name: Read extlinux.conf for validation
  slurp:
    path: /boot/extlinux/extlinux.conf
  register: extlinux_conf
  when: extlinux.stat.exists
  become: yes

- name: Validate LINUX/INITRD/FDT paths referenced by extlinux.conf
  vars:
    conf: "{{ extlinux_conf.content | b64decode }}"
    linux_path: "{{ (conf | regex_search('^\\s*LINUX\\s+(\\S+)', '\\1', multiline=True)) or ['/boot/Image'] | first }}"
    initrd_path: "{{ (conf | regex_search('^\\s*INITRD\\s+(\\S+)', '\\1', multiline=True)) or ['/boot/initrd'] | first }}"
    fdt_path: "{{ (conf | regex_search('^\\s*FDT\\s+(\\S+)', '\\1', multiline=True)) | default('') }}"
  block:
    - name: Check kernel image exists
      stat:
        path: "{{ linux_path }}"
      register: s_linux
      become: yes

    - name: Check initrd exists
      stat:
        path: "{{ initrd_path }}"
      register: s_initrd
      become: yes

    - name: Check DTB reference (skip if board uses FDTDIR)
      stat:
        path: "{{ fdt_path }}"
      register: s_fdt
      when: fdt_path|length > 0
      become: yes

    - name: Report extlinux path validation results
      debug:
        msg: |
          extlinux.conf validation:
          LINUX={{ linux_path }} - {% if s_linux.stat.exists %}✅ EXISTS{% else %}❌ MISSING{% endif %}
          INITRD={{ initrd_path }} - {% if s_initrd.stat.exists %}✅ EXISTS{% else %}❌ MISSING{% endif %}
          FDT={{ fdt_path|default('N/A') }} - {% if fdt_path|length == 0 %}N/A{% elif s_fdt.stat.exists %}✅ EXISTS{% else %}❌ MISSING{% endif %}

    - name: Fail if critical extlinux paths are missing
      assert:
        that:
          - s_linux.stat.exists
          - s_initrd.stat.exists
          - fdt_path|length == 0 or s_fdt.stat.exists
        fail_msg: "extlinux.conf references missing paths - see debug output above"
  when: extlinux.stat.exists

- name: Reboot system
  reboot:
    reboot_timeout: "{{ reboot_wait }}"
    msg: "Rebooting to new kernel"
    pre_reboot_delay: 5
    post_reboot_delay: "{{ post_reboot_delay }}"
  when: not skip_reboot
  become: yes

- name: Verify new kernel version
  command: uname -r
  register: new_kernel
  changed_when: false

- name: Assert correct kernel running
  assert:
    that:
      - new_kernel.stdout == kernel_release_expected
    fail_msg: "Kernel mismatch after reboot: {{ new_kernel.stdout }}"
  when: not skip_reboot
  ```


### roles/jetson_kernel/tasks/08_hwpm.yml
```yaml
---
# Build NVIDIA HWPM OOT module with robust conftest handling
# All tasks carry the "hwpm" tag for selective runs.


- name: Try generating conftest via nvidia-oot (if tree exists)
  when: ansible_facts['distribution'] is defined  # dummy condition to keep task always evaluated
  shell: |
    set -eu
    KSRC="{{ ksources }}"
    KBUILD="{{ kbuild }}"
    SRCROOT="{{ src_root }}"
    J="{{ build_jobs|default(6) }}"

    # Skip if we already have the canonical conftest
    if [ -f "$KBUILD/out/nvidia-conftest/nvidia/conftest/conftest.h" ]; then
      echo "conftest present"; exit 0
    fi

    if [ -d "$SRCROOT/nvidia-oot" ]; then
      echo "Building nvidia-oot to trigger conftest..."
      make -C "$KSRC" O="$KBUILD" ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
        M="$SRCROOT/nvidia-oot" modules -j"$J" || true
    fi

    if [ -d "$SRCROOT/nvgpu" ]; then
      echo "Building nvgpu to trigger conftest..."
      make -C "$KSRC" O="$KBUILD" ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
        M="$SRCROOT/nvgpu" modules -j"$J" || true
    fi
  args: { executable: /bin/bash }
  changed_when: true
  tags: [hwpm]

- name: Resolve final conftest directory (best-effort)
  shell: |
    set -e
    KBUILD="{{ kbuild }}"
    # Prefer canonical layout
    if [ -f "$KBUILD/out/nvidia-conftest/nvidia/conftest/conftest.h" ]; then
      echo "$KBUILD/out/nvidia-conftest"; exit 0;
    fi
    # Accept legacy layouts if they exist
    for base in "$KBUILD" "$KBUILD/nvidia-oot" "$KBUILD/nvgpu"; do
      if [ -f "$base/nvidia/conftest/conftest.h" ]; then
        echo "$base"; exit 0;
      fi
    done
    echo ""
  args: { executable: /bin/bash }
  register: conftest_dir_resolved
  changed_when: false
  tags: [hwpm]

- name: "Fallback: synthesize minimal conftest stub (last resort)"
  when: "conftest_dir_resolved.stdout | trim == ''"
  block:
    - name: Create canonical out tree
      file:
        path: "{{ kbuild }}/out/nvidia-conftest/nvidia/conftest"
        state: directory
        mode: '0755'
      tags: [hwpm]

    # File for the <nvidia/conftest.h> include style
    - name: Write nvidia/conftest.h
      copy:
        dest: "{{ kbuild }}/out/nvidia-conftest/nvidia/conftest.h"
        mode: '0644'
        content: |
          #ifndef NVIDIA_CONFTEST_H
          #define NVIDIA_CONFTEST_H 1
          /* Minimal stub; add defines only if build errors name them. */
          #endif
      tags: [hwpm]

    # File for the <nvidia/conftest/conftest.h> include style
    - name: Write nvidia/conftest/conftest.h
      copy:
        dest: "{{ kbuild }}/out/nvidia-conftest/nvidia/conftest/conftest.h"
        mode: '0644'
        content: |
          #ifndef NVIDIA_CONFTEST_H
          #define NVIDIA_CONFTEST_H 1
          /* Minimal stub; add defines only if build errors name them. */
          #endif
      tags: [hwpm]

    # Convenience symlink so -I$KBUILD/nvidia also works if present
    - name: Compat symlink {{ kbuild }}/nvidia -> out/nvidia-conftest/nvidia
      file:
        src: "{{ kbuild }}/out/nvidia-conftest/nvidia"
        dest: "{{ kbuild }}/nvidia"
        state: link
      tags: [hwpm]
  tags: [hwpm]

- name: Set final conftest dir fact
  set_fact:
    final_conftest_dir: >-
      {{ (conftest_dir_resolved.stdout | trim)
         if (conftest_dir_resolved.stdout | trim) else (kbuild + '/out/nvidia-conftest') }}
  tags: [hwpm]

- name: Verify conftest.h presence
  stat:
    path: "{{ item }}"
  register: s_conftest_list
  loop:
    - "{{ final_conftest_dir }}/nvidia/conftest.h"
    - "{{ final_conftest_dir }}/nvidia/conftest/conftest.h"
  tags: [hwpm]

- name: Abort if no conftest header variant found
  assert:
    that: "s_conftest_list.results | selectattr('stat.exists') | list | length > 0"
    fail_msg: "No conftest header found under {{ final_conftest_dir }}/nvidia/ (checked both styles)."
  tags: [hwpm]

- name: Show conftest candidates
  shell: |
    set -e
    echo "CONFTEST={{ final_conftest_dir }}"
    ls -l "{{ final_conftest_dir }}/nvidia" || true
    ls -l "{{ final_conftest_dir }}/nvidia/conftest" || true
  args: { executable: /bin/bash }
  changed_when: false
  tags: [hwpm]

- name: Check if kernel provides linux/dma-buf-map.h
  stat:
    path: "{{ ksources }}/include/linux/dma-buf-map.h"
  register: s_dma_buf_map_h
  changed_when: false
  tags: [hwpm]

- name: Create compat include directory
  file:
    path: "{{ kbuild }}/compat/linux"
    state: directory
    mode: '0755'
  when: not s_dma_buf_map_h.stat.exists
  tags: [hwpm]

- name: Install compat linux/dma-buf-map.h
  template:
    src: "dma-buf-map.h.j2"
    dest: "{{ kbuild }}/compat/linux/dma-buf-map.h"
    mode: '0644'
  when: not s_dma_buf_map_h.stat.exists
  tags: [hwpm]

- name: Build HWPM OOT module
  shell: |
    set -eu
    CONFTEST="{{ final_conftest_dir }}"
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
      M="{{ src_root }}/hwpm/drivers/tegra/hwpm" \
      EXTRA_CFLAGS="-DCONFIG_TEGRA_HWPM_OOT=1 \
                    -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest \
                    -I{{ kbuild }}/compat" \
      -j{{ build_jobs|default(6) }} modules V=1
  args: { executable: /bin/bash }
  tags: [hwpm]

- name: Get target kernel release
  command: uname -r
  register: current_krel
  changed_when: false
  tags: [hwpm]

- name: Get module vermagic
  shell: "modinfo '{{ src_root }}/hwpm/drivers/tegra/hwpm/nvhwpm.ko' | awk '/^vermagic:/ {print $2}'"
  register: nvhwpm_vermagic
  changed_when: false
  tags: [hwpm]

- name: Decide if vermagic can match now
  set_fact:
    _krel_match: "{{ current_krel.stdout == kernel_release_expected }}"
  tags: [hwpm]

- name: Fail if vermagic mismatches
  assert:
    that: nvhwpm_vermagic.stdout == current_krel.stdout
    fail_msg: "HWPM vermagic {{ nvhwpm_vermagic.stdout }} != running {{ current_krel.stdout }}"
  when: _krel_match
  tags: [hwpm]

- name: Install HWPM module (target kernel dir)
  shell: |
    KREL="{{ kernel_release_expected }}"
    install -D -m0644 "{{ src_root }}/hwpm/drivers/tegra/hwpm/nvhwpm.ko" \
      "/lib/modules/$KREL/extra/nvhwpm.ko"
  become: yes
  tags: [hwpm]

- name: Create HWPM module load config
  copy:
    content: "nvhwpm"
    dest: /etc/modules-load.d/nvhwpm.conf
    mode: '0644'
  become: yes
  tags: [hwpm]

- name: depmod for target kernel
  command: depmod -a {{ kernel_release_expected }}
  become: yes
  tags: [hwpm]

- name: Load HWPM module
  modprobe:
    name: nvhwpm
    state: present
  become: yes
  when: _krel_match
  ignore_errors: yes
  tags: [hwpm]

- name: Note deferred load
  debug:
    msg: >
      HWPM installed for {{ kernel_release_expected }}. You're running {{ current_krel.stdout }},
      so module load is deferred. Reboot into {{ kernel_release_expected }} and it will load.
  when: not _krel_match
  tags: [hwpm]

- name: Enable dynamic debug for HWPM
  shell: |
    if zcat /proc/config.gz | grep -q '^CONFIG_DYNAMIC_DEBUG=y'; then
      mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
      echo 'module nvhwpm +p' > /sys/kernel/debug/dynamic_debug/control || true
    fi
  become: yes
  ignore_errors: yes
  tags: [hwpm]



```

### roles/jetson_kernel/tasks/09_netfilter_modules.yml
```yaml

- name: Build netfilter modules
  shell: |
    for d in net/netfilter net/ipv4/netfilter; do
      make -C "{{ ksources }}" O="{{ kbuild }}" M="{{ ksources }}/$d" -j{{ build_jobs }} modules
    done
  become: no
  become_user: "{{ ansible_user }}"

- name: Get current kernel release
  command: uname -r
  register: current_krel
  changed_when: false

- name: Install netfilter modules
  shell: |
    set -eu
    KREL="{{ current_krel.stdout }}"
    install_one() { 
      [ -f "$1" ] || return 0
      install -D -m0644 "$1" "/lib/modules/$KREL/${2}"
    }
    
    # Core netfilter
    install_one "{{ kbuild }}/net/netfilter/x_tables.ko" "kernel/net/netfilter/x_tables.ko"
    install_one "{{ kbuild }}/net/netfilter/nfnetlink.ko" "kernel/net/netfilter/nfnetlink.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_conntrack.ko" "kernel/net/netfilter/nf_conntrack.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_defrag_ipv4.ko" "kernel/net/netfilter/nf_defrag_ipv4.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_defrag_ipv6.ko" "kernel/net/netfilter/nf_defrag_ipv6.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_nat.ko" "kernel/net/netfilter/nf_nat.ko"
    
    # iptables
    install_one "{{ kbuild }}/net/ipv4/netfilter/ip_tables.ko" "kernel/net/ipv4/netfilter/ip_tables.ko"
    install_one "{{ kbuild }}/net/ipv4/netfilter/iptable_filter.ko" "kernel/net/ipv4/netfilter/iptable_filter.ko"
    install_one "{{ kbuild }}/net/ipv4/netfilter/iptable_nat.ko" "kernel/net/ipv4/netfilter/iptable_nat.ko"
    
    # xt modules
    install_one "{{ kbuild }}/net/netfilter/xt_conntrack.ko" "kernel/net/netfilter/xt_conntrack.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_MASQUERADE.ko" "kernel/net/netfilter/xt_MASQUERADE.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_mark.ko" "kernel/net/netfilter/xt_mark.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_comment.ko" "kernel/net/netfilter/xt_comment.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_tcpudp.ko" "kernel/net/netfilter/xt_tcpudp.ko"
  become: yes

- name: Update module dependencies
  command: depmod -a
  become: yes

- name: Load netfilter modules
  modprobe:
    name: "{{ item }}"
    state: present
  loop:
    - nf_conntrack
    - nf_nat
    - x_tables
    - ip_tables
    - iptable_filter
    - iptable_nat
  become: yes
  ignore_errors: yes

```
### /roles/tasks/10_validate.yml
```yaml
- name: Validate kernel version
  command: uname -r
  register: final_kernel
  changed_when: false

- name: Check kernel release file
  shell: cat "{{ kbuild }}/include/config/kernel.release"
  register: kernel_release_file
  changed_when: false
  ignore_errors: yes

- name: Verify bridge support
  shell: |
    ip link add name br0 type bridge || true
    ip link del br0 || true
  become: yes
  changed_when: false

- name: Check bridge netfilter sysctls
  stat:
    path: /proc/sys/net/bridge/bridge-nf-call-iptables
  register: bridge_sysctl

- name: Test iptables
  shell: iptables -S | head -n5
  become: yes
  changed_when: false
  ignore_errors: yes

- name: Check HWPM module
  shell: |
    modinfo nvhwpm | head -n5 || echo "HWPM not loaded"
    find /sys -maxdepth 4 -type d -iname '*hwpm*' 2>/dev/null || true
  become: yes
  changed_when: false
  ignore_errors: yes

- name: Read expected BYOK SHA
  slurp:
    path: /boot/.byok-kernel-sha256
  register: byok_sha
  become: yes
  failed_when: false

- name: Compute current /boot image SHA
  shell: "sha256sum '/boot/{{ kernel_release_expected }}' 2>/dev/null | awk '{print $1}'"
  register: cur_sha
  changed_when: false
  become: yes

- name: Display validation summary
  debug:
    msg:
      - "Kernel Version: {{ final_kernel.stdout }}"
      - "Expected: {{ kernel_release_expected }}"
      - "Bridge Netfilter: {{ 'Enabled' if bridge_sysctl.stat.exists else 'Disabled' }}"
      - "Profile: {{ profile_netfilter }}"
      - "Expected SHA: {{ (byok_sha.content | default('') | b64decode | trim) | default('N/A') }}"
      - "Current  SHA: {{ cur_sha.stdout | default('N/A') }}"
      - >-
        {{ '✅ PROVENANCE OK (booted our exact Image)'
           if byok_sha is defined and (byok_sha.content | b64decode | trim) == cur_sha.stdout
           else '❌ PROVENANCE UNKNOWN (hash mismatch or missing)'}}

```
### roles/jetson_kernel/tasks/11_k8s_validation.yml
```yaml

---
# Validate K8s networking features in running kernel
# Quick smoke test for essential Kubernetes functionality

- name: Check kernel config for required K8s features
  shell: |
    set -e
    if [ -f /proc/config.gz ]; then
      config_source="/proc/config.gz"
      cat_cmd="zcat"
    elif [ -f /boot/config-$(uname -r) ]; then
      config_source="/boot/config-$(uname -r)"
      cat_cmd="cat"
    else
      echo "ERROR: Cannot find kernel config"
      exit 1
    fi
    
    # Essential K8s networking features
    features="CONFIG_NETFILTER=y CONFIG_NETFILTER_XTABLES=y CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y CONFIG_NETFILTER_XT_MATCH_OWNER=y CONFIG_IP_VS=y CONFIG_BRIDGE_NETFILTER=y CONFIG_BPF_SYSCALL=y CONFIG_CGROUP_BPF=y"
    
    missing_features=""
    for feature in $features; do
      if ! $cat_cmd "$config_source" | grep -q "^$feature"; then
        missing_features="$missing_features $feature"
      fi
    done
    
    if [ -z "$missing_features" ]; then
      echo "✅ All essential K8s networking features are enabled"
    else
      echo "❌ Missing K8s features: $missing_features"
      exit 1
    fi
  args: { executable: /bin/bash }
  register: k8s_features_check
  changed_when: false
  tags: [validate, k8s]

- name: Verify netfilter modules can load
  modprobe:
    name: "{{ item }}"
    state: present
  loop:
    - br_netfilter
    - nf_conntrack
    - xt_conntrack
    - xt_owner
  become: yes
  ignore_errors: yes
  tags: [validate, k8s]

- name: Check bridge netfilter sysctls
  shell: |
    set -e
    sysctl net.bridge.bridge-nf-call-iptables 2>/dev/null | grep -q "= 1" || echo "bridge-nf-call-iptables not set"
    sysctl net.ipv4.ip_forward 2>/dev/null | grep -q "= 1" || echo "ip_forward not enabled"
  register: sysctl_check
  changed_when: false
  tags: [validate, k8s]

- name: Display K8s validation results
  debug:
    msg: |
      🚀 Kubernetes Readiness Summary:
      {{ k8s_features_check.stdout }}
      
      Kernel: {{ ansible_kernel }}
      Netfilter Profile: {{ profile_netfilter }}
      
      {% if sysctl_check.stdout | length == 0 %}
      ✅ Bridge netfilter sysctls properly configured
      {% else %}
      ⚠️  Sysctls: {{ sysctl_check.stdout }}
      {% endif %}
  tags: [validate, k8s]

```





### roles/jetson_kernel/handlers/main.yml
```yaml
---
- name: reload modules
  command: depmod -a
  become: yes

- name: update initramfs
  command: update-initramfs -u
  become: yes

- name: reload sysctl
  command: sysctl --system
  become: yes
```

### roles/jetson_kernel/templates/kernel_config_fragments/25-k8s-container-deps.cfg.j2
```
CONFIG_LOCALVERSION="-tegra"
CONFIG_LOCALVERSION_AUTO=n

# Container FS & veth
CONFIG_OVERLAY_FS=y
CONFIG_VETH=m

# Bridge stack for CNIs
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_STP=y
CONFIG_LLC=y

# Namespaces & cgroups
CONFIG_NAMESPACES=y
CONFIG_UTS_NS=y
CONFIG_IPC_NS=y
CONFIG_PID_NS=y
CONFIG_NET_NS=y
CONFIG_CGROUPS=y
CONFIG_CGROUP_PIDS=y
CONFIG_CGROUP_SCHED=y
CONFIG_CGROUP_CPUACCT=y
CONFIG_CGROUP_DEVICE=y
CONFIG_CPUSETS=y
CONFIG_MEMCG=y

# Networking base
CONFIG_NET=y
CONFIG_INET=y
CONFIG_IPV6=y
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y

```
### roles/jetson_kernel/templates/dma-buf-map.h.j2
```
/* Compatibility shim for kernels without <linux/dma-buf-map.h> 
 * Generated by Ansible jetson_kernel role
 */
#ifndef _LINUX_DMA_BUF_MAP_H
#define _LINUX_DMA_BUF_MAP_H

#include <linux/dma-buf.h>

/* Minimal wrapper struct for dma_buf_map compatibility */
struct dma_buf_map {
    void *vaddr;
};

static inline bool dma_buf_map_is_null(const struct dma_buf_map *map)
{
    return !map || !map->vaddr;
}

static inline void dma_buf_map_set_vaddr(struct dma_buf_map *map, void *vaddr)
{
    if (map) map->vaddr = vaddr;
}

static inline void *dma_buf_map_vaddr(struct dma_buf_map *map)
{
    return map ? map->vaddr : NULL;
}

static inline void dma_buf_map_clear(struct dma_buf_map *map)
{
    if (map) map->vaddr = NULL;
}

#endif /* _LINUX_DMA_BUF_MAP_H */
```
### roles/jetson_kernel/templates/kernel-receipt.json.j2
```
{
  "kernel_build": {
    "timestamp": "{{ ansible_date_time.iso8601 }}",
    "version": "{{ kernel_release_expected }}",
    "sha256": "{{ _built_sha }}",
    "build_mode": "{% if build_on_target %}build_on_target{% else %}artifact_mode{% endif %}",
    "build_host": "{{ ansible_hostname }}",
    "ansible_user": "{{ ansible_user }}",
    "jetson_tag": "{{ jetson_tag }}",
    "l4t_version": "{{ l4t_version }}"
  },
  "features": {
    "netfilter_profile": "{{ profile_netfilter }}",
    "k8s_hardening": true,
    "vxlan_enabled": {{ enable_vxlan | bool | lower }},
    "hwpm_enabled": {{ build_hwpm | bool | lower }},
    "regdom_fixes": {{ apply_regdom_fixes | bool | lower }}
  },
  "installation": {
    "method": "byok_atomic",
    "extlinux_managed": false,
    "backup_created": true,
    "initramfs_updated": true
  }
}
```


### roles/jetson_kernel/templates/kernel_config_fragments/20-k8s-netfilter-builtins.cfg.j2
```
# Core netfilter/iptables as built-ins
CONFIG_NETFILTER_XTABLES=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_CONNTRACK_MARK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y
CONFIG_NF_NAT=y

CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_TARGET_REJECT=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_RAW=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_TARGET_MASQUERADE=y

CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_MATCH_TCPMSS=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_MATCH_SOCKET=y

CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_LOG=y

```

### roles/jetson_kernel/templates/kernel_config_fragments/20-k8s-netfilter-modules.cfg.j2
```
# Core netfilter/iptables as modules
CONFIG_NETFILTER_XTABLES=m
CONFIG_NF_CONNTRACK=m
CONFIG_NF_CONNTRACK_MARK=m
CONFIG_NF_DEFRAG_IPV4=m
CONFIG_NF_DEFRAG_IPV6=m
CONFIG_NF_NAT=m

CONFIG_IP_NF_IPTABLES=m
CONFIG_IP_NF_FILTER=m
CONFIG_IP_NF_TARGET_REJECT=m
CONFIG_IP_NF_MANGLE=m
CONFIG_IP_NF_RAW=m
CONFIG_IP_NF_NAT=m
CONFIG_IP_NF_TARGET_MASQUERADE=m

CONFIG_NETFILTER_XT_MATCH_CONNTRACK=m
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=m
CONFIG_NETFILTER_XT_MATCH_MARK=m
CONFIG_NETFILTER_XT_MATCH_TCPMSS=m
CONFIG_NETFILTER_XT_MATCH_COMMENT=m
CONFIG_NETFILTER_XT_MATCH_OWNER=m
CONFIG_NETFILTER_XT_MATCH_SOCKET=m

CONFIG_NETFILTER_XT_TARGET_MASQUERADE=m
CONFIG_NETFILTER_XT_TARGET_REDIRECT=m
CONFIG_NETFILTER_XT_TARGET_LOG=m
``` "{{ kbuild }}/include/generated/autoconf.h"
    grep -q '^CONFIG_LOCALVERSION="-tegra"' "{{ kbuild }}/.config"
  changed_when: false

- name: Triple-check BRIDGE is enabled everywhere
  shell: |
    set -e
    grep -q '^CONFIG_BRIDGE=y


```







### ansible.cfg
```ini
[defaults]
host_key_checking = False
stdout_callback = yaml
callbacks_enabled = timer, profile_tasks
gathering = smart
fact_caching = jsonfile
fact_caching_connection = /tmp/ansible_cache
fact_caching_timeout = 3600
retry_files_enabled = True
retry_files_save_path = /tmp/ansible-retry
ansible_managed = Ansible managed: {file} modified on %Y-%m-%d %H:%M:%S by {uid} on {host}
timeout = 30
remote_tmp = /tmp/ansible-${USER}

[ssh_connection]
pipelining = True
control_path = /tmp/ansible-ssh-%%h-%%p-%%r
ssh_args = -o ControlMaster=auto -o ControlPersist=60s
```

### inventory/hosts.yml
```yaml
all:
  children:
    jetsons:
      hosts:
        jetson1:
          ansible_host: 192.168.1.100
          ansible_user: ansible
        jetson2:
          ansible_host: 192.168.1.101
          ansible_user: ansible
```

### inventory/group_vars/jetsons.yml
```yaml
# L4T Version Configuration
l4t_version: "R36.4.4"
kernel_release_expected: "5.15.148-tegra"
jetson_tag: "jetson_36.4.4"

# Build Profile
# Options: "builtins" (recommended) or "modules"
profile_netfilter: "builtins"

# Workspace Configuration
work_root: "/home/{{ ansible_user }}/jetson-nvgpu-{{ ansible_date_time.iso8601_basic_short }}"
src_root: "{{ work_root }}/Linux_for_Tegra/source"
ksources: "{{ src_root }}/kernel-jammy-src"
kbuild: "{{ src_root }}/build"

# Architecture
arch: "arm64"
cross: "aarch64-linux-gnu-"

# Files
files01_dir: "{{ work_root }}/files01"

# Archives (update paths as needed)
jetson_linux_archive: "/home/{{ ansible_user }}/archives/Jetson_Linux_R36.4.4_aarch64.tbz2"
public_sources_archive: "/home/{{ ansible_user }}/archives/public_sources.tbz2"

# Build Options
build_hwpm: true
enable_vxlan: false
apply_regdom_fixes: true

# Reboot Configuration
reboot_wait: 180
post_reboot_delay: 30

# Build Parallelism
build_jobs: "{{ ansible_processor_vcpus }}"
```

### files01/kconfig/25-k8s-container-deps.cfg
```yaml
CONFIG_BRIDGE=y
CONFIG_BRIDGE_VLAN_FILTERING=y
CONFIG_BRIDGE_IGMP_SNOOPING=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_STP=y
CONFIG_GARP=y
CONFIG_LLC=y
CONFIG_OVERLAY_FS=y
CONFIG_OVERLAY_FS_INDEX=y
CONFIG_OVERLAY_FS_NFS_EXPORT=y
CONFIG_OVERLAY_FS_REDIRECT_DIR=y
CONFIG_NAMESPACES=y
CONFIG_UTS_NS=y
CONFIG_IPC_NS=y
CONFIG_USER_NS=y
CONFIG_PID_NS=y
CONFIG_NET_NS=y
CONFIG_CGROUPS=y
CONFIG_MEMCG=y
CONFIG_BLK_CGROUP=y
CONFIG_CGROUP_PIDS=y
CONFIG_CGROUP_CPUACCT=y
CONFIG_CGROUP_SCHED=y
CONFIG_CGROUP_FREEZER=y
CONFIG_CGROUP_BPF=y
CONFIG_TUN=y
CONFIG_VETH=m
CONFIG_MACVLAN=m
CONFIG_MACVTAP=m
CONFIG_VXLAN=m
```

### files01/kconfig/20-k8s-netfilter-builtins.cfg
```yaml
CONFIG_NET=y
CONFIG_INET=y
CONFIG_IPV6=y
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y
CONFIG_NETFILTER_FAMILY_BRIDGE=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_CONNTRACK_MARK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y
CONFIG_NF_NAT=y
CONFIG_NF_NAT_REDIRECT=y
CONFIG_NF_NAT_MASQUERADE=y
CONFIG_NETFILTER_XTABLES=y
CONFIG_NETFILTER_XT_NAT=y
CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_TPROXY=y
CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_RAW=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_TARGET_MASQUERADE=y
CONFIG_IP_NF_TARGET_REDIRECT=y
CONFIG_IP6_NF_IPTABLES=y
CONFIG_IP6_NF_FILTER=y
CONFIG_IP6_NF_MANGLE=y
CONFIG_IP6_NF_RAW=y
CONFIG_IP6_NF_NAT=y
CONFIG_IP6_NF_TARGET_MASQUERADE=y

```
### files01/kconfig/40-k8s-hardening.cfg
```yaml
# --- Core prerequisites
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y
CONFIG_NETFILTER_XTABLES=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_CONNTRACK_MARK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y

# --- IPv4 iptables tables
CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_RAW=y
CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_TCPMSS=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_TPROXY=y

# --- IPv6 iptables tables
CONFIG_IP6_NF_IPTABLES=y
CONFIG_IP6_NF_FILTER=y
CONFIG_IP6_NF_MANGLE=y
CONFIG_IP6_NF_NAT=y
CONFIG_IP6_NF_RAW=y
CONFIG_IP6_NF_TARGET_MASQUERADE=y

# --- ipset (kube-proxy)
CONFIG_IP_SET=y
CONFIG_IP_SET_HASH_IP=y
CONFIG_IP_SET_HASH_NET=y
CONFIG_IP_SET_LIST_SET=y

# --- IPVS for kube-proxy
CONFIG_IP_VS=y
CONFIG_IP_VS_PROTO_TCP=y
CONFIG_IP_VS_PROTO_UDP=y
CONFIG_IP_VS_RR=y
CONFIG_IP_VS_WRR=y
CONFIG_IP_VS_SH=y

# --- Bridge/CNI and tunnels
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_VETH=y
CONFIG_TUN=y
# VXLAN / GENEVE overlay support (module form)
CONFIG_NET_UDP_TUNNEL=m
CONFIG_VXLAN=m
CONFIG_GENEVE=m


# --- TC/qdisc / eBPF datapaths
CONFIG_NET_CLS_ACT=y
CONFIG_NET_CLS_BPF=y
CONFIG_NET_SCH_INGRESS=y
CONFIG_NET_SCH_CLSACT=y

# --- Observability / runtime proof
CONFIG_BPF=y
CONFIG_BPF_SYSCALL=y
CONFIG_BPF_JIT=y
CONFIG_KPROBES=y
CONFIG_KRETPROBES=y
CONFIG_IKCONFIG=y
CONFIG_IKCONFIG_PROC=y

# --- CRC helper for netfilter & friends
CONFIG_CRC32C=y
CONFIG_LIBCRC32C=y

# --- Wireless networking (critical for connectivity)
CONFIG_WLAN=y
CONFIG_WLAN_VENDOR_REALTEK=y
CONFIG_CFG80211=m
CONFIG_MAC80211=m
CONFIG_RTW88=m
CONFIG_RTW88_CORE=m
CONFIG_RTW88_PCI=m
CONFIG_RTW88_8822C=m
CONFIG_RTW88_8822CE=m

```






## CRITICAL ISSUES & RESOLUTIONS (Updated 2025-08-11)

### ❌ ISSUE: Network Drivers Stripped by olddefconfig

**Problem**: When building kernel with netfilter features, the `olddefconfig` command in `05_config.yml` (line 388) aggressively strips out essential network drivers, resulting in a kernel with no network connectivity.

**Symptoms**:
- Kernel builds successfully with all required K8s netfilter features
- After reboot, system has no network interfaces (`/lib/modules/$(uname -r)/kernel/net/` missing)
- SSH connectivity lost, requiring console access
- `apt update` fails with `nvidia-l4t-initrd` errors

**Root Cause**: 
```yaml
# This line in 05_config.yml causes the issue:
make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig
```

The `olddefconfig` command automatically disables network driver configurations when they conflict with or aren't explicitly preserved in the config fragments.

**Current Status**: 
- ✅ Built kernel has correct netfilter features: `CONFIG_NETFILTER_XT_MATCH_OWNER=y`, `CONFIG_IP_VS=y`, etc.  
- ❌ Network drivers missing: `CONFIG_RTW88=m`, `CONFIG_R8169=y`, etc. not preserved
- ✅ Fallback working: Can boot `5.15.148-ciliumtest` kernel for connectivity

**Solution Options**:

1. **RECOMMENDED: Add Network Driver Preservation Fragment**
```yaml
# Create: roles/jetson_kernel/templates/kernel_config_fragments/10-essential-networking.cfg.j2
CONFIG_NET=y
CONFIG_NETDEVICES=y
CONFIG_NET_ETHERNET=y
CONFIG_R8169=y
CONFIG_WLAN=y
CONFIG_RTW88=m
CONFIG_RTW88_CORE=m
CONFIG_RTW88_PCI=m
# ... other essential drivers
```

2. **Alternative: Modify Config Merge Strategy**
```yaml
# In 05_config.yml, change from:
make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig
# To:
make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} oldconfig < /dev/null
```

3. **Conservative: Preserve Original Config Base**
```yaml
# Use working kernel config as base instead of /proc/config.gz
cp /boot/config-5.15.148-ciliumtest "{{ kbuild }}/.config"
```

### 🔄 REQUIRED ACTIONS:

1. **Immediate**: Remove `dyndbg="module rtw88_core +p; module cfg80211 +p"` from extlinux.conf APPEND line (causes boot delays)

2. **Fix Network Drivers**: Implement network driver preservation in config fragments

3. **Test Strategy**: 
   - Build with preserved network drivers
   - Verify both netfilter AND network functionality
   - Validate K8s networking features work properly

4. **Update extlinux.conf Default**: Once fixed, update `DEFAULT 5.15.148-tegra`

---

## Updated File Structure (2025-08-11)

The current documentation shows an older version of the `05_config.yml`. Here's what has changed:



### Comparison with Documented Version
The documented version in this file shows:
- Simpler config seeding (only from /proc/config.gz)  
- No reference to `.config-5aug` file
- Missing the `kconfig/40-k8s-hardening.cfg` fragment
- Same problematic `olddefconfig` line

---

## Current Working Configuration

**Target System**: Jetson Orin Nano 8GB
**OS**: Ubuntu 22.04.5 LTS  
**Current Working Kernel**: `5.15.148-ciliumtest` (has connectivity, missing some netfilter features)
**Built Kernel**: `5.15.148-tegra` (has netfilter, missing network drivers)
**JetPack**: R36.4.4

**Network Interfaces (when working)**:
- `enP8p1s0`: Ethernet (192.168.87.196/24)
- `wlP1p1s0`: WiFi (192.168.1.18/24) 
- `tailscale0`: VPN (100.107.10.3/32)

**extlinux.conf Status**:
- `DEFAULT 5.15.148-tegra` (set but not working due to network driver issue)
- Fallback: `ciliumtest` label boots working kernel
- Remove `dyndbg=` parameter from APPEND line to fix boot delays
  
