# NVIDIA Conftest Rebuild Guide

## Overview
This guide explains how to rebuild the NVIDIA conftest system from scratch to resolve SOC function redefinition errors in NVGPU kernel compilation.

## Problem Statement
The current issue is that conftest headers are generated but the `NVGPU_HAS_KERNEL_SOC_HELPERS` macro is not being properly defined or force-included during NVGPU compilation, causing SOC function redefinitions between kernel SOC helpers and NVGPU wrapper functions.

## Directory Structure
```
conftest-builder/
├── current-conftest/          # Current failing conftest (reference)
│   └── nvidia/
│       ├── conftest/
│       │   ├── headers.h      # Generated headers with macros
│       │   ├── functions.h    # Function detection results
│       │   └── compile-tests/ # Individual test results
│       ├── conftest.sh        # Main conftest script
│       ├── Makefile           # Build configuration
│       └── conftest_soc_*.c   # Our custom SOC probes
├── nvidia-oot-conftest/       # Original NVIDIA conftest scripts
│   ├── Makefile               # Original Makefile
│   ├── conftest.h             # Base header
│   └── conftest.sh            # Original script (836+ lines)
└── CONFTEST_REBUILD_GUIDE.md  # This guide
```

## Core Conftest Architecture

### 1. conftest.sh Script (836 lines)
**Purpose:** Main orchestrator that detects kernel features
**Key Functions:**
- `compile_test()` - Tests if code compiles with kernel
- `symbol_test()` - Checks if kernel symbols exist  
- `header_test()` - Verifies header availability
- Generates `.h` files with feature detection results

### 2. Makefile System
**Purpose:** Integrates with kernel Kbuild system
**Critical Requirements:**
- Must work with `make -C $KERNEL_SRC O=$BUILD_DIR M=$PWD`
- Must define `obj-m` targets for probe objects
- Must use kernel's compilation flags and toolchain

### 3. Generated Headers
**Purpose:** Provide feature macros to consuming code
**Key Files:**
- `headers.h` - Main macro definitions
- `functions.h` - Function availability  
- `symbols.h` - Symbol presence
- `types.h` - Type structure changes

## SOC-Specific Requirements

### Critical SOC Probes Needed:
1. **tegra_platform_is_silicon()** detection
2. **soc_device_match()** availability  
3. **tegra platform helper functions** presence

### Required Macro Generation:
```c
// Must be generated in headers.h:
#define NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#define NV_LINUX_SOC_DEVICE_MATCH_PRESENT  
#define NV_TEGRA_PLATFORM_HELPERS_PRESENT

// Combined macro that enables wrapper suppression:
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk  
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
```

## Rebuild Strategy

### Phase 1: Analysis
1. **Examine current failure:**
   - Check why force-include isn't working
   - Verify macro definitions in generated headers
   - Test if probes compile independently

2. **Compare with working reference:**
   - Study original nvidia-oot conftest.sh  
   - Identify missing probe definitions
   - Check Makefile integration differences

### Phase 2: SOC Probe Implementation
1. **Create SOC detection functions in conftest.sh:**
   ```bash
   # Add to conftest.sh
   compile_test_with_kernel() {
       local test_name="$1"
       local test_code="$2" 
       local headers="$3"
       
       # Test compilation with proper kernel integration
   }
   
   soc_api_tests() {
       # Test tegra_platform_is_silicon
       # Test soc_device_match  
       # Test tegra helper functions
   }
   ```

2. **Ensure proper Kbuild integration:**
   ```makefile
   # Makefile must include:
   obj-m += conftest_soc_silicon.o conftest_soc_match.o conftest_tegra_helpers.o
   ccflags-y += -Wno-unused-function
   ```

### Phase 3: Integration Testing
1. **Standalone conftest build:**
   ```bash
   cd conftest-builder/rebuild-attempt/
   make -C /path/to/kernel O=/path/to/build ARCH=arm64 M=$PWD
   ```

2. **Verify macro generation:**
   ```bash
   grep "NVGPU_HAS_KERNEL_SOC_HELPERS" conftest/headers.h
   ```

3. **Test force-include mechanism:**
   ```bash
   gcc -E -include conftest/headers.h test.c | grep NVGPU_HAS_KERNEL_SOC_HELPERS
   ```

## Critical Success Factors

### 1. Kernel Header Dependencies
- Must include correct `<soc/tegra/common.h>`
- Must include `<linux/sys_soc.h>` for soc_device_match
- Must use kernel's include paths during compilation

### 2. Cross-Compilation Compatibility  
- Must work with `aarch64-linux-gnu-gcc`
- Must use kernel's compilation flags (`ARCH=arm64`)
- Must handle kernel version differences

### 3. Makefile Integration
- Must be callable from kernel's Kbuild system
- Must generate proper object files for probe testing
- Must not interfere with main kernel build

## Advanced Debugging

### 1. Compilation Trace
```bash
# Enable verbose compilation to see actual command lines
make V=1 -C /kernel O=/build ARCH=arm64 M=$PWD conftest_soc_silicon.o
```

### 2. Macro Expansion Test
```bash
# Create test file to verify macro definitions
echo '#include "conftest/headers.h"
#ifdef NVGPU_HAS_KERNEL_SOC_HELPERS
#warning "NVGPU_HAS_KERNEL_SOC_HELPERS is defined"
#endif' > test_macros.c

gcc -E -I. test_macros.c
```

### 3. Symbol Resolution
```bash
# Check if kernel provides expected symbols
grep -r "tegra_platform_is_silicon" /kernel/source/
objdump -t /build/vmlinux | grep tegra_platform
```

## Expert Outsourcing Specifications

When outsourcing this task, provide:

1. **Complete environment:**
   - Kernel source tree (/kernel-jammy-src)
   - Build directory (/build)  
   - Cross-compilation toolchain info
   - Target architecture (arm64)

2. **Expected deliverables:**
   - Working conftest.sh with SOC probes
   - Makefile that integrates with Kbuild
   - Generated headers.h with required macros
   - Integration test script

3. **Success criteria:**
   - `NVGPU_HAS_KERNEL_SOC_HELPERS=1` defined in headers.h
   - All SOC probes compile successfully
   - Force-include mechanism works in GPU Makefile
   - NVGPU build completes without SOC redefinition errors

4. **Testing requirements:**
   - Must test on actual Jetson Orin Nano hardware
   - Must work with L4T R36.4.4 kernel
   - Must integrate with existing Ansible automation

## Fallback Options

If complete rebuild proves too complex:

1. **Manual macro injection** (immediate fix)
2. **Simplified probe system** (reduced functionality)  
3. **Wrapper function removal** (code modification approach)

## Contact & Handoff

All source files, build logs, and configuration details are available in this directory for expert analysis and rebuilding.