#ifndef NVIDIA_CONFTEST_H
#define NVIDIA_CONFTEST_H 1
/* Minimal stub: extend with defines only if build errors name them. */
#endif
