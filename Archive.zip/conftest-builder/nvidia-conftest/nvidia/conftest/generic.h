#define NV_IS_EXPORT_SYMBOL_PRESENT_drm_gem_prime_fd_to_handle 1
#define NV_IS_EXPORT_SYMBOL_PRESENT_drm_gem_prime_handle_to_fd 1
// Kernel version:             "5.15.148-tegra"
