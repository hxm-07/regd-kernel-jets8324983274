#undef NV_DRM_DISPLAY_DRM_DP_AUX_BUS_H_PRESENT
#undef NV_DRM_DISPLAY_DRM_DP_HELPER_H_PRESENT
#undef NV_DRM_DISPLAY_DRM_SCDC_HELPER_H_PRESENT
#undef NV_DRM_DP_DRM_DP_AUX_BUS_H_PRESENT
#undef NV_DRM_DP_DRM_DP_HELPER_H_PRESENT
#define NV_DRM_DRM_DP_AUX_BUS_H_PRESENT
#undef NV_DRM_DRM_ELD_H_PRESENT
#define NV_GENERATED_AUTOCONF_H_PRESENT
#define NV_LINUX_KCONFIG_H_PRESENT
#define NV_LINUX_IOSYS_MAP_H_PRESENT
#undef NV_NET_GSO_H_PRESENT
#define NV_NET_PAGE_POOL_H_PRESENT
#undef NV_UFS_UFSHCD_H_PRESENT
// Kernel version:             "5.15.148-tegra"
#undef NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#undef NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#undef NV_TEGRA_PLATFORM_HELPERS_PRESENT
#undef NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#undef NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#undef NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
#undef NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#undef NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#undef NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
#undef NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#undef NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#undef NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
#define NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#define NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#define NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
#define NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#define NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#define NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
#define NV_TEGRA_PLATFORM_IS_SILICON_PRESENT
#define NV_LINUX_SOC_DEVICE_MATCH_PRESENT
#define NV_TEGRA_PLATFORM_HELPERS_PRESENT
#if defined(NV_TEGRA_PLATFORM_HELPERS_PRESENT) && defined(NV_LINUX_SOC_DEVICE_MATCH_PRESENT)
#define NVGPU_HAS_KERNEL_SOC_HELPERS 1
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon
#define nvgpu_platform_is_vdk      tegra_platform_is_vdk
#define nvgpu_platform_is_fpga     tegra_platform_is_fpga
#endif
