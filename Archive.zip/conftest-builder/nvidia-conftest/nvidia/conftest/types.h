#define NV_REQUEST_STRUCT_HAS_COMPLETION_DATA_ARG
// Kernel version:             "5.15.148-tegra"
