#include <linux/module.h>
#include <linux/sys_soc.h>
static const struct soc_device_attribute match[] = { { .machine = "tegra" }, { } };
int init_module(void) { return 0; }
void cleanup_module(void) { }
int test(void) { return soc_device_match(match) ? 0 : 0; }
