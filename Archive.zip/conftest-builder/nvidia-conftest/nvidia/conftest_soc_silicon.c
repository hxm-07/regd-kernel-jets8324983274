#include <linux/module.h>
#include <soc/tegra/common.h>
extern bool tegra_platform_is_silicon(void);
int init_module(void) { return 0; }
void cleanup_module(void) { }
int test(void) { return tegra_platform_is_silicon() ? 0 : 0; }
