#!/bin/bash
# fix-bridge-config-override.sh
# Fix CONFIG_BRIDGE being overridden from =y to =m during kernel build
# 
# PROBLEM: make modules_prepare converts CONFIG_BRIDGE=y to CONFIG_BRIDGE=m
# SOLUTION: Force the correct values after modules_prepare but before main build

set -e

echo "=== FIXING BRIDGE CONFIG OVERRIDE ISSUE ==="

# Check if we're in the right directory
if [ ! -f "build/.config" ]; then
    echo "ERROR: Must be run from kernel build workspace (build/.config not found)"
    exit 1
fi

echo "1. Backing up current .config"
cp build/.config build/.config.backup-$(date +%Y%m%d_%H%M%S)

echo "2. Restoring correct config from files01"
cp /home/ansible/files01/.config-5aug build/.config

echo "3. Checking what auto.conf currently has:"
if [ -f "build/include/config/auto.conf" ]; then
    echo "Current auto.conf BRIDGE settings:"
    grep 'CONFIG_BRIDGE' build/include/config/auto.conf || echo "No BRIDGE configs found"
else
    echo "auto.conf not found (normal after modules_prepare)"
fi

echo "4. Forcing correct CONFIG_BRIDGE values in auto.conf"
mkdir -p build/include/config
mkdir -p build/include/generated

# Create/update auto.conf with correct values
if [ -f "build/include/config/auto.conf" ]; then
    # Remove existing BRIDGE configs
    sed -i '/^CONFIG_BRIDGE/d' build/include/config/auto.conf
fi

# Add correct BRIDGE configs to auto.conf
cat >> build/include/config/auto.conf << 'EOF'
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_BRIDGE_IGMP_SNOOPING=y
CONFIG_BRIDGE_VLAN_FILTERING=y
CONFIG_BRIDGE_NF_EBTABLES=m
EOF

echo "5. Creating/updating autoconf.h with correct defines"
if [ -f "build/include/generated/autoconf.h" ]; then
    # Remove existing BRIDGE defines
    sed -i '/^#.*CONFIG_BRIDGE/d' build/include/generated/autoconf.h
fi

# Add correct BRIDGE defines to autoconf.h
cat >> build/include/generated/autoconf.h << 'EOF'
#define CONFIG_BRIDGE 1
#define CONFIG_BRIDGE_NETFILTER 1
#define CONFIG_BRIDGE_IGMP_SNOOPING 1
#define CONFIG_BRIDGE_VLAN_FILTERING 1
#define CONFIG_BRIDGE_NF_EBTABLES_MODULE 1
EOF

echo "6. Verifying the fix:"
echo "auto.conf now has:"
grep 'CONFIG_BRIDGE' build/include/config/auto.conf

echo "autoconf.h now has:"
grep 'CONFIG_BRIDGE' build/include/generated/autoconf.h

echo "✅ Bridge config override fix applied!"
echo ""
echo "USAGE INSTRUCTIONS:"
echo "Run this script AFTER 'make modules_prepare' but BEFORE main kernel build"
echo "This ensures bridge is built-in (=y) instead of as modules (=m)"