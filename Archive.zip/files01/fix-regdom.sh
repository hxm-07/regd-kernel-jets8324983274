#!/bin/bash
sed -i '/^static const struct ieee80211_regdomain world_regdom = {/,/^};/{
    /^static const struct ieee80211_regdomain world_regdom = {/!{
        /^};/!d
    }
}' net/wireless/reg.c

sed -i '/static const struct ieee80211_regdomain world_regdom = {/,/^};/c\
        static const struct ieee80211_regdomain world_regdom = {\
        \t.n_reg_rules = 2,\
        \t.alpha2 = "00",\
        \t.reg_rules = {\
        \t\t/* 2.4 GHz: 2392-2494 MHz @ 40MHz, 30dBm */\
        \t\tREG_RULE(2392, 2494, 40, 0, 30, 0),\
        \t\t/* 5 GHz: 5140-5960 MHz @ 160MHz, 30dBm */\
        \t\tREG_RULE(5140, 5960, 160, 0, 30, 0),\
        \t}\
};' net/wireless/reg.c
