/*
 * nvidia_oot_stubs.c - Temporary stubs for nvidia-oot symbols
 * 
 * Provides minimal implementations of nvidia-oot symbols when OOT modules
 * are not built. These stubs are automatically disabled when real providers
 * are detected via NVIDIA_OOT_PROVIDERS_PRESENT macro.
 * 
 * TODO: Remove once A-prime (KBUILD_EXTRA_SYMBOLS) approach is enabled.
 */
#ifndef NVIDIA_OOT_PROVIDERS_PRESENT
#include <linux/device.h>
#include <linux/export.h>

/* Include headers for function prototypes to satisfy -Werror=missing-prototypes */
#include <linux/platform/tegra/mc_utils.h>   /* prototype for emc_freq_to_bw */
#include <linux/platform/tegra/common.h>     /* extern struct device tegra_vpr_dev */

/* Conservative bandwidth fallback for EMC frequency-to-bandwidth conversion
 * NOTE: Real implementation in nvidia-oot/drivers/platform/tegra/mc-utils/mc-utils.c
 * uses platform-specific lookup tables. This fallback uses a 2x multiplier
 * for conservative bandwidth estimation.
 */
unsigned long emc_freq_to_bw(unsigned long freq)
{
    /* Conservative estimate: freq * 2 for bandwidth headroom */
    return freq << 1;
}
EXPORT_SYMBOL(emc_freq_to_bw);

/* Minimal VPR (Video Protect Region) device stub
 * NOTE: Real implementation in nvidia-oot/drivers/video/tegra/nvmap/nvmap_ioctl.c
 * provides full VPR memory management. This stub provides minimal device
 * structure for basic compatibility.
 */
struct device tegra_vpr_dev = {
    .init_name = "tegra-vpr-stub",
};
EXPORT_SYMBOL(tegra_vpr_dev);

#endif /* !NVIDIA_OOT_PROVIDERS_PRESENT */