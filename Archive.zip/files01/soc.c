/*
 * Copyright (c) 2017-2022, NVIDIA CORPORATION.  All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */

#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)
#include <soc/tegra/chip-id.h>
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
#include <soc/tegra/fuse.h>
#else
#include <soc/tegra/virt/hv-ivc.h>
#include <soc/tegra/fuse-helper.h>
#endif
#include <soc/tegra/virt/syscalls.h>
#include <nvgpu/ipa_pa_cache.h>

#include <nvgpu/soc.h>
#include "os_linux.h"
#include "platform_gk20a.h"

/* When kernel SOC helpers exist, conftest defines NVGPU_HAS_KERNEL_SOC_HELPERS
 * and maps nvgpu_platform_* to tegra_platform_* via headers.h.
 * In that case, do not emit duplicate function definitions here.
 */
#ifndef NVGPU_HAS_KERNEL_SOC_HELPERS
/* Wrapper functions only defined if kernel helpers do not exist */

bool nvgpu_platform_is_silicon(struct gk20a *g)
{
	return tegra_platform_is_silicon();
}

bool nvgpu_platform_is_simulation(struct gk20a *g)
{
	return tegra_platform_is_vdk();
}

bool nvgpu_platform_is_fpga(struct gk20a *g)
{
	return tegra_platform_is_fpga();
}

bool nvgpu_is_hypervisor_mode(struct gk20a *g)
{
	return is_tegra_hypervisor_mode();
}

bool nvgpu_is_soc_t194_a01(struct gk20a *g)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
	struct device *dev = dev_from_gk20a(g);
	struct gk20a_platform *platform = gk20a_get_platform(dev);
	return ((platform->platform_chip_id == TEGRA_194 &&
			tegra_chip_get_revision() == TEGRA_REVISION_A01) ?
			true : false);
#else
	const struct soc_device_attribute tegra_soc_attrs[] = {
		{
			.soc_id = "TEGRA194",
			.revision = "*A01*"
		},
		{/* sentinel */}
	};
	if (soc_device_match(tegra_soc_attrs)) {
		return true;
	}
	return false;
#endif
}

int nvgpu_init_soc_vars(struct gk20a *g)
{
	struct device *dev = dev_from_gk20a(g);
	struct gk20a_platform *platform = gk20a_get_platform(dev);
	int err;

	if (nvgpu_is_hypervisor_mode(g)) {
		err = hyp_read_gid(&platform->vmid);
		if (err) {
			nvgpu_err(g, "failed to read vmid");
			return err;
		}
		platform->phys_addr = nvgpu_tegra_hv_ipa_pa;
	}
	return 0;
}

#endif /* NVGPU_HAS_KERNEL_SOC_HELPERS */

/* This function is always needed regardless of kernel helper availability */
u64 nvgpu_get_pa_from_ipa(struct gk20a *g, u64 ipa)
{
	struct device *dev = dev_from_gk20a(g);
	struct gk20a_platform *platform = gk20a_get_platform(dev);
	u64 pa_len = 0U;

	if (platform->phys_addr) {
		return platform->phys_addr(g, ipa, &pa_len);
	}
	return ipa;
}
