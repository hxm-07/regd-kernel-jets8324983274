#!/bin/bash

# SPDX-FileCopyrightText: Copyright (c) 2012-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


#
# This script sync's NVIDIA's version of
# 1. the kernel source
# from nv-tegra, NVIDIA's public git repository.
# The script also provides opportunities to the sync to a specific tag
# so that the binaries shipped with a release can be replicated.
#
# Usage:
# By default it will download all the listed sources
# ./source_sync.sh
# Use the -t <TAG> option to provide the TAG to be used to sync all the sources.
# Use the -k <TAG> option to download only the kernel and device tree repos and optionally sync to TAG
# For detailed usage information run with -h option.
#


# verify that git is installed
if  ! which git > /dev/null  ; then
  echo "ERROR: git is not installed. If your linux distro is 10.04 or later,"
  echo "git can be installed by 'sudo apt-get install git-core'."
  exit 1
fi

# source dir
LDK_DIR=$(cd $(dirname $0) && pwd)
# script name
SCRIPT_NAME=$(basename $0)

# PATCHED: Modified SOURCE_INFO to use flattened paths
# The format is: type:flattened_path:repository:
SOURCE_INFO="
k:kernel-jammy-src:nv-tegra.nvidia.com/3rdparty/canonical/linux-jammy.git:
k:nvgpu:nv-tegra.nvidia.com/linux-nvgpu.git:
k:nvidia-oot:nv-tegra.nvidia.com/linux-nv-oot.git:
k:hwpm:nv-tegra.nvidia.com/linux-hwpm.git:
k:nvethernetrm:nv-tegra.nvidia.com/kernel/nvethernetrm.git:
k:kernel-devicetree:nv-tegra.nvidia.com/linux/kernel-devicetree.git:
k:hardware/t23x-nv-public:nv-tegra.nvidia.com/device/hardware/nvidia/t23x-public-dts.git:
k:hardware/tegra-nv-public:nv-tegra.nvidia.com/device/hardware/nvidia/tegra-public-dts.git:
k:nvdisplay:nv-tegra.nvidia.com/tegra/kernel-src/nv-kernel-display-driver.git:
k:dtc-1.4.5:nv-tegra.nvidia.com/3rdparty/dtc-src/1.4.5.git:
o:tegra/argus-cam-libav/argus_cam_libavencoder:nv-tegra.nvidia.com/tegra/argus-cam-libav/argus_cam_libavencoder.git:
o:tegra/cuda-src/nvsample_cudaprocess:nv-tegra.nvidia.com/tegra/cuda-src/nvsample_cudaprocess.git:
o:tegra/gfx-src/nv-xconfig:nv-tegra.nvidia.com/tegra/gfx-src/nv-xconfig.git:
o:tegra/gst-src/gst-egl:nv-tegra.nvidia.com/tegra/gst-src/gst-egl.git:
o:tegra/gst-src/gst-jpeg:nv-tegra.nvidia.com/tegra/gst-src/gst-jpeg.git:
o:tegra/gst-src/gst-nvarguscamera:nv-tegra.nvidia.com/tegra/gst-src/gst-nvarguscamera.git:
o:tegra/gst-src/gst-nvcompositor:nv-tegra.nvidia.com/tegra/gst-src/gst-nvcompositor.git:
o:tegra/gst-src/gst-nvtee:nv-tegra.nvidia.com/tegra/gst-src/gst-nvtee.git:
o:tegra/gst-src/gst-nvv4l2camera:nv-tegra.nvidia.com/tegra/gst-src/gst-nvv4l2camera.git:
o:tegra/gst-src/gst-nvvidconv:nv-tegra.nvidia.com/tegra/gst-src/gst-nvvidconv.git:
o:tegra/gst-src/gst-nvvideo4linux2:nv-tegra.nvidia.com/tegra/gst-src/gst-nvvideo4linux2.git:
o:tegra/gst-src/nvgstapps:nv-tegra.nvidia.com/tegra/gst-src/nvgstapps.git:
o:tegra/gst-src/libgstnvcustomhelper:nv-tegra.nvidia.com/tegra/gst-src/libgstnvcustomhelper.git:
o:tegra/gst-src/libgstnvdrmvideosink:nv-tegra.nvidia.com/tegra/gst-src/libgstnvdrmvideosink.git:
o:tegra/gst-src/libgstnvvideosinks:nv-tegra.nvidia.com/tegra/gst-src/libgstnvvideosinks.git:
o:tegra/gst-src/opencv_gst_samples:nv-tegra.nvidia.com/tegra/gst-src/opencv_gst_samples.git:
o:tegra/v4l2-src/libv4l2_nvargus:nv-tegra.nvidia.com/tegra/v4l2-src/libv4l2_nvargus.git:
o:tegra/nv-sci-src/nvsci_headers:nv-tegra.nvidia.com/tegra/nv-sci-src/nvsci_headers.git:
o:tegra/nv-sci-src/nvsci_samples:nv-tegra.nvidia.com/tegra/nv-sci-src/nvsci_samples.git:
o:tegra/openwfd-src/openwfd_headers:nv-tegra.nvidia.com/tegra/openwfd-src/openwfd_headers.git:
o:tegra/optee-src/atf:nv-tegra.nvidia.com/tegra/optee-src/atf.git:
o:tegra/optee-src/nv-optee:nv-tegra.nvidia.com/tegra/optee-src/nv-optee.git:
o:tegra/spe-src/spe-freertos-bsp:nv-tegra.nvidia.com/tegra/spe-src/spe-freertos-bsp.git:
o:tegra/v4l2-src/v4l2_libs:nv-tegra.nvidia.com/tegra/v4l2-src/v4l2_libs.git:
"

# exit on error on sync
EOE=0
# after processing SOURCE_INFO
NSOURCES=0
declare -a SOURCE_INFO_PROCESSED
# download all?
DALL=1
# PATCHED: Add flag to control .git removal
REMOVE_GIT_DIRS=${REMOVE_GIT_DIRS:-1}

function Usages {
	local ScriptName=$1
	local LINE
	local OP
	local DESC
	local PROCESSED=()
	local i

	echo "Use: $1 [options]"
	echo "Available general options are,"
	echo "     -h     :     help"
	echo "     -e     : exit on sync error"
	echo "     -d [DIR] : root of source is DIR"
	echo "     -t [TAG] : Git tag that will be used to sync all the sources"
	echo "     -g     : Keep .git directories (default: remove them)"
	echo ""
	echo "By default, all sources are downloaded."
	echo "Only specified sources are downloaded, if one or more of the following options are mentioned."
	echo ""
	echo "$SOURCE_INFO" | while read LINE; do
		if [ ! -z "$LINE" ]; then
			OP=$(echo "$LINE" | cut -f 1 -d ':')
			DESC=$(echo "$LINE" | cut -f 2 -d ':')
			if [[ ! " ${PROCESSED[@]} " =~ " ${OP} " ]]; then
				echo "     -${OP} [TAG]: Download $DESC source and optionally sync to TAG"
				PROCESSED+=("${OP}")
			else
				echo "           and download $DESC source and sync to the same TAG"
			fi
		fi
	done
	echo ""
}

function ProcessSwitch {
	local SWITCH="$1"
	local TAG="$2"
	local i
	local found=0

	for ((i=0; i < NSOURCES; i++)); do
		local OP=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 1 -d ':')
		if [ "-${OP}" == "$SWITCH" ]; then
			SOURCE_INFO_PROCESSED[i]="${SOURCE_INFO_PROCESSED[i]}${TAG}:y"
			DALL=0
			found=1
		fi
	done

	if [ "$found" == 1 ]; then
		return 0
	fi

	echo "Terminating... wrong switch: ${SWITCH}" >&2
	Usages "$SCRIPT_NAME"
	exit 1
}

function UpdateTags {
	local SWITCH="$1"
	local TAG="$2"
	local i

	for ((i=0; i < NSOURCES; i++)); do
		local OP=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 1 -d ':')
		if [ "${OP}" == "$SWITCH" ]; then
			SOURCE_INFO_PROCESSED[i]=$(echo "${SOURCE_INFO_PROCESSED[i]}" \
				| awk -F: -v OFS=: -v var="${TAG}" '{$4=var; print}')
		fi
	done
}

function DownloadAndSync {
	local WHAT_SOURCE="$1"
	local LDK_SOURCE_DIR="$2"
	local REPO_URL="$3"
	local TAG="$4"
	local OPT="$5"
	local RET=0

	echo "[INFO] Processing: $WHAT_SOURCE"
	echo "[INFO] Destination: $LDK_SOURCE_DIR"
	echo "[INFO] Repository: $REPO_URL"
	echo "[INFO] Tag: ${TAG:-'(none specified)'}"

	if [ -d "${LDK_SOURCE_DIR}" ]; then
		echo "[INFO] Directory for $WHAT_SOURCE already exists at ${LDK_SOURCE_DIR}"
		pushd "${LDK_SOURCE_DIR}" > /dev/null
		git status 2>&1 >/dev/null
		if [ $? -ne 0 ]; then
			echo "[ERROR] Directory exists but is not a git repository!"
			echo "[FIX] Clean it up first: rm -rf ${LDK_SOURCE_DIR}"
			popd > /dev/null
			return 1
		fi
		echo "[INFO] Fetching all tags and branches..."
		git fetch --all --tags 2>&1 >/dev/null
		if [ $? -ne 0 ]; then
			echo "[WARNING] Git fetch failed, continuing anyway..."
		fi
		popd > /dev/null
	else
		echo "[INFO] Cloning $WHAT_SOURCE repository..."
		# Create parent directories if needed
		mkdir -p "$(dirname "${LDK_SOURCE_DIR}")"
		
		git clone "$REPO_URL" -n "${LDK_SOURCE_DIR}" 2>&1 >/dev/null
		if [ $? -ne 0 ]; then
			echo "[ERROR] Failed to clone $WHAT_SOURCE!"
			echo "[ERROR] Repository: $REPO_URL"
			echo "[ERROR] Destination: ${LDK_SOURCE_DIR}"
			return 1
		fi

		echo "[SUCCESS] Cloned $WHAT_SOURCE to: ${LDK_SOURCE_DIR}"
	fi

	if [ -z "$TAG" ]; then
		echo "[PROMPT] Please enter a tag to sync $WHAT_SOURCE to"
		echo -n "(enter nothing to skip): "
		read TAG
		TAG=$(echo $TAG)
		UpdateTags $OPT $TAG
	fi

	if [ ! -z "$TAG" ]; then
		pushd ${LDK_SOURCE_DIR} > /dev/null
		
		# PATCHED: Enhanced tag verification with fallback patterns
		echo "[INFO] Looking for tag '$TAG'..."
		
		# Try exact tag first
		ACTUAL_TAG=""
		if git rev-parse "$TAG" >/dev/null 2>&1; then
			ACTUAL_TAG="$TAG"
		else
			# Try alternative tag patterns
			echo "[INFO] Exact tag not found, trying alternative patterns..."
			
			# If user specified tegra-l4t-r36.4.4, try jetson_36.4.4
			if [[ "$TAG" =~ tegra-l4t-r([0-9]+\.[0-9]+\.[0-9]+) ]]; then
				ALT_TAG="jetson_${BASH_REMATCH[1]}"
				echo "[INFO] Trying alternative: $ALT_TAG"
				if git rev-parse "$ALT_TAG" >/dev/null 2>&1; then
					ACTUAL_TAG="$ALT_TAG"
					echo "[INFO] Found tag as: $ALT_TAG"
				fi
			fi
			
			# If still not found, look for closest match
			if [ -z "$ACTUAL_TAG" ]; then
				# Extract version numbers from requested tag
				if [[ "$TAG" =~ ([0-9]+\.[0-9]+) ]]; then
					VERSION_PATTERN="${BASH_REMATCH[1]}"
					echo "[INFO] Looking for tags matching version $VERSION_PATTERN..."
					
					# Find the latest matching tag
					MATCHING_TAGS=$(git tag -l | grep -E "(jetson_|l4t-.*r)${VERSION_PATTERN}" | sort -V | tail -1)
					if [ ! -z "$MATCHING_TAGS" ]; then
						ACTUAL_TAG="$MATCHING_TAGS"
						echo "[WARNING] Using closest match: $ACTUAL_TAG"
					fi
				fi
			fi
		fi
		
		if [ -z "$ACTUAL_TAG" ]; then
			echo "[ERROR] No suitable tag found for '$TAG' in $WHAT_SOURCE!"
			echo "[INFO] Available tags containing '36':"
			git tag -l | grep "36" | head -20
			echo "[INFO] All available tags (first 10):"
			git tag -l | head -10
			echo "[FIX] Try one of the tags above or run: git -C ${LDK_SOURCE_DIR} fetch --tags"
			popd > /dev/null
			return 1
		fi
		
		echo "[INFO] Checking out tag $ACTUAL_TAG..."
		git checkout -b "mybranch_$(date +%Y-%m-%d-%s)" "$ACTUAL_TAG" 2>&1 >/dev/null
		if [ $? -eq 0 ]; then
			echo "[SUCCESS] $WHAT_SOURCE synced to tag $ACTUAL_TAG"
			
			# PATCHED: Remove .git directory after successful checkout
			if [ "$REMOVE_GIT_DIRS" == "1" ]; then
				echo "[INFO] Removing .git directory to prevent kernel -dirty suffix..."
				rm -rf .git
			fi
		else
			echo "[ERROR] Failed to checkout tag $ACTUAL_TAG!"
			RET=1
		fi
		popd > /dev/null
	else
		echo "[INFO] No tag specified, skipping checkout for $WHAT_SOURCE"
	fi
	
	echo ""
	return "$RET"
}

# PATCHED: Verify SRC environment variable is set
if [ -z "$SRC" ]; then
	echo "[ERROR] SRC environment variable is not set!"
	echo "[FIX] Export SRC before running this script:"
	echo "      export SRC=/path/to/Linux_for_Tegra/source"
	exit 1
fi

# Use SRC as the base directory if provided
if [ ! -z "$SRC" ]; then
	LDK_DIR="$SRC"
fi

# prepare processing ....
GETOPT=":eghd:t:"

OIFS="$IFS"
IFS=$(echo -en "\n\b")
SOURCE_INFO_PROCESSED=($(echo "$SOURCE_INFO"))
IFS="$OIFS"
NSOURCES=${#SOURCE_INFO_PROCESSED[*]}

for ((i=0; i < NSOURCES; i++)); do
	OP=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 1 -d ':')
	GETOPT="${GETOPT}${OP}:"
done

# parse the command line first
while getopts "$GETOPT" opt; do
	case $opt in
		d)
			case $OPTARG in
				-[A-Za-z]*)
					Usages "$SCRIPT_NAME"
					exit 1
					;;
				*)
					LDK_DIR="$OPTARG"
					;;
			esac
			;;
		e)
			EOE=1
			;;
		g)
			REMOVE_GIT_DIRS=0
			;;
		h)
			Usages "$SCRIPT_NAME"
			exit 1
			;;
		t)
			TAG="$OPTARG"
			PROCESSED=()
			for ((i=0; i < NSOURCES; i++)); do
				OP=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 1 -d ':')
				if [[ ! " ${PROCESSED[@]} " =~ " ${OP} " ]]; then
					UpdateTags $OP $TAG
					PROCESSED+=("${OP}")
				fi
			done
			;;
		[A-Za-z])
			case $OPTARG in
				-[A-Za-z]*)
					eval arg=\$$((OPTIND-1))
					case $arg in
						-[A-Za-Z]-*)
							Usages "$SCRIPT_NAME"
							exit 1
							;;
						*)
							ProcessSwitch "-$opt" ""
							OPTIND=$((OPTIND-1))
							;;
					esac
					;;
				*)
					ProcessSwitch "-$opt" "$OPTARG"
					;;
			esac
			;;
		:)
			case $OPTARG in
				#required arguments
				d)
					Usages "$SCRIPT_NAME"
					exit 1
					;;
				#optional arguments
				[A-Za-z])
					ProcessSwitch "-$OPTARG" ""
					;;
			esac
			;;
		\?)
			echo "Terminating... wrong switch: $@" >&2
			Usages "$SCRIPT_NAME"
			exit 1
			;;
	esac
done
shift $((OPTIND-1))

echo "[INFO] Starting source sync process..."
echo "[INFO] Base directory: $LDK_DIR"
echo ""

GRET=0
for ((i=0; i < NSOURCES; i++)); do
	OPT=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 1 -d ':')
	WHAT=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 2 -d ':')
	REPO=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 3 -d ':')
	TAG=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 4 -d ':')
	DNLOAD=$(echo "${SOURCE_INFO_PROCESSED[i]}" | cut -f 5 -d ':')

	if [ $DALL -eq 1 -o "${DNLOAD}" = "y" ]; then
		DownloadAndSync "$WHAT" "${LDK_DIR}/${WHAT}" "git://${REPO}" "${TAG}" "${OPT}"
		tRET=$?
		let GRET=GRET+tRET
		if [ $tRET -ne 0 -a $EOE -eq 1 ]; then
			echo "[ERROR] Exiting due to error (exit on error is enabled)"
			exit $tRET
		fi
	fi
done

# PATCHED: Update symlink path for flattened structure
NVETHERNET_PATH="${LDK_DIR}/nvidia-oot/drivers/net/ethernet/nvidia/nvethernet"
if [ -d "$(dirname "${NVETHERNET_PATH}")" ]; then
	echo "[INFO] Creating nvethernetrm symlink..."
	mkdir -p "$(dirname "${NVETHERNET_PATH}")"
	ln -sf ../../../../../../nvethernetrm "${NVETHERNET_PATH}/nvethernetrm"
fi

# PATCHED: Validation checks
echo ""
echo "[INFO] Running post-sync validation..."

# Check critical kernel files exist in the correct location
if [ -f "${LDK_DIR}/kernel-jammy-src/Makefile" ]; then
	echo "[SUCCESS] kernel-jammy-src/Makefile found (flattened structure confirmed)"
	MAKEFILE_SIZE=$(stat -c%s "${LDK_DIR}/kernel-jammy-src/Makefile" 2>/dev/null || echo "0")
	echo "[INFO] Makefile size: $MAKEFILE_SIZE bytes"
else
	echo "[ERROR] kernel-jammy-src/Makefile not found at expected location!"
	echo "[ERROR] This indicates the directory structure is not flattened correctly"
fi

if [ -f "${LDK_DIR}/kernel-jammy-src/init/main.c" ]; then
	echo "[SUCCESS] kernel-jammy-src/init/main.c found"
else
	echo "[WARNING] kernel-jammy-src/init/main.c not found"
fi

echo ""
if [ $GRET -eq 0 ]; then
	echo "[SUCCESS] All sources synced successfully!"
else
	echo "[WARNING] Some sources had issues during sync (errors: $GRET)"
fi

exit $GRET