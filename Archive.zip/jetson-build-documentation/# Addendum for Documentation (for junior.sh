# Addendum for Documentation (for junior dev)

Correction Plan (Single Source of Truth)
🔒 RULE:
You MUST define and cd into a fresh $WORK each time. Never re-use stale paths.

Clean Start — Destructive Reset
1. Wipe corrupted workspace:
bash
Copy
rm -rf /home/ansible/jetson-nvgpu-20250808_*
2. Begin New Run:
bash
Copy
export WORK=/home/ansible/jetson-nvgpu-$(date +%Y%m%d_%H%M%S)
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src
export KBUILD=$SRC/build
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$WORK" "$SRC"
cd "$WORK"
3. Extraction (Corrected + Tracked)
bash
Copy
tar -xf /home/ansible/jetson-r3644-full/Jetson_Linux_R36.4.4_aarch64.tbz2 -C "$WORK"
tar -xf /home/ansible/jetson-r3644-full/public_sources.tbz2 -C "$SRC"
mkdir -p "$SRC/kernel" "$SRC/kernel/nvidia"
tar -xf "$SRC/kernel_src.tbz2" -C "$SRC/kernel"
tar -xf "$SRC/kernel_oot_modules_src.tbz2" -C "$SRC/kernel/nvidia"


## Root Cause

Wrong extraction target. You ran:

```bash
tar -xf public_sources.tbz2 -C "$WORK"
```

Expected:

```bash
tar -xf public_sources.tbz2 -C "$SRC"
```

You set `SRC=$WORK/Linux_for_Tegra/source`, but extracted **into `$WORK`**, not `$SRC`. Result: double-nested tree:

```
$SRC/kernel/kernel/kernel-jammy-src
         ^^^^^^^—wrong
```

---

## RCA: Reconstructing the Failure Chain

| Step | Command                                           | Issue                                 | Correction                               |
| ---- | ------------------------------------------------- | ------------------------------------- | ---------------------------------------- |
| 1    | `mkdir -p "$SRC/kernel"`                          | ✅                                     | Correct                                  |
| 2    | `tar -xf public_sources.tbz2 -C "$WORK"`          | ❌                                     | Should have been `-C "$SRC"`             |
| 3    | `tar -xf "$SRC/kernel_src.tbz2" -C "$SRC/kernel"` | ✅                                     | But tree already malformed               |
| 4    | Result:                                           | `$SRC/kernel/kernel/kernel-jammy-src` | Should be `$SRC/kernel/kernel-jammy-src` |

---

## Required Cleanup and Restart

### Phase 0 — Set Environment Again

```bash
export WORK=/home/ansible/jetson-nvgpu-$(date +%Y%m%d_%H%M%S)
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src
export KBUILD=$SRC/build
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
```

### Phase 1 — Extraction (Corrected)

```bash
mkdir -p "$WORK"
tar -xf /home/ansible/jetson-r3644-full/Jetson_Linux_R36.4.4_aarch64.tbz2 -C "$WORK"
mkdir -p "$SRC"
tar -xf /home/ansible/jetson-r3644-full/public_sources.tbz2 -C "$SRC"
mkdir -p "$SRC/kernel" "$SRC/kernel/nvidia"
tar -xf "$SRC/kernel_src.tbz2" -C "$SRC/kernel"
tar -xf "$SRC/kernel_oot_modules_src.tbz2" -C "$SRC/kernel/nvidia"
```

### Phase 2 — Sanity Check (Mandatory Before Proceeding)

```bash
test -f "$KSRC/init/main.c"
stat -c%s "$KSRC/Makefile"   # must be 67315
```

If both pass, proceed to patching and config.

---

## Addendum for Documentation (for junior dev)

### Wrong Command:

```bash
tar -xf public_sources.tbz2 -C "$WORK"
```

### Correct Command:

```bash
tar -xf public_sources.tbz2 -C "$SRC"
```

### Effect of Mistake:

Created invalid kernel root at:

```
$SRC/kernel/kernel/kernel-jammy-src
```

which breaks all paths, leads to missing Makefile, and fails `make` operations.

---

Re-extract now using corrected flow above. Confirm `$KSRC` Makefile is present and exactly 67315 bytes before proceeding.
