# What actually went wrong (final RCA)

## 1) We kept pointing at the **wrapper** sometimes, not the **kernel root**

* There are two Makefiles in play:

  * **Wrapper**: `$SRC/kernel/Makefile` (\~3.6 KB). It’s not a real kernel top. Targets like `olddefconfig`, `modules_prepare` may not exist or behave differently.
  * **Kernel top**: `$SRC/kernel/kernel-jammy-src/Makefile` (**67,315 bytes** in your tree). This *is* the real kernel.
* Early failures like:

  * `No rule to make target 'modules_prepare'`
  * `olddefconfig` not found
    were because we were calling `make` in/through the wrapper path.
* **Now** your `find` shows `init/main.c` lives under `$SRC/kernel/kernel-jammy-src/init` and the Makefile is 67,315 bytes—this confirms `KSRC="$SRC/kernel/kernel-jammy-src"` is correct.

## 2) Expecting `auto.conf` after `prepare` (wrong target order)

* `auto.conf` and `autoconf.h` are produced by the **Kconfig** pass, not by `prepare`.
* We did:

  * copy `.config` → ✅
  * `make ... prepare` → this builds `asm-offsets`, VDSO, etc.
  * **But we skipped `olddefconfig`/`syncconfig`/`modules_prepare`** at the correct tree.
* Result: `$KBUILD/include/config/auto.conf` was missing. That’s normal if you don’t run a config target.

**Correct sequence (real kernel top):**

```
make -C "$KSRC" O="$KBUILD" ARCH="$ARCH" olddefconfig   # or syncconfig
make -C "$KSRC" O="$KBUILD" ARCH="$ARCH" modules_prepare
```

After that, `auto.conf` + `autoconf.h` appear under `$KBUILD/include/...`.

## 3) Nested extraction and path drift created “ghost” states

* We had nested `Linux_for_Tegra/source/Linux_for_Tegra/source/*` after extracting `public_sources.tbz2` into `$SRC` (which already *was* `/.../Linux_for_Tegra/source`). That duplication is how the kernel tar ended up at `$SRC/Linux_for_Tegra/source/kernel_src.tbz2`.
* That nesting made us bounce between:

  * `$SRC/kernel/kernel-jammy-src` (correct), and
  * `$SRC/kernel/kernel/kernel-jammy-src` (wrong, extra `kernel/`).
* On top of that, multiple **monitor\_config.sh** processes and multiple **workspaces** were running concurrently and restoring configs in the wrong O= directory. Chaos multiplier.

## 4) `source_sync.sh` (nohup) + interactive prompts = stuck jobs

* You ran `source_sync.sh -e` **without** `-t` sometimes. The script then **prompts** for a tag. Under `nohup` there is no TTY, so it logged:

  ```
  read: read error: 0: Bad file descriptor
  ```
* When `-t tegra-l4t-r36.4.4` was used, kernel-jammy git sometimes failed with:

  ```
  fatal: could not open ... tmp_pack_XXXX for reading: No such file or directory
  fetch-pack: invalid index-pack output
  ```

  That’s typically a transient network/packfile/corruption issue during clone, sometimes exacerbated by concurrent deletes of `.git` or low disk.
* **Bottom line**: you don’t need `source_sync.sh` at all to build the kernel if you use **`kernel_src.tbz2` + `kernel_oot_modules_src.tbz2`**. It removes an entire failure domain.

---

# Why `auto.conf` was missing *this time*

You were finally in the **right kernel root** (good!), but you ran `prepare` instead of a **config** target. `prepare` doesn’t create `auto.conf`. Running `olddefconfig` (or `syncconfig`) + `modules_prepare` with `O=$KBUILD` generates it. That’s the whole story here.

---

# What I’d tell someone starting fresh with only the MD guide

## Pre-flight (do these or suffer)

1. **Single workspace** — don’t mix.
   Set once:

   ```
   export WORK=/home/ansible/jetson-nvgpu-<timestamp>
   export SRC=$WORK/Linux_for_Tegra/source
   export KSRC=$SRC/kernel/kernel-jammy-src
   export KBUILD=$SRC/build
   export ARCH=arm64
   export CROSS_COMPILE=aarch64-linux-gnu-
   ```
2. **Extract, don’t duplicate**

   * Extract `public_sources.tbz2` to `$WORK` (not to `$SRC`).
   * After extract, you should have **one** `Linux_for_Tegra/source/` tree.
   * Extract `kernel_src.tbz2` to `$SRC/kernel/` → creates `$SRC/kernel/kernel-jammy-src/`.
   * Extract `kernel_oot_modules_src.tbz2` to `$SRC/kernel/nvidia/` → creates `nvidia-oot`, `nvgpu`, `hwpm`, `nvethernetrm`, etc.
3. **Verify kernel top is real**

   ```
   test -f "$KSRC/init/main.c"
   stat -c%s "$KSRC/Makefile"   # should be “big”; your value was 67315 bytes
   ```

## Config/build (the only order that works)

1. Seed config:

   ```
   rm -rf "$KBUILD" && mkdir -p "$KBUILD"
   cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
   ```
2. **Generate auto.conf & autoconf.h**:

   ```
   make -C "$KSRC" ARCH="$ARCH" O="$KBUILD" olddefconfig
   make -C "$KSRC" ARCH="$ARCH" O="$KBUILD" modules_prepare
   ls -l "$KBUILD/include/config/auto.conf" "$KBUILD/include/generated/autoconf.h"
   ```
3. **Bridge override timing**
   Apply your bridge override script **immediately after `modules_prepare`** and **before** the main `Image modules dtbs` build.
4. **Only one** monitor\_config.sh process, pointed at the **exact** `$KBUILD` you’re using.

## Avoid this

* Don’t run `source_sync.sh` unless you really need upstream git. The tarballs already give you what you need. If you do run it, always pass `-t tegra-l4t-r36.4.4 -e` and don’t nohup it without `-t`.
* Don’t call `make` in `$SRC/kernel` (wrapper). Always in `$KSRC` (kernel-jammy-src).
* Don’t have multiple workspaces restoring different `$KBUILD/.config` in the background.

---

# Success odds (realistic)

* **Using only your MD guide as originally written:**
  **70–80%** on first run, because two steps were easy to misinterpret:

  * extracting `public_sources.tbz2` into `$SRC` (causes nested `Linux_for_Tegra/source`);
  * running `prepare` and expecting `auto.conf` (needs `olddefconfig`/`modules_prepare`).
* **With the small addendum above (clarifying extraction + the exact make targets):**
  **95%+**. The remaining 5% is network hiccups or local environment (disk, perms).

---

# What to do **right now** (to unstick)

You’ve confirmed the real kernel root:

```
/home/ansible/jetson-nvgpu-20250808_021801/Linux_for_Tegra/source/kernel/kernel-jammy-src
# Makefile size: 67315 bytes
```

Run these 4 lines exactly:

```bash
export KSRC="$SRC/kernel/kernel-jammy-src"
rm -rf "$KBUILD" && mkdir -p "$KBUILD"
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
make -C "$KSRC" ARCH="$ARCH" O="$KBUILD" olddefconfig && \
make -C "$KSRC" ARCH="$ARCH" O="$KBUILD" modules_prepare
```

Then verify:

```bash
ls -l "$KBUILD/include/config/auto.conf" "$KBUILD/include/generated/autoconf.h"
```

If those two files exist, we immediately apply the bridge override and kick off the main build.
