# Complete Commands Reference for Jetson Kernel Build

## Environment Setup Commands

### Initial Setup
```bash
# Create timestamped work directory
export TIMESTAMP=$(date +%Y%m%d_%H%M%S)
export WORK=$HOME/jetson-$TIMESTAMP
mkdir -p "$WORK"
cd "$WORK"

# Install required packages (Ubuntu 22.04)
sudo apt update
sudo apt install -y gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
sudo apt install -y build-essential bc bison flex libssl-dev libncurses5-dev
sudo apt install -y git wget curl rsync

# Set cross-compilation environment
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
```

### Build Path Variables
```bash
# Adjust WORK path to your actual directory
export WORK=$HOME/jetson-20250805_195319
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src    # R36.4.x uses jammy-src
export KBUILD=$SRC/build
export OOT=$SRC/nvidia-oot
export CONFTEST=$SRC/out/nvidia-conftest
```

### Verification Commands
```bash
# Verify toolchain
aarch64-linux-gnu-gcc --version
which aarch64-linux-gnu-gcc

# Verify environment
echo "ARCH = $ARCH"
echo "CROSS_COMPILE = $CROSS_COMPILE"
echo "WORK = $WORK"
echo "KSRC = $KSRC"

# Check available resources
free -h                    # RAM
df -h                      # Disk space
nproc                      # CPU cores
```

## Source Download and Extraction Commands

### Download Source Archives
```bash
# Navigate to NVIDIA Developer Portal
# https://developer.nvidia.com/jetson-linux-r3644
# Download these files:
# - Jetson_Linux_R36.4.4_aarch64.tbz2 (746MB)
# - public_sources.tbz2 (226MB)

# Verify file integrity
ls -la *.tbz2
# Expected output:
# -rw-rw-r-- 1 user user 746324969 Jetson_Linux_R36.4.4_aarch64.tbz2
# -rw-rw-r-- 1 user user 226164437 public_sources.tbz2
```

### Extract Archives (Order Critical!)
```bash
# Extract public sources FIRST
tar -xvf public_sources.tbz2

# Extract Jetson Linux SECOND (merges with above)
tar -xvf Jetson_Linux_R36.4.4_aarch64.tbz2

# Navigate to source directory
cd Linux_for_Tegra/source

# Extract kernel and OOT sources
tar -xvf kernel_src.tbz2
tar -xvf kernel_oot_modules_src.tbz2
```

### Get Real Kernel Source via Git
```bash
# Method 1: Interactive (press Enter for each prompt)
./source_sync.sh

# Method 2: Specify exact tag
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03

# Method 3: Manual git clone (if script fails)
cd kernel
rm -rf kernel-jammy-src
git clone https://nv-tegra.nvidia.com/3rdparty/canonical/linux-jammy.git kernel-jammy-src
cd kernel-jammy-src
git checkout l4t-l4t-r36.4.4_eng_2025-06-03
cd ../..
```

### Verify Source Structure
```bash
# Check kernel source
ls -la kernel/kernel-jammy-src/Makefile
ls -la kernel/kernel-jammy-src/arch/arm64/

# Check NVSCIIPC driver
ls -la nvidia-oot/drivers/misc/nvsciipc/

# Check git status
cd nvidia-oot && git branch && cd ..
```

## Configuration and Fixes Commands

### Apply Essential Fixes
```bash
# Fix 1: Crash kernel issue
cp /home/ansible/files01/init.c.adjusted \
   kernel/kernel-jammy-src/arch/arm64/mm/init.c

# Fix 2: Wireless regulatory issue
cp /home/ansible/files01/regd.c.modified \
   kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c

# Fix 3: Additional regulatory setup
cd kernel/kernel-jammy-src
/home/ansible/files01/fix-regdom.sh
cd ../..

# Verify fixes applied
ls -la kernel/kernel-jammy-src/arch/arm64/mm/init.c        # Should be 16505 bytes
ls -la kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c  # Should be 19637 bytes
```

### Setup Build Configuration
```bash
# Create build directory
mkdir -p "$KBUILD"

# Copy saved configuration
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Verify configuration
ls -la "$KBUILD/.config"                    # Should be 299360 bytes
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"  # Should show: CONFIG_TEGRA_OOT_MODULE=m
```

## Build Process Commands

### Phase 1: Kernel Preparation
```bash
# Prepare kernel build (WILL modify .config)
nohup make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  modules_prepare > "$KBUILD/modules_prepare.log" 2>&1 &

# Monitor preparation
tail -f "$KBUILD/modules_prepare.log"

# IMMEDIATELY restore config after completion
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
```

### Phase 2: Main Kernel Build
```bash
# Build kernel and in-tree modules (45-60 minutes)
nohup make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  -j$(nproc) > "$KBUILD/kernel_build.log" 2>&1 &

# Monitor build progress
tail -f "$KBUILD/kernel_build.log"

# Check build completion
ls -la "$KBUILD/arch/arm64/boot/Image"  # Should be ~46MB
```

### Phase 3: NVIDIA Conftest Setup
```bash
# Create conftest directories
mkdir -p "$CONFTEST/nvidia"

# Copy conftest files from OOT
cp -a "$OOT/scripts/conftest/"* "$CONFTEST/nvidia/"

# Run conftest to generate compatibility headers
make -f "$CONFTEST/nvidia/Makefile" \
     src="$CONFTEST/nvidia" obj="$CONFTEST/nvidia" \
     NV_KERNEL_SOURCES="$KSRC" NV_KERNEL_OUTPUT="$KBUILD" \
     ARCH=$ARCH -j$(nproc)

# Verify conftest headers
ls -la "$CONFTEST/nvidia/conftest/headers.h"  # Should exist
```

### Phase 4: NVIDIA OOT Modules Build
```bash
# Ensure config is intact before OOT build
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"

# Build all NVIDIA OOT modules including NVSCIIPC
nohup make -C "$KBUILD" \
     M="$OOT" \
     CONFIG_TEGRA_OOT_MODULE=m \
     srctree.nvidia-oot="$OOT" \
     srctree.nvconftest="$CONFTEST" \
     -j$(nproc) modules > "$KBUILD/oot_build.log" 2>&1 &

# Monitor OOT build
tail -f "$KBUILD/oot_build.log"
```

## Monitoring and Verification Commands

### Config File Monitoring
```bash
# Check config file size (should always be 299360)
stat -c%s "$KBUILD/.config"

# Check critical flag
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"

# Restore config if corrupted
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Continuous monitoring script
while true; do
  if [ $(stat -c%s "$KBUILD/.config" 2>/dev/null || echo "0") != "299360" ]; then
    echo "$(date): Config corrupted, restoring..."
    cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
  fi
  sleep 30
done
```

### Build Progress Monitoring
```bash
# Check running build processes
ps aux | grep make | grep -v grep

# Monitor specific build phases
tail -f "$KBUILD/modules_prepare.log"
tail -f "$KBUILD/kernel_build.log"
tail -f "$KBUILD/oot_build.log"

# Check for errors in logs
grep -i "error\|failed\|fatal" "$KBUILD"/*.log

# Monitor system resources during build
watch -n 5 'free -h && df -h'
```

### Build Results Verification
```bash
# Check kernel image
ls -la "$KBUILD/arch/arm64/boot/Image"       # Should be ~46MB

# Check NVSCIIPC compilation
find "$OOT" -name "*nvsciipc*" -type f
# Should show: nvsciipc.c, nvsciipc.h, nvsciipc.o

# Check all OOT modules built
find "$OOT" -name "*.ko" -type f | wc -l

# Check conftest headers
ls -la "$CONFTEST/nvidia/conftest/headers.h"
```

## Troubleshooting Commands

### Clean and Reset Commands
```bash
# Clean build artifacts
make -C "$KSRC" O="$KBUILD" clean

# Deep clean (removes config too)
make -C "$KSRC" O="$KBUILD" mrproper

# Remove and restart OOT build only
rm -rf "$KBUILD"/*.ko "$OOT"/*.ko "$OOT"/*/*.o
make -C "$KBUILD" M="$OOT" clean
```

### Diagnostic Commands
```bash
# Check toolchain
which aarch64-linux-gnu-gcc
aarch64-linux-gnu-gcc --version

# Check source integrity
ls -la "$KSRC/Makefile"                     # Should exist
find "$KSRC" -name "Kconfig" | wc -l       # Should be 100+

# Check git repository status
cd "$KSRC" && git status && git log --oneline -5

# Test network connectivity
ping -c 3 nv-tegra.nvidia.com
wget -O /dev/null --timeout=10 https://nv-tegra.nvidia.com/

# Check disk space
df -h "$WORK"
du -sh "$WORK"
```

### Recovery Commands
```bash
# Stop all builds
pkill -f "make.*$KBUILD"

# Complete environment reset
make -C "$KSRC" O="$KBUILD" mrproper
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Re-download corrupted sources
cd "$SRC"
rm -rf kernel/kernel-jammy-src nvidia-oot
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03

# Re-apply fixes after source recovery
cp /home/ansible/files01/init.c.adjusted kernel/kernel-jammy-src/arch/arm64/mm/init.c
cp /home/ansible/files01/regd.c.modified kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c
cd kernel/kernel-jammy-src && /home/ansible/files01/fix-regdom.sh && cd ../..
```

## Advanced Commands

### Build Specific Components Only
```bash
# Build only NVSCIIPC module
make -C "$KBUILD" M="$OOT/drivers/misc/nvsciipc" \
     CONFIG_TEGRA_OOT_MODULE=m \
     srctree.nvidia-oot="$OOT" \
     srctree.nvconftest="$CONFTEST" \
     modules

# Build only GPU modules
make -C "$KBUILD" M="$SRC/nvgpu" \
     CONFIG_TEGRA_OOT_MODULE=m \
     modules

# Build kernel with specific parallelism
make -C "$KSRC" O="$KBUILD" -j4  # Use 4 cores only
```

### Debugging Commands
```bash
# Verbose build output
make -C "$KSRC" O="$KBUILD" V=1 modules_prepare

# Check make variables
make -C "$KSRC" O="$KBUILD" -p | grep "^ARCH\|^CROSS_COMPILE"

# Test specific driver compilation
make -C "$KSRC" O="$KBUILD" M=drivers/misc/nvsciipc modules SUBDIRS=drivers/misc/nvsciipc

# Check symbol availability
grep -r "EXPORT_SYMBOL.*nvsciipc" "$KSRC"
```

### File Management Commands
```bash
# Create backup of working build
tar -czf jetson-build-backup-$(date +%Y%m%d).tar.gz "$WORK"

# Extract specific files from archives
tar -tf public_sources.tbz2 | grep nvsciipc
tar -xf kernel_oot_modules_src.tbz2 specific/path/file

# Compare configurations
diff /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Find large files consuming space
find "$WORK" -type f -size +100M -exec ls -lh {} \;
```

## Complete Build Script Example

```bash
#!/bin/bash
# Complete automated build script
# save as: build_jetson_kernel.sh

set -e  # Exit on any error

# Setup environment
export TIMESTAMP=$(date +%Y%m%d_%H%M%S)
export WORK=$HOME/jetson-$TIMESTAMP
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

echo "Starting Jetson kernel build at $(date)"
echo "Working directory: $WORK"

# Create work directory
mkdir -p "$WORK"
cd "$WORK"

# Extract sources (assumes archives are in current directory)
echo "Extracting sources..."
tar -xf public_sources.tbz2
tar -xf Jetson_Linux_R36.4.4_aarch64.tbz2

cd Linux_for_Tegra/source
tar -xf kernel_src.tbz2
tar -xf kernel_oot_modules_src.tbz2

# Setup paths
export SRC="$WORK/Linux_for_Tegra/source"
export KSRC="$SRC/kernel/kernel-jammy-src"
export KBUILD="$SRC/build"
export OOT="$SRC/nvidia-oot"
export CONFTEST="$SRC/out/nvidia-conftest"

# Download real kernel source
echo "Downloading kernel source..."
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03

# Apply fixes
echo "Applying fixes..."
cp /home/ansible/files01/init.c.adjusted "$KSRC/arch/arm64/mm/init.c"
cp /home/ansible/files01/regd.c.modified "$KSRC/drivers/net/wireless/realtek/rtw88/regd.c"
cd "$KSRC" && /home/ansible/files01/fix-regdom.sh && cd "$SRC"

# Setup configuration
mkdir -p "$KBUILD"
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Build phases
echo "Phase 1: modules_prepare..."
make -C "$KSRC" O="$KBUILD" modules_prepare
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"  # Restore config

echo "Phase 2: kernel build..."
make -C "$KSRC" O="$KBUILD" -j$(nproc)

echo "Phase 3: conftest setup..."
mkdir -p "$CONFTEST/nvidia"
cp -a "$OOT/scripts/conftest/"* "$CONFTEST/nvidia/"
make -f "$CONFTEST/nvidia/Makefile" \
     src="$CONFTEST/nvidia" obj="$CONFTEST/nvidia" \
     NV_KERNEL_SOURCES="$KSRC" NV_KERNEL_OUTPUT="$KBUILD" \
     ARCH=$ARCH -j$(nproc)

echo "Phase 4: OOT modules..."
make -C "$KBUILD" M="$OOT" \
     CONFIG_TEGRA_OOT_MODULE=m \
     srctree.nvidia-oot="$OOT" \
     srctree.nvconftest="$CONFTEST" \
     -j$(nproc) modules

echo "Build completed at $(date)"
echo "Results:"
ls -la "$KBUILD/arch/arm64/boot/Image"
find "$OOT" -name "*nvsciipc*" -type f
```

## Quick Command Reference Card

### Emergency Commands (Most Used)
```bash
# Restore config
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Check config integrity
stat -c%s "$KBUILD/.config"  # Should be 299360

# Stop all builds
pkill -f "make.*$KBUILD"

# Check build status
ps aux | grep make | grep -v grep

# Monitor logs
tail -f "$KBUILD"/*.log
```

### Environment Quick Setup
```bash
export WORK=$HOME/jetson-$(date +%Y%m%d_%H%M%S)
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src
export KBUILD=$SRC/build OOT=$SRC/nvidia-oot
export CONFTEST=$SRC/out/nvidia-conftest
```

---

**Remember**: Always use the exact commands shown. Kernel builds are sensitive to variations in syntax and environment.

*Last Updated: August 5, 2025*