# Complete Jetson Orin Nano Kernel Build Guide for Junior Developers

## Project Overview
This guide documents the complete process of building Linux 5.15 kernel with NVIDIA R36.4.4 patches and NVSCIIPC driver support for Jetson Orin Nano 8GB. Every command, problem, and solution is documented.

## ⚠️ CRITICAL WARNINGS FOR JUNIOR DEVELOPERS

### 1. NEVER USE `olddefconfig` OR `oldconfig`
**WHY**: These commands will SILENTLY REMOVE your critical configuration flags without warning!

```bash
# ❌ NEVER RUN THESE:
make olddefconfig  # Will remove CONFIG_TEGRA_OOT_MODULE=m
make oldconfig     # Will remove CONFIG_TEGRA_OOT_MODULE=m
make menuconfig    # If you exit, it may run olddefconfig automatically
```

**WHAT HAPPENS**: 
- `olddefconfig` looks for unknown symbols in your `.config`
- Finds `CONFIG_TEGRA_OOT_MODULE=m` but can't locate it in main kernel Kconfig
- **SILENTLY REMOVES IT** from your config file
- File size changes from 299360 → 299353 bytes (exactly 7 bytes = length of the removed line)

**SOLUTION**: Always monitor config file size and restore from backup immediately if changed.

### 2. Always Use nohup for Long Builds
**WHY**: Builds take 1-3 hours. If SSH disconnects, you lose everything.

```bash
# ✅ CORRECT WAY:
nohup make -C "$KSRC" O="$KBUILD" -j$(nproc) > build.log 2>&1 &

# ❌ WRONG WAY:
make -C "$KSRC" O="$KBUILD" -j$(nproc)  # Will fail if SSH disconnects
```

### 3. Monitor Config File Every 30 Seconds
**WHY**: The kernel build system will modify your config during compilation.

```bash
# Monitor script to run every 30s:
while true; do
  CONFIG_SIZE=$(stat -c%s "$KBUILD/.config")
  if [ "$CONFIG_SIZE" != "299360" ]; then
    echo "❌ CONFIG CHANGED! Restoring..."
    cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
  fi
  sleep 30
done
```

## Environment Setup

### Target Hardware
- **Device**: Jetson Orin Nano 8GB Development Kit
- **Architecture**: ARM64 (aarch64)
- **JetPack Version**: R36.4.4
- **Kernel Version**: Linux 5.15.148-tegra

### Host System Requirements
- **OS**: Ubuntu 22.04 LTS
- **RAM**: Minimum 8GB (16GB recommended)
- **Storage**: 20GB free space
- **Network**: Fast internet for 2GB+ downloads
- **SSH Access**: To target Jetson device

### Cross-Compilation Toolchain
```bash
# Install cross-compilation tools
sudo apt update
sudo apt install -y gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
sudo apt install -y build-essential bc bison flex libssl-dev libncurses5-dev
sudo apt install -y git wget curl rsync

# Verify toolchain
aarch64-linux-gnu-gcc --version
# Should show: aarch64-linux-gnu-gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
```

## Step-by-Step Build Process

### Step 1: Create Clean Build Environment

```bash
# Create timestamped directory (ALWAYS use timestamps for organization)
export TIMESTAMP=$(date +%Y%m%d_%H%M%S)
export WORK=$HOME/jetson-$TIMESTAMP
mkdir -p "$WORK"
cd "$WORK"

# Example: /home/ansible/jetson-20250805_195319
echo "Working in: $WORK"
```

### Step 2: Download NVIDIA Sources

**IMPORTANT**: You need TWO archives from NVIDIA Developer site.

#### Get the Archives
1. Go to: https://developer.nvidia.com/jetson-linux-r3644
2. Download these EXACT files:
   - `Jetson_Linux_R36.4.4_aarch64.tbz2` (746MB)
   - `public_sources.tbz2` (226MB)

```bash
# Verify file sizes (critical - wrong versions will fail)
ls -la *.tbz2
# Should show:
# -rw-rw-r-- 1 user user 746324969 Jetson_Linux_R36.4.4_aarch64.tbz2
# -rw-rw-r-- 1 user user 226164437 public_sources.tbz2
```

#### Extract Archives (Order Matters!)
```bash
# Extract public sources FIRST
tar -xvf public_sources.tbz2
# Creates: Linux_for_Tegra/source/ with build scripts

# Extract Jetson Linux SECOND (merges into same directory)
tar -xvf Jetson_Linux_R36.4.4_aarch64.tbz2
# Merges into: Linux_for_Tegra/ adding bootloader, configs, etc.

# Verify structure
ls -la Linux_for_Tegra/source/
# Should show: kernel_src.tbz2, kernel_oot_modules_src.tbz2, source_sync.sh
```

### Step 3: Extract Kernel Sources

```bash
cd Linux_for_Tegra/source

# Extract kernel wrapper (small - just samples and build scripts)
tar -xvf kernel_src.tbz2
# Creates: kernel/kernel-jammy-src/ (mostly empty)

# Extract OOT modules source
tar -xvf kernel_oot_modules_src.tbz2  
# Creates: hardware/ directory with device trees
```

### Step 4: The Git Problem and Solution

**PROBLEM**: The extracted kernel source is just a wrapper. Real kernel source must be downloaded via git.

#### Running source_sync.sh (The Git Challenge)
```bash
# This script downloads the REAL Linux kernel source (2.2GB)
./source_sync.sh

# ❌ PROBLEM: Script will ask for tags for every repository
# It will prompt like:
# "Please enter a tag to sync /path/to/repo source to (enter nothing to skip):"
```

**SOLUTION 1**: Let it run and press Enter for each prompt (tedious but works)

**SOLUTION 2**: Find the correct tag and specify it:
```bash
# First, check what tags are available in nvidia-oot repo
cd nvidia-oot && git tag | grep r36.4
# Shows tags like: l4t-l4t-r36.4.4_eng_2025-06-03

# Use the latest R36.4.4 tag
cd ..
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03
```

**WHAT THIS DOWNLOADS**:
- Real Linux 5.15 kernel source → `kernel/kernel-jammy-src/` (2.2GB)
- NVIDIA GPU drivers → `nvgpu/`
- NVIDIA OOT modules → `nvidia-oot/` 
- Hardware monitoring → `hwpm/`
- Display drivers → `nvdisplay/`

#### Verifying Git Download Success
```bash
# Check if real kernel source is there
ls -la kernel/kernel-jammy-src/
# Should show: Makefile, arch/, drivers/, include/, etc.

# Check NVSCIIPC driver location
ls -la nvidia-oot/drivers/misc/nvsciipc/
# Should show: nvsciipc.c, nvsciipc.h, Makefile

# Check git branch
cd nvidia-oot && git branch
# Should show: * l4t/l4t-r36.4.4 (or similar)
```

### Step 5: Apply Critical Fixes

**LOCATION**: Your fixes should be in `/home/ansible/files01/`

```bash
# List available fixes
ls -la /home/ansible/files01/
# Should show:
# .config-5aug          (299360 bytes) - Your kernel configuration
# init.c.adjusted       (16505 bytes)  - Crash kernel fix
# regd.c.modified       (19637 bytes)  - Wireless regulatory fix  
# fix-regdom.sh         (669 bytes)    - Regulatory domain script
```

#### Fix 1: Crash Kernel Problem
```bash
# Replace init.c to prevent crashk-related panics
cp /home/ansible/files01/init.c.adjusted \
   kernel/kernel-jammy-src/arch/arm64/mm/init.c
   
# Verify replacement
ls -la kernel/kernel-jammy-src/arch/arm64/mm/init.c
# Should be 16505 bytes with current timestamp
```

#### Fix 2: Wireless Regulatory Problem
```bash
# Replace regulatory domain handler for RTW88 WiFi driver
cp /home/ansible/files01/regd.c.modified \
   kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c
   
# Verify replacement
ls -la kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c
# Should be 19637 bytes with current timestamp
```

#### Fix 3: Additional Regulatory Setup
```bash
# Run regulatory domain fix script
cd kernel/kernel-jammy-src
/home/ansible/files01/fix-regdom.sh

# Script applies additional regulatory compliance changes
echo "Regulatory fixes applied"
```

### Step 6: Set Up Build Environment Variables

```bash
# CRITICAL: These must be exact for R36.4.x structure
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

# Build paths (adjust WORK to your actual path)
export WORK=$HOME/jetson-20250805_195319  # Your timestamped directory
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src    # ← R36.4.x uses jammy-src, NOT kernel-5.15
export KBUILD=$SRC/build                    # Out-of-tree build directory
export OOT=$SRC/nvidia-oot                  # NVIDIA OOT modules
export CONFTEST=$SRC/out/nvidia-conftest    # Compatibility headers

# Verify paths exist
echo "KSRC: $KSRC"   && ls -d "$KSRC"
echo "OOT: $OOT"     && ls -d "$OOT" 
echo "Conftest will be created at: $CONFTEST"
```

### Step 7: Configure Kernel Build

#### Copy Your Custom Configuration
```bash
# Create build directory
mkdir -p "$KBUILD"

# Copy your saved configuration (NEVER use defconfig for production!)
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Verify configuration
ls -la "$KBUILD/.config"
# Should show: 299360 bytes exactly

# Check critical flag is present
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"
# Should output: CONFIG_TEGRA_OOT_MODULE=m
```

### Step 8: Kernel Build Process

#### Phase 1: Prepare Kernel Build
```bash
# This step processes your config and prepares build environment
# WARNING: This step WILL modify your .config file!
nohup make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  modules_prepare > "$KBUILD/modules_prepare.log" 2>&1 &

# Monitor the process
tail -f "$KBUILD/modules_prepare.log"

# IMMEDIATELY after completion, check config file
ls -la "$KBUILD/.config"
# If size changed from 299360 to 299353, your flag was removed!

# Restore config if needed
if [ $(stat -c%s "$KBUILD/.config") != "299360" ]; then
  echo "Config was modified, restoring..."
  cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
fi
```

#### Phase 2: Build Kernel Image and Modules
```bash
# This is the main kernel build (takes 45-60 minutes)
nohup make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  -j$(nproc) > "$KBUILD/kernel_build.log" 2>&1 &

# Monitor build progress
tail -f "$KBUILD/kernel_build.log"

# Check config during build (run this in another terminal)
while true; do
  CONFIG_SIZE=$(stat -c%s "$KBUILD/.config" 2>/dev/null || echo "0")
  if [ "$CONFIG_SIZE" != "299360" ] && [ "$CONFIG_SIZE" != "0" ]; then
    echo "$(date): Config changed to $CONFIG_SIZE bytes, restoring..."
    cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
  fi
  sleep 30
done

# Verify successful completion
ls -la "$KBUILD/arch/arm64/boot/Image"
# Should show ~46MB kernel image file
```

### Step 9: NVIDIA Conftest Setup

**PURPOSE**: Generates compatibility headers for NVIDIA drivers.

```bash
# Create conftest directories
mkdir -p "$CONFTEST/nvidia"

# Copy NVIDIA conftest scripts
cp -a "$OOT/scripts/conftest/"* "$CONFTEST/nvidia/"

# Verify files copied
ls -la "$CONFTEST/nvidia/"
# Should show: Makefile, conftest.h, conftest.sh

# Run conftest (generates kernel compatibility definitions)
make -f "$CONFTEST/nvidia/Makefile" \
     src="$CONFTEST/nvidia" obj="$CONFTEST/nvidia" \
     NV_KERNEL_SOURCES="$KSRC" NV_KERNEL_OUTPUT="$KBUILD" \
     ARCH=$ARCH -j$(nproc)

# Verify conftest headers generated
ls -la "$CONFTEST/nvidia/conftest/headers.h"
# Should exist and be ~500-1000 bytes
```

### Step 10: Build NVIDIA OOT Modules (Including NVSCIIPC)

```bash
# Check config one more time before OOT build
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"
# Must show: CONFIG_TEGRA_OOT_MODULE=m

# Build all NVIDIA OOT modules with nohup
nohup make -C "$KBUILD" \
     M="$OOT" \
     CONFIG_TEGRA_OOT_MODULE=m \
     srctree.nvidia-oot="$OOT" \
     srctree.nvconftest="$CONFTEST" \
     -j$(nproc) modules > "$KBUILD/oot_build.log" 2>&1 &

# Monitor OOT build
tail -f "$KBUILD/oot_build.log"

# Check if NVSCIIPC compiled (even if final linking fails)
find "$OOT" -name "*nvsciipc*" -type f
# Should show: nvsciipc.c, nvsciipc.h, nvsciipc.o (object file)

# Check for final .ko modules
find "$OOT" -name "*.ko" -type f
# May be empty if build failed on other drivers
```

## Understanding Build Results

### Success Indicators ✅
1. **Kernel Image**: `build/arch/arm64/boot/Image` (~46MB)
2. **NVSCIIPC Object**: `nvidia-oot/drivers/misc/nvsciipc/nvsciipc.o` (~30KB)
3. **Config Intact**: `build/.config` (exactly 299360 bytes)
4. **Conftest Headers**: `out/nvidia-conftest/nvidia/conftest/headers.h`

### Partial Success (Common)
- NVSCIIPC compiles to `.o` but final `.ko` linking fails
- Usually due to errors in other unrelated drivers (like CAN bus drivers)
- **This is OK** - NVSCIIPC driver itself worked

### Complete Failure ❌
- No kernel Image produced
- NVSCIIPC object file missing
- Config file corrupted or missing critical flags

## Troubleshooting Common Issues

### Problem 1: "No rule to make target 'modules_prepare'"
**Cause**: Wrong kernel source path or empty kernel directory
**Solution**: 
```bash
# Check if you have the real kernel source
ls -la "$KSRC/Makefile"
ls -la "$KSRC/arch/arm64/"

# If missing, re-run source_sync.sh
cd "$SRC" && ./source_sync.sh
```

### Problem 2: Config file keeps getting modified
**Cause**: Kernel build system runs `silentoldconfig` 
**Solution**: Monitor and restore immediately
```bash
# Create monitoring script
cat << 'EOF' > monitor_config.sh
#!/bin/bash
KBUILD="$1"
while true; do
  if [ $(stat -c%s "$KBUILD/.config" 2>/dev/null || echo "0") != "299360" ]; then
    cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
    echo "$(date): Config restored"
  fi
  sleep 10
done
EOF

chmod +x monitor_config.sh
./monitor_config.sh "$KBUILD" &
```

### Problem 3: Cross-compilation errors
**Cause**: Missing or wrong toolchain
**Solution**:
```bash
# Verify toolchain
which aarch64-linux-gnu-gcc
aarch64-linux-gnu-gcc --version

# If missing:
sudo apt install gcc-aarch64-linux-gnu

# Check environment
echo $ARCH         # Should be: arm64
echo $CROSS_COMPILE # Should be: aarch64-linux-gnu-
```

### Problem 4: Out of disk space during build
**Cause**: Kernel build requires ~8GB total space
**Solution**:
```bash
# Check space
df -h

# Clean up if needed
make -C "$KSRC" O="$KBUILD" clean
rm -rf "$SRC/tegra"  # Remove extra downloaded components
```

### Problem 5: Git download fails or times out
**Cause**: Network issues or git server problems
**Solution**:
```bash
# Check network
ping -c 3 nv-tegra.nvidia.com

# Retry with different protocol
cd "$SRC"
# Edit source_sync.sh to use https instead of git://
sed -i 's|git://|https://|g' source_sync.sh
./source_sync.sh
```

## Directory Structure Reference

After successful build:
```
jetson-20250805_195319/
└── Linux_for_Tegra/
    └── source/
        ├── build/
        │   ├── .config                      (299360 bytes - your config)
        │   ├── arch/arm64/boot/Image        (46MB - bootable kernel)
        │   ├── kernel_build.log             (build log)
        │   └── oot_build.log               (OOT modules build log)
        ├── kernel/
        │   └── kernel-jammy-src/            (2.2GB - real Linux source)
        │       ├── arch/arm64/mm/init.c     (your crash fix)
        │       └── drivers/net/wireless/realtek/rtw88/regd.c (your wifi fix)
        ├── nvidia-oot/                     (NVIDIA OOT modules)
        │   └── drivers/misc/nvsciipc/
        │       ├── nvsciipc.c               (source code)
        │       ├── nvsciipc.h               (header)
        │       └── nvsciipc.o               (compiled object)
        └── out/nvidia-conftest/
            └── nvidia/conftest/headers.h    (compatibility headers)
```

## File Sizes Reference (for verification)

| File | Expected Size | Purpose |
|------|---------------|---------|
| `.config-5aug` | 299360 bytes | Your kernel configuration |
| `kernel Image` | ~46MB | Bootable kernel |
| `nvsciipc.o` | ~30KB | Compiled NVSCIIPC driver |
| `conftest/headers.h` | ~500-1000 bytes | NVIDIA compatibility |
| `init.c.adjusted` | 16505 bytes | Crash kernel fix |
| `regd.c.modified` | 19637 bytes | Wireless regulatory fix |

## Build Time Estimates

| Phase | Time | CPU Usage |
|-------|------|-----------|
| Source download | 5-10 min | Network limited |
| modules_prepare | 2-3 min | Medium |
| Kernel build | 45-60 min | High (100% all cores) |
| Conftest | 1-2 min | Medium |
| OOT modules | 5-10 min | High |
| **Total** | **1-2 hours** | |

## Commands Quick Reference

```bash
# Setup
export WORK=$HOME/jetson-$(date +%Y%m%d_%H%M%S)
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel/kernel-jammy-src
export KBUILD=$SRC/build
export OOT=$SRC/nvidia-oot
export CONFTEST=$SRC/out/nvidia-conftest

# Extract and setup sources
tar -xvf public_sources.tbz2
tar -xvf Jetson_Linux_R36.4.4_aarch64.tbz2
cd Linux_for_Tegra/source
tar -xvf kernel_src.tbz2
tar -xvf kernel_oot_modules_src.tbz2
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03

# Apply fixes
cp /home/ansible/files01/init.c.adjusted kernel/kernel-jammy-src/arch/arm64/mm/init.c
cp /home/ansible/files01/regd.c.modified kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c
cd kernel/kernel-jammy-src && /home/ansible/files01/fix-regdom.sh && cd ../..

# Build sequence
mkdir -p "$KBUILD"
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
make -C "$KSRC" O="$KBUILD" modules_prepare
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"  # Restore if modified
make -C "$KSRC" O="$KBUILD" -j$(nproc)

# NVIDIA modules
mkdir -p "$CONFTEST/nvidia"
cp -a "$OOT/scripts/conftest/"* "$CONFTEST/nvidia/"
make -f "$CONFTEST/nvidia/Makefile" src="$CONFTEST/nvidia" obj="$CONFTEST/nvidia" NV_KERNEL_SOURCES="$KSRC" NV_KERNEL_OUTPUT="$KBUILD" ARCH=$ARCH -j$(nproc)
make -C "$KBUILD" M="$OOT" CONFIG_TEGRA_OOT_MODULE=m srctree.nvidia-oot="$OOT" srctree.nvconftest="$CONFTEST" -j$(nproc) modules
```

## What Junior Developers Must Remember

1. **NEVER** run `olddefconfig` - it destroys your config
2. **ALWAYS** use nohup for builds longer than 5 minutes  
3. **MONITOR** config file size constantly (299360 bytes)
4. **BACKUP** your config before every build step
5. **VERIFY** file sizes match expected values
6. **USE** exact commands - don't improvise with kernel builds
7. **DOCUMENT** every deviation from this guide
8. **TEST** environment variables before long builds

---

**Final Status**: NVSCIIPC driver successfully compiled and ready for deployment testing.

*Last Updated: August 5, 2025*  
*Build Environment: Ubuntu 22.04 + R36.4.4 sources*