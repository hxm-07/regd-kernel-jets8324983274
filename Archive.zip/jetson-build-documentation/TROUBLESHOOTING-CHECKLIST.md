# Jetson Kernel Build Troubleshooting Checklist

## Pre-Build Verification Checklist

### ✅ Environment Setup
- [ ] Host system: Ubuntu 22.04 LTS
- [ ] Cross-compilation toolchain installed: `aarch64-linux-gnu-gcc --version`
- [ ] Minimum 20GB free disk space: `df -h`
- [ ] Minimum 8GB RAM available: `free -h`
- [ ] Fast internet connection for 2GB+ downloads

### ✅ Source Files Verification
- [ ] `Jetson_Linux_R36.4.4_aarch64.tbz2` = 746324969 bytes exactly
- [ ] `public_sources.tbz2` = 226164437 bytes exactly
- [ ] Downloaded from: https://developer.nvidia.com/jetson-linux-r3644
- [ ] Both files extracted without errors

### ✅ Configuration Files Present
- [ ] `/home/ansible/files01/.config-5aug` exists (299360 bytes)
- [ ] `/home/ansible/files01/init.c.adjusted` exists (16505 bytes)
- [ ] `/home/ansible/files01/regd.c.modified` exists (19637 bytes)
- [ ] `/home/ansible/files01/fix-regdom.sh` exists (669 bytes, executable)

## During Build Monitoring Checklist

### ✅ Config File Integrity (Check Every 30 Seconds)
```bash
# Expected size check
stat -c%s "$KBUILD/.config"  # Must be exactly 299360

# Critical flag check
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"  # Must show: CONFIG_TEGRA_OOT_MODULE=m

# If either fails, immediately run:
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
```

### ✅ Build Process Health
- [ ] nohup processes running: `ps aux | grep make`
- [ ] Log files growing: `ls -la "$KBUILD"/*.log`
- [ ] No "Error" messages in recent log entries: `tail -20 "$KBUILD"/build.log`
- [ ] System not running out of space: `df -h`

## Common Error Scenarios & Solutions

### Error 1: "No rule to make target 'modules_prepare'"

**Symptoms:**
```
make: *** No rule to make target 'modules_prepare'.  Stop.
```

**Root Cause:** Empty or incomplete kernel source directory

**Diagnosis Commands:**
```bash
ls -la "$KSRC/Makefile"        # Should exist and be ~67KB
ls -la "$KSRC/arch/arm64"      # Should exist with subdirectories
find "$KSRC" -name "Kconfig" | wc -l  # Should be 100+ files
```

**Solutions:**
1. **Check kernel source path:**
   ```bash
   echo "KSRC = $KSRC"
   # Should be: /path/to/Linux_for_Tegra/source/kernel/kernel-jammy-src
   ```

2. **Re-run source sync:**
   ```bash
   cd "$SRC"
   rm -rf kernel/kernel-jammy-src
   ./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03
   ```

3. **Check git repository status:**
   ```bash
   cd "$KSRC"
   git status
   git log --oneline -5  # Should show recent commits
   ```

### Error 2: Config File Corruption

**Symptoms:**
- File size changes from 299360 to 299353 bytes
- `CONFIG_TEGRA_OOT_MODULE=m` missing from config
- OOT modules fail to build

**Root Cause:** Kernel build system runs `silentoldconfig` automatically

**Immediate Fix:**
```bash
# Restore config immediately
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# Verify restoration
ls -la "$KBUILD/.config"  # Should be 299360 bytes
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"  # Should exist
```

**Prevention:**
```bash
# Run this monitoring script in parallel with builds
cat << 'EOF' > config_monitor.sh
#!/bin/bash
KBUILD="$1"
while true; do
    CURRENT_SIZE=$(stat -c%s "$KBUILD/.config" 2>/dev/null || echo "0")
    if [ "$CURRENT_SIZE" != "299360" ] && [ "$CURRENT_SIZE" != "0" ]; then
        echo "$(date): Config corrupted ($CURRENT_SIZE bytes), restoring..."
        cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
    fi
    sleep 30
done
EOF

chmod +x config_monitor.sh
nohup ./config_monitor.sh "$KBUILD" > config_monitor.log 2>&1 &
```

### Error 3: Git Download Failures

**Symptoms:**
```
fatal: unable to connect to nv-tegra.nvidia.com
Cloning into 'kernel/kernel-jammy-src'...
fatal: The remote end hung up unexpectedly
```

**Root Cause:** Network issues or git protocol problems

**Diagnosis:**
```bash
# Test connectivity
ping -c 3 nv-tegra.nvidia.com
wget -O /dev/null http://nv-tegra.nvidia.com/ --timeout=10
```

**Solutions:**

1. **Switch git protocol:**
   ```bash
   cd "$SRC"
   # Edit source_sync.sh to use https instead of git://
   sed -i 's|git://nv-tegra.nvidia.com|https://nv-tegra.nvidia.com|g' source_sync.sh
   ./source_sync.sh
   ```

2. **Manual repository clone:**
   ```bash
   cd "$SRC/kernel"
   rm -rf kernel-jammy-src
   git clone https://nv-tegra.nvidia.com/3rdparty/canonical/linux-jammy.git kernel-jammy-src
   cd kernel-jammy-src
   git checkout l4t-l4t-r36.4.4_eng_2025-06-03
   ```

3. **Use alternative mirror (if available):**
   ```bash
   # Check if GitHub mirror exists
   git clone https://github.com/NVIDIA/linux-kernel-jammy.git kernel-jammy-src
   ```

### Error 4: Cross-Compilation Issues

**Symptoms:**
```
/bin/sh: 1: aarch64-linux-gnu-gcc: not found
make: *** [scripts/Makefile.build:285: scripts/basic/fixdep] Error 127
```

**Root Cause:** Missing or incorrectly configured cross-compilation toolchain

**Diagnosis:**
```bash
# Check toolchain availability
which aarch64-linux-gnu-gcc
aarch64-linux-gnu-gcc --version

# Check environment variables
echo "ARCH = $ARCH"               # Should be: arm64
echo "CROSS_COMPILE = $CROSS_COMPILE" # Should be: aarch64-linux-gnu-
```

**Solutions:**

1. **Install toolchain:**
   ```bash
   sudo apt update
   sudo apt install -y gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
   sudo apt install -y build-essential bc bison flex libssl-dev
   ```

2. **Set environment variables:**
   ```bash
   export ARCH=arm64
   export CROSS_COMPILE=aarch64-linux-gnu-
   
   # Add to ~/.bashrc for persistence
   echo 'export ARCH=arm64' >> ~/.bashrc
   echo 'export CROSS_COMPILE=aarch64-linux-gnu-' >> ~/.bashrc
   ```

3. **Test toolchain:**
   ```bash
   # Create simple test program
   echo 'int main(){return 0;}' > test.c
   aarch64-linux-gnu-gcc test.c -o test_arm64
   file test_arm64  # Should show: ARM aarch64
   rm test.c test_arm64
   ```

### Error 5: Disk Space Issues

**Symptoms:**
```
No space left on device
make: *** [scripts/Makefile.build] Error 1
```

**Root Cause:** Kernel build requires 8-10GB total space

**Diagnosis:**
```bash
# Check available space
df -h
du -sh "$WORK"  # Check current build size
```

**Solutions:**

1. **Clean previous builds:**
   ```bash
   make -C "$KSRC" O="$KBUILD" clean
   make -C "$KSRC" O="$KBUILD" mrproper
   ```

2. **Remove unnecessary downloads:**
   ```bash
   cd "$SRC"
   rm -rf tegra/  # Remove extra components
   rm -f *.tbz2   # Remove original archives after extraction
   ```

3. **Move to larger partition:**
   ```bash
   # Move entire work directory
   mv "$WORK" /path/to/larger/partition/
   export WORK=/path/to/larger/partition/jetson-TIMESTAMP
   # Update all path variables
   ```

### Error 6: OOT Module Build Failures

**Symptoms:**
```
make[2]: *** [/path/to/nvidia-oot/drivers/net] Error 2
make[1]: *** [/path/to/nvidia-oot/drivers] Error 2
make: *** [/path/to/nvidia-oot] Error 2
```

**Root Cause:** Error in specific OOT driver (often unrelated to NVSCIIPC)

**Diagnosis:**
```bash
# Check what actually built
find "$OOT" -name "*.o" | grep nvsciipc
# Should show: nvidia-oot/drivers/misc/nvsciipc/nvsciipc.o

# Check specific error
grep -A 10 -B 10 "Error 2" "$KBUILD/oot_build.log"
```

**Solutions:**

1. **Build NVSCIIPC independently:**
   ```bash
   # Build only the NVSCIIPC module
   make -C "$KBUILD" M="$OOT/drivers/misc/nvsciipc" \
        CONFIG_TEGRA_OOT_MODULE=m \
        srctree.nvidia-oot="$OOT" \
        srctree.nvconftest="$CONFTEST" \
        modules
   ```

2. **Skip problematic drivers:**
   ```bash
   # Disable problematic drivers in OOT Makefile
   cd "$OOT"
   # Comment out failing subdirectories in drivers/Makefile
   sed -i 's/^obj-.*mttcan/#&/' drivers/net/can/Makefile
   ```

3. **Check missing dependencies:**
   ```bash
   # Verify conftest headers exist
   ls -la "$CONFTEST/nvidia/conftest/headers.h"
   
   # Verify kernel headers prepared
   ls -la "$KBUILD/include/generated/autoconf.h"
   ```

## Recovery Procedures

### Complete Build Recovery
```bash
# 1. Stop all running builds
pkill -f "make.*$KBUILD"

# 2. Clean everything
make -C "$KSRC" O="$KBUILD" mrproper

# 3. Restore configuration
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"

# 4. Verify environment
echo "KSRC = $KSRC"
echo "KBUILD = $KBUILD"
echo "OOT = $OOT"

# 5. Restart from modules_prepare
make -C "$KSRC" O="$KBUILD" modules_prepare
```

### Partial Recovery (Config Only)
```bash
# Quick config restoration without full rebuild
cp /home/ansible/files01/.config-5aug "$KBUILD/.config"
grep CONFIG_TEGRA_OOT_MODULE "$KBUILD/.config"  # Verify
```

### Source Recovery
```bash
# Re-download corrupted source
cd "$SRC"
rm -rf kernel/kernel-jammy-src nvidia-oot
./source_sync.sh -k l4t-l4t-r36.4.4_eng_2025-06-03

# Re-apply fixes
cp /home/ansible/files01/init.c.adjusted kernel/kernel-jammy-src/arch/arm64/mm/init.c
cp /home/ansible/files01/regd.c.modified kernel/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c
```

## Log File Analysis Guide

### Key Log Files
```bash
# Main kernel build log
"$KBUILD/kernel_build.log"

# OOT modules build log
"$KBUILD/oot_build.log"

# Module preparation log
"$KBUILD/modules_prepare.log"

# Config monitoring log
"config_monitor.log"
```

### Critical Log Patterns

**SUCCESS Patterns:**
```bash
grep "Leaving directory" "$KBUILD/kernel_build.log" | tail -1
# Should show: make: Leaving directory '/path/to/build'

grep "OBJCOPY.*Image" "$KBUILD/kernel_build.log"
# Should show: OBJCOPY arch/arm64/boot/Image
```

**ERROR Patterns:**
```bash
grep -i "error\|failed\|fatal" "$KBUILD"/*.log

# Config corruption
grep "warning: unexpected data" "$KBUILD"/*.log

# Missing files
grep "No such file or directory" "$KBUILD"/*.log

# Permission issues
grep "Permission denied" "$KBUILD"/*.log
```

## Emergency Contacts & Resources

### NVIDIA Developer Resources
- **Main Portal**: https://developer.nvidia.com/jetson-linux-r3644
- **Documentation**: https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/
- **Forums**: https://forums.developer.nvidia.com/c/agx-autonomous-machines/jetson-embedded-systems/

### Git Repositories
- **NVIDIA Tegra**: https://nv-tegra.nvidia.com/
- **Kernel Source**: https://nv-tegra.nvidia.com/3rdparty/canonical/linux-jammy.git
- **OOT Modules**: https://github.com/NVIDIA/open-gpu-kernel-modules

### Build Environment Verification Script
```bash
#!/bin/bash
# save as: verify_environment.sh

echo "=== Jetson Build Environment Verification ==="

# Check host system
echo "Host OS: $(lsb_release -d 2>/dev/null || echo 'Unknown')"
echo "Available RAM: $(free -h | grep Mem | awk '{print $2}')"
echo "Available Disk: $(df -h . | tail -1 | awk '{print $4}')"

# Check toolchain
echo "Cross Compiler: $(aarch64-linux-gnu-gcc --version 2>/dev/null | head -1 || echo 'MISSING')"

# Check environment variables
echo "ARCH = $ARCH"
echo "CROSS_COMPILE = $CROSS_COMPILE"
echo "KSRC = $KSRC"
echo "KBUILD = $KBUILD"

# Check critical files
echo "Config file: $(ls -la /home/ansible/files01/.config-5aug 2>/dev/null || echo 'MISSING')"
echo "Kernel source: $(ls -ld $KSRC 2>/dev/null || echo 'MISSING')"

# Check network
echo "Network to NVIDIA: $(ping -c 1 nv-tegra.nvidia.com >/dev/null 2>&1 && echo 'OK' || echo 'FAILED')"

echo "=== Verification Complete ==="
```

---

**Remember**: When in doubt, always restore from known good state rather than trying to fix corrupted builds.

*Last Updated: August 5, 2025*