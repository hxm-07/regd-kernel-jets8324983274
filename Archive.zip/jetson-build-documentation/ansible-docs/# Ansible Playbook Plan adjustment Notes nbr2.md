# Ansible Playbook Plan adjustment Notes nbr02 8-9-25


Here’s exactly what I recommend bundling—and the names/locations the playbook will expect:

## Keep (rename to these)

* `source_sync.sh-modified` → **`files/source_sync.sh`**
* `init.c.adjusted` → **`files/patches/init.c.adjusted`** (optional, if you want that tweak)
* `regd.c.modified` → **`files/patches/rtw88-regd.c`** (goes to `drivers/net/wireless/realtek/rtw88/regd.c`)
* `atheros-ath9k-hackregd.c` → **`files/patches/ath9k-regd.c`** (goes to `drivers/net/wireless/ath/ath9k/regd.c`)
* `tegra-soc-hwpm-uapi.h` → **`files/patches/tegra-soc-hwpm-uapi.h`** (copied to `include/uapi/linux/`)
* `gpu-Kconfig-patched` → **`files/patches/gpu-Kconfig-patched`** (installed over `drivers/gpu/Kconfig`)
* `gpu-Makefile-patched` → **`files/patches/gpu-Makefile-patched`** (installed over `drivers/gpu/Makefile`)
* `hwpm-modified-makefile` → **`files/patches/hwpm-modified-makefile`** (we’ll copy over `hwpm/drivers/tegra/hwpm/Makefile` to ensure the conftest include flags are present)
* `hwpmanalysis.h.mod` → **`files/patches/tegra_hwpm_static_analysis.h`** (drop-in for `hwpm/drivers/tegra/hwpm/include/tegra_hwpm_static_analysis.h`)

## Add (you don’t have these in the list)

* **`.config-5aug`** → **`files/.config-5aug`** (this is your seed config; absolutely required)
* I’ll generate and include the two Kconfig fragments we discussed:

  * **`files/kconfig/20-k8s-netfilter-builtins.cfg`** (conntrack/NAT/iptables built-ins)
  * **`files/kconfig/25-k8s-container-deps.cfg`** (bridge stack built-in, overlayfs built-in, vxlan as module)

## Drop from the bundle (optional to keep separately)

* `nvhwpm.ko` — don’t ship binaries in the repo; we’ll **build** and install it to match the running kernel’s `vermagic`. If you keep it for emergencies, store it outside the playbook repo and only use it when `uname -r` and `modinfo` vermagic match **exactly**.

## “Maybe” items

* `nvgpu-Kconfig` (298 B) — unless you know we actively overwrite another Kconfig with it, we won’t use it. Keep for reference, but the playbook won’t deploy it.

---

## One-liner to create the tar the playbook needs

If you place your files under `/home/ansible/files01`, you can run:

```bash
mkdir -p /home/ansible/ansible-bundle/files/patches /home/ansible/ansible-bundle/files/kconfig

# Required seed config
cp /home/ansible/files01/.config-5aug \
   /home/ansible/ansible-bundle/files/.config-5aug

# Modified sync helper
cp /home/ansible/files01/source_sync.sh-modified \
   /home/ansible/ansible-bundle/files/source_sync.sh

# GPU + HWPM patches
cp /home/ansible/files01/gpu-Kconfig-patched \
   /home/ansible/ansible-bundle/files/patches/gpu-Kconfig-patched
cp /home/ansible/files01/gpu-Makefile-patched \
   /home/ansible/ansible-bundle/files/patches/gpu-Makefile-patched
cp /home/ansible/files01/hwpm-modified-makefile \
   /home/ansible/ansible-bundle/files/patches/hwpm-modified-makefile
cp /home/ansible/files01/tegra-soc-hwpm-uapi.h \
   /home/ansible/ansible-bundle/files/patches/tegra-soc-hwpm-uapi.h
cp /home/ansible/files01/hwpmanalysis.h.mod \
   /home/ansible/ansible-bundle/files/patches/tegra_hwpm_static_analysis.h

# Optional tweaks you used
cp /home/ansible/files01/init.c.adjusted \
   /home/ansible/ansible-bundle/files/patches/init.c.adjusted
cp /home/ansible/files01/regd.c.modified \
   /home/ansible/ansible-bundle/files/patches/rtw88-regd.c
cp /home/ansible/files01/atheros-ath9k-hackregd.c \
   /home/ansible/ansible-bundle/files/patches/ath9k-regd.c

# I’ll generate these two cfg files for you; put them here:
cat > /home/ansible/ansible-bundle/files/kconfig/20-k8s-netfilter-builtins.cfg <<'EOF'
CONFIG_NET=y
CONFIG_INET=y
CONFIG_IPV6=y
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y
CONFIG_NETFILTER_FAMILY_BRIDGE=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_CONNTRACK_MARK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y
CONFIG_NF_NAT=y
CONFIG_NF_NAT_REDIRECT=y
CONFIG_NF_NAT_MASQUERADE=y
CONFIG_NETFILTER_XTABLES=y
CONFIG_NETFILTER_XT_NAT=y
CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_TPROXY=y
CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_RAW=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_TARGET_MASQUERADE=y
CONFIG_IP_NF_TARGET_REDIRECT=y
CONFIG_IP6_NF_IPTABLES=y
CONFIG_IP6_NF_FILTER=y
CONFIG_IP6_NF_MANGLE=y
CONFIG_IP6_NF_RAW=y
CONFIG_IP6_NF_NAT=y
CONFIG_IP6_NF_TARGET_MASQUERADE=y
EOF

cat > /home/ansible/ansible-bundle/files/kconfig/25-k8s-container-deps.cfg <<'EOF'
CONFIG_BRIDGE=y
CONFIG_BRIDGE_VLAN_FILTERING=y
CONFIG_BRIDGE_IGMP_SNOOPING=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_STP=y
CONFIG_GARP=y
CONFIG_LLC=y
CONFIG_OVERLAY_FS=y
CONFIG_OVERLAY_FS_INDEX=y
CONFIG_OVERLAY_FS_NFS_EXPORT=y
CONFIG_OVERLAY_FS_REDIRECT_DIR=y
CONFIG_NAMESPACES=y
CONFIG_UTS_NS=y
CONFIG_IPC_NS=y
CONFIG_USER_NS=y
CONFIG_PID_NS=y
CONFIG_NET_NS=y
CONFIG_CGROUPS=y
CONFIG_MEMCG=y
CONFIG_BLK_CGROUP=y
CONFIG_CGROUP_PIDS=y
CONFIG_CGROUP_CPUACCT=y
CONFIG_CGROUP_SCHED=y
CONFIG_CGROUP_FREEZER=y
CONFIG_CGROUP_BPF=y
CONFIG_TUN=y
CONFIG_VETH=m
CONFIG_MACVLAN=m
CONFIG_MACVTAP=m
CONFIG_VXLAN=m
EOF

# Pack it
tar -C /home/ansible/ansible-bundle -czf /home/ansible/files01-ansible-bundle.tgz .
echo "Bundle written to /home/ansible/files01-ansible-bundle.tgz"
```



Good catch — you’re right, we must run `fix-regdom.sh` and I forgot to wire it into the flow. Here’s exactly where it belongs and an idempotent Ansible drop-in to add to the role right after the two `regd.c` copies and **before** any kernel/HWPM build starts.

### Where in the pipeline

1. Extract `files01.tgz`
2. Copy the `regd.c` overrides:

* `drivers/net/wireless/realtek/rtw88/regd.c`
* `drivers/net/wireless/ath/ath9k/regd.c`

3. **Run `fix-regdom.sh`** (from your `files01` bundle) against the **kernel source tree (`KSRC`)**
4. Proceed with the rest (config enforce/merge, `modules_prepare`, build, OOT HWPM, etc.)

### Ansible tasks (idempotent)

Put these tasks *right after* the two copy tasks for `regd.c`:

```yaml
- name: Ensure fix-regdom.sh is present and executable
  file:
    path: "{{ files01_dir }}/fix-regdom.sh"
    mode: "0755"
    state: file

- name: Run fix-regdom.sh once per source tree
  shell: |
    set -euo pipefail
    if [ ! -f .regdom_patched ]; then
      echo "[fix-regdom] applying patch to kernel sources at $(pwd)"
      bash "{{ files01_dir }}/fix-regdom.sh"
      touch .regdom_patched
    else
      echo "[fix-regdom] already applied, skipping"
    fi
  args:
    chdir: "{{ ksources }}"
  register: fix_regdom
  changed_when: "'applying patch' in fix_regdom.stdout"

- name: Quick sanity for regdom edits (no-op)
  shell: |
    set -eo pipefail
    grep -q 'ath9k' drivers/net/wireless/ath/ath9k/regd.c
    grep -q 'rtw88' drivers/net/wireless/realtek/rtw88/regd.c
  args:
    chdir: "{{ ksources }}"
  changed_when: false
```

**Notes**

* `{{ files01_dir }}` is where you unpacked `files01.tgz`.
* `{{ ksources }}` is your kernel source dir (`$SRC/kernel-jammy-src`).
* The `touch .regdom_patched` guard makes the task reliably **idempotent** across re-runs and reboots.
* Keep this **before** any `make ... modules_prepare`/build so the patch is in effect for all downstream compiles.

