# Jetson L4T R36.4.4 — Reproducible Kernel + OOT HWPM + K3s Netfilter

**Goal**

* Build a **reproducible** kernel for Jetson Orin (T234) on-device, matching release `5.15.148-tegra`, with:

  1. bridge stack reliable for Kubernetes (bridge/br\_netfilter + deps)
  2. netfilter/iptables either **built‑in** (recommended for prod) or **modules** (close to stock)
  3. NVIDIA **HWPM** out‑of‑tree module compiled against the running kernel (vermagic‑clean).
* The process is idempotent and suitable to drive via Ansible on slow links.

> **Profiles**
>
> * **Profile A (recommended)**: netfilter/iptables **built‑in** → avoids module CRC drift and Unknown symbol issues.
> * **Profile B (optional)**: netfilter/iptables as **modules (=m)** → closer to stock; ensure you’re loading modules built against **your** kernel tree.

---

## 0) Prereqs & Artifacts

* Device: Jetson Orin running **L4T R36.4.4** (Ubuntu 22.04).
* Target kernel release: **`5.15.148-tegra`** (no extra suffix).
* Host == Device (on‑device build).

### Packages (device)

```bash
sudo apt-get update
sudo apt-get install -y build-essential bc bison flex libssl-dev \
  libncurses-dev dwarves ccache libelf-dev python3 rsync \
  gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
```

### Workspace variables (canonical)

```bash
export WORK="$HOME/jetson-nvgpu-$(date +%Y%m%d_%H%M%S)"
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel-jammy-src     # kernel source
export KBUILD=$SRC/build              # kernel build output (O=)
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
```

### Files bundle you provide (`files01.tgz`)

Pack these into a tarball and ship with the Ansible role (no absolute host paths in playbooks):

```
files01/
  ├── source_sync.sh-modified           # replaces L4T’s script (tag handling)
  ├── gpu-Kconfig-patched               # minimal Kconfig patch you used
  ├── gpu-Makefile-patched              # minimal Makefile patch you used
  ├── init.c.adjusted                   # arch/arm64/mm/init.c (if needed by your build)
  ├── atheros-ath9k-hackregd.c          # ath9k regdom adjust
  ├── regd.c.modified                   # rtw88 regdom adjust
  ├── fix-regdom.sh                     # idempotent script to apply regdom tweaks
  ├── tegra-soc-hwpm-uapi.h             # uapi header copied for HWPM OOT
  ├── hwpm-modified-makefile            # if you carry a Makefile tweak for HWPM
  ├── nvgpu-Kconfig                     # (if you carry) any specific nvgpu Kconfig
  ├── 20-k8s-netfilter-builtins.cfg     # **provided below**
  └── 25-k8s-container-deps.cfg         # **provided below**
```

> Keep the bundle small; any change here bumps your reproducible digest.

---

## 1) Get L4T + Sources (slow link‑safe)

```bash
mkdir -p "$WORK" && cd "$WORK"
# You provide the two tarballs locally or via scp before running
#  Jetson_Linux_R36.4.4_aarch64.tbz2
#  public_sources.tbz2

tar -xf ./Jetson_Linux_R36.4.4_aarch64.tbz2 -C "$WORK"
tar -xf ./public_sources.tbz2             -C "$WORK"

# layout check
ls -lh "$SRC/kernel_src.tbz2" "$SRC/kernel_oot_modules_src.tbz2" "$SRC/source_sync.sh"
mkdir -p "$SRC/kernel" "$SRC/kernel/nvidia"
tar -xf "$SRC/kernel_src.tbz2"            -C "$SRC/kernel"
tar -xf "$SRC/kernel_oot_modules_src.tbz2"-C "$SRC/kernel/nvidia"
```

### Replace `source_sync.sh`

```bash
# Replace with your fixed script (better tag handling)
cp files01/source_sync.sh-modified "$SRC/source_sync.sh"
chmod +x "$SRC/source_sync.sh"

# Pull the right tag into kernel-jammy-src
cd "$SRC"
./source_sync.sh -t jetson_36.4.4
# Sanity: the tree should exist now
[ -f "$SRC/kernel-jammy-src/Makefile" ] || { echo "sync failed"; exit 1; }
```

> Rationale: we observed the stock script/tag drift causing wrong trees; the patched script consistently yielded the correct 5.15.148 tree.

---

## 2) Seed the kernel and apply your tiny patchset

```bash
# Build output dir
mkdir -p "$KBUILD"

# If you keep a large reference config (optional), drop it now:
# cp files01/.config-5aug "$KBUILD/.config"

# Apply your minimal patches
cp files01/gpu-Kconfig-patched    "$SRC/kernel-jammy-src/drivers/gpu/Kconfig"
cp files01/gpu-Makefile-patched   "$SRC/kernel-jammy-src/drivers/gpu/Makefile"

# Optional init.c adjust (carry only if you really need it)
[ -f files01/init.c.adjusted ] && \
  cp files01/init.c.adjusted "$SRC/kernel-jammy-src/arch/arm64/mm/init.c"

# Regulatory domain fixes
cp files01/regd.c.modified \
  "$SRC/kernel-jammy-src/drivers/net/wireless/realtek/rtw88/regd.c"
cp files01/atheros-ath9k-hackregd.c \
  "$SRC/kernel-jammy-src/drivers/net/wireless/ath/ath9k/regd.c"
chmod +x files01/fix-regdom.sh
(
  cd "$SRC/kernel-jammy-src"
  if [ ! -f .regdom_patched ]; then
    bash "$WORK/files01/fix-regdom.sh"
    touch .regdom_patched
  fi
)
```

> **Idempotence**: `.regdom_patched` guards multiple runs. Keep all edits **before** any `modules_prepare` to ensure they’re in the build.

---

## 3) Enforce config (bridge + container deps + netfilter profile)

We don’t blindly replace the vendor config. We **merge small, owned fragments** then normalize via Kconfig.

### Fragments (ship these exactly)

**`files01/25-k8s-container-deps.cfg`**

```
CONFIG_LOCALVERSION="-tegra"
CONFIG_LOCALVERSION_AUTO=n

# Container FS & veth
CONFIG_OVERLAY_FS=y
CONFIG_VETH=m

# Bridge stack for CNIs (built-in to avoid boot/module ordering surprises)
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
CONFIG_STP=y
CONFIG_LLC=y

# Namespaces & cgroups expected by k3s
CONFIG_NAMESPACES=y
CONFIG_UTS_NS=y
CONFIG_IPC_NS=y
CONFIG_PID_NS=y
CONFIG_NET_NS=y
CONFIG_CGROUPS=y
CONFIG_CGROUP_PIDS=y
CONFIG_CGROUP_SCHED=y
CONFIG_CGROUP_CPUACCT=y
CONFIG_CGROUP_DEVICE=y
CONFIG_CPUSETS=y
CONFIG_MEMCG=y

# Networking base
CONFIG_NET=y
CONFIG_INET=y
CONFIG_IPV6=y
CONFIG_NETFILTER=y
CONFIG_NETFILTER_ADVANCED=y
```

**`files01/20-k8s-netfilter-builtins.cfg`** (Profile A)

```
# Core netfilter/iptables as built-ins to avoid module-CRC drift
CONFIG_NETFILTER_XTABLES=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_CONNTRACK_MARK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y
CONFIG_NF_NAT=y

CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_TARGET_REJECT=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_RAW=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_TARGET_MASQUERADE=y

CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_MATCH_TCPMSS=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_MATCH_SOCKET=y

CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_LOG=y
```

> If you prefer **modules** instead, clone this file as `20-k8s-netfilter-modules.cfg` and flip every `=y` to `=m` (Profile B).

### Merge & normalize

```bash
# Ensure the fragment merge helper exists
MERGE="$SRC/kernel-jammy-src/scripts/kconfig/merge_config.sh"

# Use the running kernel’s config as a baseline if present
if zcat /proc/config.gz >/dev/null 2>&1; then
  zcat /proc/config.gz > "$KBUILD/.config"
fi

# Merge fragments
"$MERGE" -m -O "$KBUILD" \
  "$KBUILD/.config" \
  "$WORK/files01/25-k8s-container-deps.cfg" \
  "$WORK/files01/20-k8s-netfilter-builtins.cfg"   # or ...-modules.cfg for Profile B

# Normalize .config and generate headers
make -C "$KSRC" O="$KBUILD" ARCH=$ARCH olddefconfig
make -C "$KSRC" O="$KBUILD" ARCH=$ARCH modules_prepare

# Lock all three views match (belt-and-suspenders)
for f in \
  "$KBUILD/.config" \
  "$KBUILD/include/config/auto.conf" \
  "$KBUILD/include/generated/autoconf.h"; do
  grep -q '^CONFIG_BRIDGE=y' "$f" || { echo "BRIDGE NOT LOCKED in $f"; exit 1; }
  grep -q '^CONFIG_LOCALVERSION="-tegra"' "$KBUILD/.config" || { echo "LOCALVERSION wrong"; exit 1; }
done
```

---

## 4) Build kernel (slow-link friendly)

Use foreground on console, or `nohup` with logs if you expect disconnects. Under Ansible, prefer `async` (see role below).

```bash
nohup bash -c \
  "make -C '$KSRC' O='$KBUILD' ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE -j\"$(nproc)\" Image modules dtbs" \
  > "$KBUILD/kernel_build.log" 2>&1 &
BUILD_PID=$!
echo "Build PID: $BUILD_PID  (log: $KBUILD/kernel_build.log)"

# crude monitor
( tail -f "$KBUILD/kernel_build.log" & ) | sed -u 's/^/[kernel-build] /'
wait $BUILD_PID

# sanity
[ -f "$KBUILD/arch/arm64/boot/Image" ] || { echo "no Image"; exit 1; }
cat "$KBUILD/include/config/kernel.release"   # expect: 5.15.148-tegra (NO +dirty)
```

> If `kernel.release` ever contains a `+` or extra suffix, **stop**: your OOT modules later won’t load. Fix `CONFIG_LOCALVERSION` and rebuild.

---

## 5) Install kernel + modules, set boot, reboot

```bash
# Install modules into /lib/modules/$(kernelrelease)
sudo make -C "$KSRC" O="$KBUILD" ARCH=$ARCH modules_install

# Copy Image and dtbs (Jetson typically uses /boot/Image and extlinux)
sudo install -m0644 "$KBUILD/arch/arm64/boot/Image" /boot/Image
sudo rsync -a "$KBUILD/arch/arm64/boot/dts/" /boot/dtb/

# Ensure extlinux.conf points to /boot/Image (usually already does)
grep -A2 -n "MENU LABEL primary kernel" /boot/extlinux/extlinux.conf || true

# Persist bridge netfilter sysctls (optional)
echo "br_netfilter" | sudo tee /etc/modules-load.d/br_netfilter.conf

# Reboot and give it time
sudo reboot
```

Wait **120–180s**, then ssh back in. Post‑reboot checks:

```bash
uname -r                      # must be 5.15.148-tegra
cat /proc/version
modinfo bridge | head -n1     # present even if built-in (module info may not exist when =y)
```

---

## 6) Build & install NVIDIA HWPM OOT module

The in‑tree vs OOT symbols varied across trees. We standardized on the **OOT path**:

```bash
# Env refresh after reboot
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel-jammy-src
export KBUILD=$SRC/build
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

# Prepare headers (vermagic alignment)
make -C "$KSRC" O="$KBUILD" olddefconfig prepare modules_prepare
make -C "$KSRC" O="$KBUILD" -s kernelrelease   # expect 5.15.148-tegra

# HWPM include helpers (conftest paths)
CONFTEST="$KBUILD/out/nvidia-conftest"

# Optional: ensure HWPM Makefile tweak is in if you carry one
[ -f "$WORK/files01/hwpm-modified-makefile" ] && \
  cp "$WORK/files01/hwpm-modified-makefile" "$SRC/hwpm/drivers/tegra/hwpm/Makefile"

# Ensure the uapi header is available if your OOT needs it
install -D -m0644 "$WORK/files01/tegra-soc-hwpm-uapi.h" \
  "$KSRC/include/uapi/linux/tegra-soc-hwpm-uapi.h"

# Build OOT with explicit OOT flag and conftest include path
make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  M="$SRC/hwpm/drivers/tegra/hwpm" \
  EXTRA_CFLAGS="-DCONFIG_TEGRA_HWPM_OOT=1 -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest" \
  -j"$(nproc)" modules V=1

# Verify vermagic exactly matches running kernel
modinfo "$SRC/hwpm/drivers/tegra/hwpm/nvhwpm.ko" | grep vermagic
uname -r

# Install and persist
KREL=$(uname -r)
sudo install -D -m0644 "$SRC/hwpm/drivers/tegra/hwpm/nvhwpm.ko" \
  "/lib/modules/$KREL/extra/nvhwpm.ko"
echo nvhwpm | sudo tee /etc/modules-load.d/nvhwpm.conf
sudo depmod -a
sudo modprobe -v nvhwpm || true

# Optional: dynamic debug (if enabled)
if zcat /proc/config.gz | grep -q '^CONFIG_DYNAMIC_DEBUG=y'; then
  sudo mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
  echo 'module nvhwpm +p' | sudo tee /sys/kernel/debug/dynamic_debug/control
fi

# Device present?
sudo find /sys -maxdepth 4 -type d -iname '*hwpm*'
ls -l /dev | grep -i hwpm || true
```

> If vermagic mismatch occurs, revisit **Step 5** (kernel.release cleanliness) and rebuild OOT.

---

## 7) Netfilter/iptables readiness for k3s

### Profile A (built‑ins): nothing to load

Just verify presence and sysctls:

```bash
# br_netfilter path exists if bridge netfilter is enabled
ls /proc/sys/net/bridge/bridge-nf-call-iptables

# quick iptables sanity (nft or legacy depending on userspace)
sudo iptables -L -n | head
```

### Profile B (modules): compile + install netfilter set

Only if you chose the `-modules.cfg` in Step 3 and want to ship modules instead of built‑ins:

```bash
for d in net/netfilter net/ipv4/netfilter; do
  make -C "$KSRC" O="$KBUILD" M="$KSRC/$d" -j"$(nproc)" modules
done

KREL=$(uname -r)
install_one() { [ -f "$1" ] || return 0; sudo install -D -m0644 "$1" "/lib/modules/$KREL/${2}"; }

install_one "$KBUILD/net/netfilter/x_tables.ko"                 "kernel/net/netfilter/x_tables.ko"
install_one "$KBUILD/net/netfilter/nfnetlink.ko"                "kernel/net/netfilter/nfnetlink.ko"
install_one "$KBUILD/net/netfilter/nf_conntrack.ko"             "kernel/net/netfilter/nf_conntrack.ko"
install_one "$KBUILD/net/netfilter/nf_defrag_ipv4.ko"           "kernel/net/netfilter/nf_defrag_ipv4.ko"
install_one "$KBUILD/net/netfilter/nf_defrag_ipv6.ko"           "kernel/net/netfilter/nf_defrag_ipv6.ko"
install_one "$KBUILD/net/netfilter/nf_nat.ko"                   "kernel/net/netfilter/nf_nat.ko"

install_one "$KBUILD/net/ipv4/netfilter/ip_tables.ko"           "kernel/net/ipv4/netfilter/ip_tables.ko"
install_one "$KBUILD/net/ipv4/netfilter/iptable_filter.ko"      "kernel/net/ipv4/netfilter/iptable_filter.ko"
install_one "$KBUILD/net/ipv4/netfilter/iptable_nat.ko"         "kernel/net/ipv4/netfilter/iptable_nat.ko"

install_one "$KBUILD/net/netfilter/xt_conntrack.ko"             "kernel/net/netfilter/xt_conntrack.ko"
install_one "$KBUILD/net/netfilter/xt_MASQUERADE.ko"            "kernel/net/netfilter/xt_MASQUERADE.ko"
install_one "$KBUILD/net/netfilter/xt_mark.ko"                  "kernel/net/netfilter/xt_mark.ko"
install_one "$KBUILD/net/netfilter/xt_comment.ko"               "kernel/net/netfilter/xt_comment.ko"
install_one "$KBUILD/net/netfilter/xt_tcpudp.ko"                "kernel/net/netfilter/xt_tcpudp.ko"

sudo depmod -a
sudo modprobe -v nf_conntrack nf_nat x_tables ip_tables iptable_filter iptable_nat \
                 xt_conntrack xt_MASQUERADE xt_mark xt_comment xt_tcpudp
```

> If you ever see **Unknown symbol**: you didn’t build these against **this** kernel (or the kernel picked up a `+dirty`). Revisit Steps 3–5.

---

## 8) Post‑build validation

```bash
# Kernel identity
uname -r                         # 5.15.148-tegra
cat "$KBUILD/include/config/kernel.release"

# Bridge stack
ip link add name br0 type bridge || true
ip link del br0 || true

# br_netfilter sysctls
ls /proc/sys/net/bridge/bridge-nf-call-iptables

# iptables availability
sudo iptables -S | head -n5

# HWPM nodes
sudo find /sys/kernel/debug -maxdepth 2 -type d -iname '*hwpm*' || true
```

Package artifacts for reuse elsewhere (optional):

```bash
OUT=/opt/kernel-artifacts-$(date +%Y%m%d_%H%M%S)
sudo mkdir -p "$OUT"
KREL=$(uname -r)
sudo cp -a /lib/modules/$KREL "$OUT/"
sudo cp -a /boot/Image "$OUT/"
sudo rsync -a /boot/dtb/ "$OUT/dtb/"
[ -f "/lib/modules/$KREL/extra/nvhwpm.ko" ] && \
  sudo install -D -m0644 "/lib/modules/$KREL/extra/nvhwpm.ko" "$OUT/extra/nvhwpm.ko"
(cd "$OUT/.." && sudo tar czf kernel-artifacts-$KREL.tgz "$(basename "$OUT")")
```

---

## 9) Ansible Role Blueprint (idempotent, slow‑link tolerant)

**Role variables**

```yaml
# defaults/main.yml
work_root: "/home/{{ ansible_user }}/jetson-nvgpu-{{ ansible_date_time.iso8601_basic_short }}"
src_root:  "{{ work_root }}/Linux_for_Tegra/source"
ksources:  "{{ src_root }}/kernel-jammy-src"
kbuild:    "{{ src_root }}/build"
arch:      "arm64"
cross:     "aarch64-linux-gnu-"
files01_dir: "{{ work_root }}/files01"
profile_netfilter: "builtins"   # or "modules"
reboot_wait: 180
```

**Files to ship**

* `files01.tgz` containing everything listed earlier (including the two cfgs).

**Tasks** (ordered)

```yaml
- name: Create workspace
  file: { path: "{{ work_root }}", state: directory }

- name: Drop L4T archives (copy from controller or URL)
  copy:
    src: "{{ item }}"
    dest: "{{ work_root }}/"
  with_items:
    - Jetson_Linux_R36.4.4_aarch64.tbz2
    - public_sources.tbz2

- name: Unpack L4T + public sources
  shell: |
    set -euo pipefail
    tar -xf Jetson_Linux_R36.4.4_aarch64.tbz2 -C "{{ work_root }}"
    tar -xf public_sources.tbz2 -C "{{ work_root }}"
  args: { chdir: "{{ work_root }}" }

- name: Unpack files01
  unarchive:
    src: files01.tgz
    dest: "{{ work_root }}"
    creates: "{{ files01_dir }}"

- name: Extract kernel tarballs into source tree
  shell: |
    set -euo pipefail
    mkdir -p "{{ src_root }}/kernel" "{{ src_root }}/kernel/nvidia"
    tar -xf "{{ src_root }}/kernel_src.tbz2" -C "{{ src_root }}/kernel"
    tar -xf "{{ src_root }}/kernel_oot_modules_src.tbz2" -C "{{ src_root }}/kernel/nvidia"
  args: { chdir: "{{ work_root }}" }

- name: Replace source_sync.sh with patched
  copy:
    src: "{{ files01_dir }}/source_sync.sh-modified"
    dest: "{{ src_root }}/source_sync.sh"
    mode: "0755"

- name: Sync kernel sources to jetson_36.4.4
  shell: ./source_sync.sh -t jetson_36.4.4
  args: { chdir: "{{ src_root }}" }

- name: Verify ksources presence
  stat: { path: "{{ ksources }}/Makefile" }
  register: ks
- assert:
    that: ks.stat.exists

# ---- Tiny patchset ----
- name: Apply gpu Kconfig/Makefile patches
  copy:
    src: "{{ item.src }}"
    dest: "{{ item.dest }}"
    mode: "0644"
  with_items:
    - { src: "{{ files01_dir }}/gpu-Kconfig-patched",  dest: "{{ ksources }}/drivers/gpu/Kconfig" }
    - { src: "{{ files01_dir }}/gpu-Makefile-patched", dest: "{{ ksources }}/drivers/gpu/Makefile" }

- name: Optional init.c tweak
  copy:
    src: "{{ files01_dir }}/init.c.adjusted"
    dest: "{{ ksources }}/arch/arm64/mm/init.c"
    mode: "0644"
  when: lookup('file', files01_dir + '/init.c.adjusted', errors='ignore')|length > 0

- name: Copy regdom overrides
  copy:
    src: "{{ item.src }}"
    dest: "{{ item.dest }}"
    mode: "0644"
  with_items:
    - { src: "{{ files01_dir }}/regd.c.modified", dest: "{{ ksources }}/drivers/net/wireless/realtek/rtw88/regd.c" }
    - { src: "{{ files01_dir }}/atheros-ath9k-hackregd.c", dest: "{{ ksources }}/drivers/net/wireless/ath/ath9k/regd.c" }

- name: Ensure fix-regdom.sh executable
  file: { path: "{{ files01_dir }}/fix-regdom.sh", mode: "0755", state: file }

- name: Run fix-regdom.sh once per tree
  shell: |
    set -euo pipefail
    if [ ! -f .regdom_patched ]; then
      bash "{{ files01_dir }}/fix-regdom.sh"
      touch .regdom_patched
    fi
  args: { chdir: "{{ ksources }}" }

# ---- Config fragments and normalization ----
- name: Seed baseline config from running kernel if available
  shell: zcat /proc/config.gz > "{{ kbuild }}/.config"
  args: { chdir: "{{ work_root }}" }
  ignore_errors: yes

- name: Write container deps fragment
  copy:
    dest: "{{ files01_dir }}/25-k8s-container-deps.cfg"
    mode: "0644"
    content: |
      CONFIG_LOCALVERSION="-tegra"
      CONFIG_LOCALVERSION_AUTO=n
      CONFIG_OVERLAY_FS=y
      CONFIG_VETH=m
      CONFIG_BRIDGE=y
      CONFIG_BRIDGE_NETFILTER=y
      CONFIG_STP=y
      CONFIG_LLC=y
      CONFIG_NAMESPACES=y
      CONFIG_UTS_NS=y
      CONFIG_IPC_NS=y
      CONFIG_PID_NS=y
      CONFIG_NET_NS=y
      CONFIG_CGROUPS=y
      CONFIG_CGROUP_PIDS=y
      CONFIG_CGROUP_SCHED=y
      CONFIG_CGROUP_CPUACCT=y
      CONFIG_CGROUP_DEVICE=y
      CONFIG_CPUSETS=y
      CONFIG_MEMCG=y
      CONFIG_NET=y
      CONFIG_INET=y
      CONFIG_IPV6=y
      CONFIG_NETFILTER=y
      CONFIG_NETFILTER_ADVANCED=y

- name: Write netfilter profile fragment
  copy:
    dest: "{{ files01_dir }}/20-k8s-netfilter-{{ profile_netfilter }}.cfg"
    mode: "0644"
    content: |
      {% if profile_netfilter == 'builtins' %}
      CONFIG_NETFILTER_XTABLES=y
      CONFIG_NF_CONNTRACK=y
      CONFIG_NF_CONNTRACK_MARK=y
      CONFIG_NF_DEFRAG_IPV4=y
      CONFIG_NF_DEFRAG_IPV6=y
      CONFIG_NF_NAT=y
      CONFIG_IP_NF_IPTABLES=y
      CONFIG_IP_NF_FILTER=y
      CONFIG_IP_NF_TARGET_REJECT=y
      CONFIG_IP_NF_MANGLE=y
      CONFIG_IP_NF_RAW=y
      CONFIG_IP_NF_NAT=y
      CONFIG_IP_NF_TARGET_MASQUERADE=y
      CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
      CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
      CONFIG_NETFILTER_XT_MATCH_MARK=y
      CONFIG_NETFILTER_XT_MATCH_TCPMSS=y
      CONFIG_NETFILTER_XT_MATCH_COMMENT=y
      CONFIG_NETFILTER_XT_MATCH_OWNER=y
      CONFIG_NETFILTER_XT_MATCH_SOCKET=y
      CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
      CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
      CONFIG_NETFILTER_XT_TARGET_LOG=y
      {% else %}
      CONFIG_NETFILTER_XTABLES=m
      CONFIG_NF_CONNTRACK=m
      CONFIG_NF_CONNTRACK_MARK=m
      CONFIG_NF_DEFRAG_IPV4=m
      CONFIG_NF_DEFRAG_IPV6=m
      CONFIG_NF_NAT=m
      CONFIG_IP_NF_IPTABLES=m
      CONFIG_IP_NF_FILTER=m
      CONFIG_IP_NF_TARGET_REJECT=m
      CONFIG_IP_NF_MANGLE=m
      CONFIG_IP_NF_RAW=m
      CONFIG_IP_NF_NAT=m
      CONFIG_IP_NF_TARGET_MASQUERADE=m
      CONFIG_NETFILTER_XT_MATCH_CONNTRACK=m
      CONFIG_NETFILTER_XT_MATCH_MULTIPORT=m
      CONFIG_NETFILTER_XT_MATCH_MARK=m
      CONFIG_NETFILTER_XT_MATCH_TCPMSS=m
      CONFIG_NETFILTER_XT_MATCH_COMMENT=m
      CONFIG_NETFILTER_XT_MATCH_OWNER=m
      CONFIG_NETFILTER_XT_MATCH_SOCKET=m
      CONFIG_NETFILTER_XT_TARGET_MASQUERADE=m
      CONFIG_NETFILTER_XT_TARGET_REDIRECT=m
      CONFIG_NETFILTER_XT_TARGET_LOG=m
      {% endif %}

- name: Merge fragments
  shell: |
    set -euo pipefail
    mkdir -p "{{ kbuild }}"
    if [ ! -f "{{ kbuild }}/.config" ]; then
      zcat /proc/config.gz > "{{ kbuild }}/.config"
    fi
    "{{ ksources }}/scripts/kconfig/merge_config.sh" -m -O "{{ kbuild }}" \
      "{{ kbuild }}/.config" \
      "{{ files01_dir }}/25-k8s-container-deps.cfg" \
      "{{ files01_dir }}/20-k8s-netfilter-{{ profile_netfilter }}.cfg"
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_prepare
    # verify locks in all views
    grep -q '^CONFIG_BRIDGE=y' "{{ kbuild }}/.config"
    grep -q '^CONFIG_BRIDGE=y' "{{ kbuild }}/include/config/auto.conf"
    grep -q '^#define CONFIG_BRIDGE 1$' "{{ kbuild }}/include/generated/autoconf.h"
  args: { chdir: "{{ work_root }}" }

# ---- Kernel build (async, slow-link safe) ----
- name: Build kernel, modules, dtbs (async)
  shell: |
    nohup bash -c \
      "make -C '{{ ksources }}' O='{{ kbuild }}' ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
       -j$(nproc) Image modules dtbs" \
      > "{{ kbuild }}/kernel_build.log" 2>&1 & echo $! > "{{ kbuild }}/kernel_build.pid"
  async: 7200
  poll: 0

- name: Poll build completion
  shell: |
    pid=$(cat "{{ kbuild }}/kernel_build.pid" 2>/dev/null || true)
    if [ -n "$pid" ] && ps -p "$pid" >/dev/null 2>&1; then
      echo RUNNING
      exit 3
    fi
    [ -f "{{ kbuild }}/arch/arm64/boot/Image" ] && echo DONE || { echo FAIL; exit 2; }
  register: build_poll
  retries: 240
  delay: 15
  until: build_poll.rc != 3

- name: Fail if build failed
  fail: { msg: "Kernel build failed; see {{ kbuild }}/kernel_build.log" }
  when: build_poll.stdout != 'DONE'

- name: Install modules
  shell: make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} modules_install

- name: Install Image + dtbs
  shell: |
    set -euo pipefail
    install -m0644 "{{ kbuild }}/arch/arm64/boot/Image" /boot/Image
    rsync -a "{{ kbuild }}/arch/arm64/boot/dts/" /boot/dtb/

- name: Reboot into new kernel
  reboot:
    reboot_timeout: 180
    msg: "Rebooting to new kernel"
    pre_reboot_delay: 3
    post_reboot_delay: 15

- name: Verify kernelrelease
  shell: |
    set -e
    echo "running: $(uname -r)"
    test "$(uname -r)" = "$(cat {{ kbuild }}/include/config/kernel.release)"

# ---- HWPM OOT build/install ----
- name: Prepare headers for OOT
  shell: |
    make -C "{{ ksources }}" O="{{ kbuild }}" olddefconfig prepare modules_prepare
    make -C "{{ ksources }}" O="{{ kbuild }}" -s kernelrelease

- name: Build HWPM (OOT)
  shell: |
    set -euo pipefail
    CONFTEST="{{ kbuild }}/out/nvidia-conftest"
    make -C "{{ ksources }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
      M="{{ src_root }}/hwpm/drivers/tegra/hwpm" \
      EXTRA_CFLAGS="-DCONFIG_TEGRA_HWPM_OOT=1 -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest" \
      -j"$(nproc)" modules V=1
  args: { chdir: "{{ work_root }}" }

- name: Install HWPM module
  shell: |
    KREL=$(uname -r)
    install -D -m0644 "{{ src_root }}/hwpm/drivers/tegra/hwpm/nvhwpm.ko" \
      "/lib/modules/$KREL/extra/nvhwpm.ko"
    echo nvhwpm > /etc/modules-load.d/nvhwpm.conf
    depmod -a
    modprobe -v nvhwpm || true

# ---- Profile B only: install netfilter modules ----
- name: Build netfilter modules (Profile B)
  shell: |
    for d in net/netfilter net/ipv4/netfilter; do
      make -C "{{ ksources }}" O="{{ kbuild }}" M="{{ ksources }}/$d" -j"$(nproc)" modules;
    done
  when: profile_netfilter == 'modules'

- name: Install netfilter modules (Profile B)
  shell: |
    set -euo pipefail
    KREL=$(uname -r)
    install_one() { [ -f "$1" ] || return 0; install -D -m0644 "$1" "/lib/modules/$KREL/${2}"; }
    install_one "{{ kbuild }}/net/netfilter/x_tables.ko"                 "kernel/net/netfilter/x_tables.ko"
    install_one "{{ kbuild }}/net/netfilter/nfnetlink.ko"                "kernel/net/netfilter/nfnetlink.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_conntrack.ko"             "kernel/net/netfilter/nf_conntrack.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_defrag_ipv4.ko"           "kernel/net/netfilter/nf_defrag_ipv4.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_defrag_ipv6.ko"           "kernel/net/netfilter/nf_defrag_ipv6.ko"
    install_one "{{ kbuild }}/net/netfilter/nf_nat.ko"                   "kernel/net/netfilter/nf_nat.ko"
    install_one "{{ kbuild }}/net/ipv4/netfilter/ip_tables.ko"           "kernel/net/ipv4/netfilter/ip_tables.ko"
    install_one "{{ kbuild }}/net/ipv4/netfilter/iptable_filter.ko"      "kernel/net/ipv4/netfilter/iptable_filter.ko"
    install_one "{{ kbuild }}/net/ipv4/netfilter/iptable_nat.ko"         "kernel/net/ipv4/netfilter/iptable_nat.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_conntrack.ko"             "kernel/net/netfilter/xt_conntrack.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_MASQUERADE.ko"            "kernel/net/netfilter/xt_MASQUERADE.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_mark.ko"                  "kernel/net/netfilter/xt_mark.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_comment.ko"               "kernel/net/netfilter/xt_comment.ko"
    install_one "{{ kbuild }}/net/netfilter/xt_tcpudp.ko"                "kernel/net/netfilter/xt_tcpudp.ko"
    depmod -a
  when: profile_netfilter == 'modules'

- name: Post-boot validations
  shell: |
    set -e
    echo "KREL=$(uname -r)"; ls /proc/sys/net/bridge/bridge-nf-call-iptables
    ip link add name br0 type bridge || true; ip link del br0 || true
    if command -v iptables >/dev/null; then iptables -S | head -n5; fi
    modinfo nvhwpm | head -n5 || true
  changed_when: false
```

---

## 10) Why this works (lessons baked‑in)

* **Localversion discipline** → prevents vermagic drift (`5.15.148-tegra` exactly), so OOT modules load cleanly.
* **Config fragments** → tiny, owned deltas avoid fighting vendor defconfig & survive re‑runs.
* **Bridge & netfilter** → either built‑in (prefer) or rebuilt modules from the **same** tree, eliminating Unknown symbol/CRC mismatches.
* **Patched source\_sync** → consistent tag resolution (`jetson_36.4.4`), no more “wrong tree” surprises.
* **Idempotence** → `.regdom_patched` guard, fragment re‑merges, and path checks keep replays safe.
* **Slow links** → `nohup` + log, or Ansible `async/poll` ensures long compiles don’t break deployment.

---

## 11) Optional: VXLAN switch

Some Jetsons need VXLAN (e.g., flannel in VXLAN mode). Add a fragment when required:

```
# files01/30-vxlan.cfg
CONFIG_VXLAN=m
CONFIG_NET_UDP_TUNNEL=m
CONFIG_GENEVE=m
```

Then include it in the merge step when `enable_vxlan: true`.

---

### Final Notes

* Keep `files01.tgz` under version control with a **single source of truth**.
* If you ever see `Unknown symbol` while loading a module, confirm:
  `uname -r` == `cat $KBUILD/include/config/kernel.release` and **no `+dirty`**.
* If production cannot test, prefer **Profile A (built‑ins)**.

**End of guide.**
