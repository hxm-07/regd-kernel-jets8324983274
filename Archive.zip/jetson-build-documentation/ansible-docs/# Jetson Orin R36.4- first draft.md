# Jetson Orin R36.4.4 — BYOK Kernel + OOT Modules (NVGPU + K8s Bridge) — Production Playbook v1.0 @time 8-9-25

**Audience:** SRE/DevOps (ansible-first), no pre-prod test window.
**Devices:** Jetson Orin Nano/NX/AGX on JetPack **R36.4.4** (kernel **5.15.148-tegra**).
**Goal:** Reproduce our working system: clean kernel build (NVGPU built-in), required OOT modules, HWPM ko, and **bridge/netfilter** ready for Kubernetes.
**Paradigms supported:**

* **Track A (Preferred):** full BYOK kernel + built-ins (bridge=y) → reboot → K8s-ready.
* **Track B (Fallback):** keep stock kernel, compile/install only the missing net/bridge modules + HWPM.

> ⚠️ **Hard requirements**
>
> * Must match exact kernel release string **5.15.148-tegra** (no `+`, no extra suffix).
> * Use a **fresh timestamped workspace** per run.
> * Enforce **bridge=y** either by built-in (Track A) or by shipping all deps as modules (Track B).
> * OOT builds must include **workspace-specific conftest include paths**.

---

## 0) Inputs & Artifacts

### 0.1 Files from NVIDIA (present on the new Jetson or provided out-of-band)

* `Jetson_Linux_R36.4.4_aarch64.tbz2`
* `public_sources.tbz2`

### 0.2 Files we export from the **golden Jetson** (your current working box)

*(If any are missing on target, stop and request them.)*

| File                                             | Purpose                                                                 | Expected notes                    |
| ------------------------------------------------ | ----------------------------------------------------------------------- | --------------------------------- |
| `/home/ansible/files01/.config-5aug`             | Master kernel config with **NVGPU=y**, **bridge=y**, and our selections | Size reference: **299,473 bytes** |
| `/home/ansible/files01/init.c.adjusted`          | Crash kernel fix applied to `arch/arm64/mm/init.c`                      | Required before build             |
| `/home/ansible/files01/regd.c.modified`          | Realtek rtw88 regulatory-domain fix                                     | Optional if not using rtw88       |
| `/home/ansible/files01/atheros-ath9k-hackregd.c` | Atheros ath9k regulatory-domain fix                                     | Optional if not using ath9k       |
| `/home/ansible/files01/fix-regdom.sh`            | Extra regdomain compliance helper                                       | Optional                          |
| `/home/ansible/files01/gpu-Kconfig-patched`      | GPU Kconfig patch to expose NVGPU                                       | Required                          |
| `/home/ansible/files01/gpu-Makefile-patched`     | GPU Makefile patch                                                      | Required                          |

> Keep these under the same **files01/** path on the new Jetson for idempotency.

### 0.3 Variables (Ansible-friendly)

```bash
# Timestamped workspace
export WORK=/home/ansible/jetson-nvgpu-$(date +%Y%m%d_%H%M%S)
export SRC=$WORK/Linux_for_Tegra/source
export KSRC=$SRC/kernel-jammy-src          # “real” kernel source root
export KBUILD=$SRC/build                   # kernel build output (O=)
export KBUILD_PROBE=$SRC/build-probe       # optional config staging
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-
export OOT=$SRC/kernel/nvidia/nvidia-oot   # NVIDIA OOT tree
export CONFTEST=$SRC/out/nvidia-conftest   # workspace conftest dir
export SRCTREE_HWPM=$SRC/hwpm/drivers      # HWPM root (drivers/)
```

### 0.4 Preconditions (fail-fast)

* `uname -r` on target **must** be `5.15.148-tegra` (stock JetPack 36.4.4).
* At least **20GB free** under `/home/ansible` (or mount fast SSD and point `WORK` to it).
* Toolchain: `gcc-aarch64-linux-gnu`, `g++-aarch64-linux-gnu`, `build-essential`, `bc`, `bison`, `flex`, `libssl-dev`, `libncurses5-dev`, `git`, `rsync`.

---

## 1) Prepare clean workspace & extract sources

```bash
mkdir -p "$WORK" "$SRC"
cd "$WORK"
# Extract BSP and public sources
sudo tar -xf /home/ansible/jetson-r3644-full/Jetson_Linux_R36.4.4_aarch64.tbz2 -C "$WORK"
sudo tar -xf /home/ansible/jetson-r3644-full/public_sources.tbz2 -C "$WORK"

# Kernel wrappers inside L4T source dir
mkdir -p "$SRC/kernel" "$SRC/kernel/nvidia"
# Extract real kernel sources to $KSRC
mkdir -p "$KSRC"
# Prefer our patched NVIDIA sync script (fixes tag + tree layout)
install -m0755 /home/ansible/files01/source_sync.sh-modified "$SRC/source_sync.sh"
( cd "$SRC" && ./source_sync.sh -t jetson_36.4.4 )

# Fallback: manual extraction if the script is unavailable
# sudo tar -xf "$SRC/kernel_src.tbz2" -C "$KSRC" --strip-components=1
# sudo tar -xf "$SRC/kernel_oot_modules_src.tbz2" -C "$SRC/kernel/nvidia"
```

**Checks**

```bash
[ -f "$KSRC/Makefile" ] || { echo "Kernel src missing"; exit 1; }
[ -f "$KSRC/init/main.c" ] || { echo "Kernel tree bad"; exit 1; }
```

---

## 2) Patch kernel tree (pre-build)

```bash
# Apply crash fix
install -m0644 /home/ansible/files01/init.c.adjusted \
  "$KSRC/arch/arm64/mm/init.c"

# Wireless (optional, safe to always apply)
install -m0644 /home/ansible/files01/regd.c.modified \
  "$KSRC/drivers/net/wireless/realtek/rtw88/regd.c" || true
install -m0644 /home/ansible/files01/atheros-ath9k-hackregd.c \
  "$KSRC/drivers/net/wireless/ath/ath9k/regd.c" || true
/home/ansible/files01/fix-regdom.sh || true

# NVGPU integration
install -m0644 /home/ansible/files01/gpu-Kconfig-patched \
  "$KSRC/drivers/gpu/Kconfig"
install -m0644 /home/ansible/files01/gpu-Makefile-patched \
  "$KSRC/drivers/gpu/Makefile"

# HWPM UAPI header (required for HWPM module)
install -Dm0644 "$SRC/hwpm/include/uapi/linux/tegra-soc-hwpm-uapi.h" \
  "$KSRC/include/uapi/linux/tegra-soc-hwpm-uapi.h"
```

**Seed config & prepare**

```bash
mkdir -p "$KBUILD"
install -m0644 /home/ansible/files01/.config-5aug "$KBUILD/.config"
# Ensure stable localversion (verm tiny gotcha)
sed -i 's/^CONFIG_LOCALVERSION=.*/CONFIG_LOCALVERSION="-tegra"/' "$KBUILD/.config"
make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE modules_prepare
```

---

## 3) Critical: Protect bridge=built-in during build (Track A)

**Why:** some steps flip `CONFIG_BRIDGE=y → m`. We force it back **immediately after** `modules_prepare` and before the main build.

Create helper (once per workspace):

```bash
cat > "$SRC/fix-bridge-config-override.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f build/.config ] || { echo "run from L4T source root"; exit 1; }
cp /home/ansible/files01/.config-5aug build/.config
mkdir -p build/include/config build/include/generated
# Force into auto.conf
sed -i '/^CONFIG_BRIDGE/d;/^CONFIG_BRIDGE_NETFILTER/d' build/include/config/auto.conf 2>/dev/null || true
cat >> build/include/config/auto.conf <<CONF
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
CONF
# Force into autoconf.h
sed -i '/CONFIG_BRIDGE/d' build/include/generated/autoconf.h 2>/dev/null || true
cat >> build/include/generated/autoconf.h <<CONF
#define CONFIG_BRIDGE 1
#define CONFIG_BRIDGE_NETFILTER 1
CONF
EOF
chmod +x "$SRC/fix-bridge-config-override.sh"
```

Apply immediately:

```bash
"$SRC/fix-bridge-config-override.sh"
```

> **Gating checks**

```bash
grep -q '^CONFIG_BRIDGE=y' "$KBUILD/include/config/auto.conf" || { echo BRIDGE_BAD; exit 1; }
```

---

## 4) Build kernel (Track A)

```bash
# Full build (~45–60 min)
nohup make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE \
  -j"$(nproc)" Image modules dtbs > "$KBUILD/kernel_build.log" 2>&1 &
# Wait loop (optional)
while pgrep -f "Image modules dtbs" >/dev/null; do sleep 30; done

# Verify
[ -f "$KBUILD/arch/arm64/boot/Image" ] || { echo "No Image"; exit 1; }
REL=$(cat "$KBUILD/include/config/kernel.release"); echo "kernelrelease=$REL"
case "$REL" in *+*) echo "DIRTY VERSION ($REL)"; exit 1;; esac
```

**Deploy & reboot (Track A)**

```bash
sudo cp /boot/Image "/boot/Image.backup-$(date +%Y%m%d_%H%M%S)"
sudo cp "$KBUILD/arch/arm64/boot/Image" /boot/Image
sudo reboot
```

**Post-boot validations**

```bash
uname -r | grep -x '5.15.148-tegra'
# Bridge must be built-in now
grep '^CONFIG_BRIDGE=' /proc/config.gz | gunzip | cat || zcat /proc/config.gz | grep '^CONFIG_BRIDGE='
# Quick bridge sanity
sudo ip link add br-test type bridge && sudo ip link del br-test
```

> If Track A cannot be used (no reboot window), use **Track B** below to build/install only the missing bridge deps as modules.

---

## 5) Conftest (for any OOT build)

```bash
mkdir -p "$CONFTEST/nvidia"
rsync -a "$OOT/scripts/conftest/" "$CONFTEST/nvidia/"
make -j"$(nproc)" ARCH=$ARCH src="$CONFTEST/nvidia" obj="$CONFTEST/nvidia" \
  NV_KERNEL_SOURCES="$KSRC" NV_KERNEL_OUTPUT="$KBUILD" -f "$CONFTEST/nvidia/Makefile"
[ -f "$CONFTEST/nvidia/conftest/headers.h" ] || { echo "conftest headers missing"; exit 1; }
```

> Always compile OOT with:

```bash
export EXTRA_CFLAGS="-I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest"
```

---

## 6) Build HWPM (nvhwpm.ko) with compat shim

**Context:** L4T r36.4.4 headers expose `u8 tegra_get_*()`; HWPM’s compat header had conflicting `unsigned int` externs. We drop those conflicting externs before build.

```bash
# One-time header shim	sed -i \
  '/extern unsigned int tegra_get_chip_id/d; /extern unsigned int tegra_get_platform/d' \
  "$SRC/hwpm/drivers/tegra/hwpm/os/linux/soc_utils_compat.h"

# Build against running kernel headers
make -C "$KSRC" O="$KBUILD" ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE modules_prepare
make -C "$KBUILD" M="$SRCTREE_HWPM" \
  CONFIG_TEGRA_HWPM=m \
  EXTRA_CFLAGS="$EXTRA_CFLAGS" \
  -j"$(nproc)" modules

# Check artifact
[ -f "$SRC/hwpm/drivers/tegra/hwpm/nvhwpm.ko" ] || { echo "nvhwpm.ko missing"; exit 1; }
# VERM must match running kernel
modinfo "$SRC/hwpm/drivers/tegra/hwpm/nvhwpm.ko" | grep -q 'vermagic: *5.15.148-tegra '
```

**Install & load**

```bash
JETMODDIR="/lib/modules/$(uname -r)/extra"
sudo install -d "$JETMODDIR"
sudo install -m0644 "$SRC/hwpm/drivers/tegra/hwpm/nvhwpm.ko" "$JETMODDIR/"
sudo depmod -a
sudo modprobe -v nvhwpm || sudo insmod "$JETMODDIR/nvhwpm.ko"
# Optional: persist
echo nvhwpm | sudo tee /etc/modules-load.d/nvhwpm.conf >/dev/null
```

**Sanity**

```bash
lsmod | grep -i nvhwpm
sudo mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
sudo find /sys -maxdepth 4 -type d -iname '*hwpm*'
ls -l /dev/tegra-soc-hwpm || true
```

---

## 7) Build NVIDIA OOT modules (NVSCIIPC, nvethernet, …)

```bash
# Ensure config in place again (defensive)
install -m0644 /home/ansible/files01/.config-5aug "$KBUILD/.config"
make -C "$KBUILD" M="$OOT" \
  CONFIG_TEGRA_OOT_MODULE=m \
  EXTRA_CFLAGS="$EXTRA_CFLAGS" \
  KBUILD_EXTRA_SYMBOLS="$SRCTREE_HWPM/Module.symvers" \
  -j"$(nproc)" modules
```

**Install & update deps**

```bash
sudo make -C "$KSRC" O="$KBUILD" modules_install   # installs all built modules under /lib/modules/$(uname -r)
sudo depmod -a
```

**Key artifacts check**

```bash
ls -l "$OOT/drivers/misc/nvsciipc/nvsciipc.ko"
ls -l "$OOT/drivers/net/ethernet/nvidia/nvethernet/nvethernet.ko"
```

---

## 8) Track B (no reboot window): build & install just bridge deps as modules

If you **cannot** deliver a new kernel now, compile only what’s missing and install to the running kernel.

```bash
# Build specific net modules against KBUILD
for d in net/llc net/802 net/ipv6 net/bridge net/bridge/netfilter net/netfilter net/ipv4/netfilter; do
  make -C "$KSRC" O="$KBUILD" M="$KSRC/$d" -j"$(nproc)" modules
done

KREL=$(uname -r)
sudo install -D -m0644 "$KBUILD/net/ipv6/ipv6.ko"                    \
  "/lib/modules/$KREL/kernel/net/ipv6/ipv6.ko"
sudo install -D -m0644 "$KBUILD/net/llc/llc.ko"                      \
  "/lib/modules/$KREL/kernel/net/llc/llc.ko"
sudo install -D -m0644 "$KBUILD/net/802/stp.ko"                      \
  "/lib/modules/$KREL/kernel/net/802/stp.ko"
sudo install -D -m0644 "$KBUILD/net/bridge/bridge.ko"                \
  "/lib/modules/$KREL/kernel/net/bridge/bridge.ko"
# br_netfilter path exists only if built; guard it
if [ -f "$KBUILD/net/bridge/netfilter/br_netfilter.ko" ]; then
  sudo install -D -m0644 "$KBUILD/net/bridge/netfilter/br_netfilter.ko" \
    "/lib/modules/$KREL/kernel/net/bridge/netfilter/br_netfilter.ko"
fi
sudo depmod -a

# Try loading
sudo modprobe -v ipv6 llc stp bridge br_netfilter 2>/dev/null || true
# Enable K8s sysctls if br_netfilter present
if lsmod | grep -q br_netfilter; then
  echo 'net.bridge.bridge-nf-call-iptables=1' | sudo tee /etc/sysctl.d/99-k8s-brnf.conf
  echo 'net.bridge.bridge-nf-call-ip6tables=1' | sudo tee -a /etc/sysctl.d/99-k8s-brnf.conf
  sudo sysctl --system
fi
```

**Validation**

```bash
sudo ip link add br-test type bridge && sudo ip link del br-test || { echo BRIDGE_FAIL; exit 1; }
```

> This track is serviceable but **prefer Track A** (built-in bridge) for long-term K8s reliability.

---

## 9) HWPM & NVGPU runtime checks

```bash
# NVGPU present (built-in)
sudo cat /proc/kallsyms | grep -i nvgpu | head -n 5
# HWPM device and debugfs
sudo find /sys -maxdepth 4 -type d -iname '*hwpm*'
ls -l /dev/tegra-soc-hwpm || true
```

---

## 10) Packaging for reuse on another Jetson (same kernel release)

**HWPM only**

```bash
cd "$SRC/hwpm/drivers/tegra/hwpm"
tar czf nvhwpm-$(uname -r).tgz nvhwpm.ko
# On the other Jetson with **identical** `uname -r`:
tar xzf nvhwpm-5.15.148-tegra.tgz
sudo install -D -m0644 nvhwpm.ko \
  "/lib/modules/$(uname -r)/extra/nvhwpm.ko"
sudo depmod -a && sudo modprobe -v nvhwpm
```

**Full kernel image**

```bash
scp "$KBUILD/arch/arm64/boot/Image" jetson2:/tmp/Image-nvgpu-bridge
# On target:
sudo cp /boot/Image /boot/Image.backup-$(date +%Y%m%d_%H%M%S)
sudo cp /tmp/Image-nvgpu-bridge /boot/Image && sudo reboot
```

---

## 11) Rollback plan

```bash
# If new kernel fails:
sudo cp /boot/Image.backup-* /boot/Image && sudo reboot
# If modules break networking:
sudo rm -f /etc/sysctl.d/99-k8s-brnf.conf
sudo reboot
```

---

## 12) Ansible Playbook Skeleton (idempotent)

> Convert to roles as needed; run with `become: true`.

```yaml
- hosts: jetsons
  gather_facts: false
  vars:
    work: "/home/ansible/jetson-nvgpu-{{ lookup('pipe','date +%Y%m%d_%H%M%S') }}"
    src: "{{ work }}/Linux_for_Tegra/source"
    ksrc: "{{ src }}/kernel-jammy-src"
    kbuild: "{{ src }}/build"
    arch: arm64
    cross: aarch64-linux-gnu-
  pre_tasks:
    - name: Fail if kernel release mismatches
      command: uname -r
      register: ker
      failed_when: ker.stdout != '5.15.148-tegra'

    - name: Ensure packages
      apt:
        name:
          - gcc-aarch64-linux-gnu
          - g++-aarch64-linux-gnu
          - build-essential
          - bc
          - bison
          - flex
          - libssl-dev
          - libncurses5-dev
          - git
          - rsync
        state: present
        update_cache: yes

  tasks:
    - name: Create workspace
      file: { path: "{{ work }}", state: directory }

    - name: Extract BSP
      unarchive:
        src: /home/ansible/jetson-r3644-full/Jetson_Linux_R36.4.4_aarch64.tbz2
        dest: "{{ work }}"
        remote_src: true
      args:
        creates: "{{ work }}/Linux_for_Tegra"

    - name: Extract public sources
      unarchive:
        src: /home/ansible/jetson-r3644-full/public_sources.tbz2
        dest: "{{ work }}"
        remote_src: true

    - name: Extract kernel_src into ksrc
      shell: |
        mkdir -p "{{ ksrc }}"
        tar -xf "{{ src }}/kernel_src.tbz2" -C "{{ ksrc }}" --strip-components=1
      args: { creates: "{{ ksrc }}/Makefile" }

    - name: Extract kernel_oot_modules_src
      shell: |
        mkdir -p "{{ src }}/kernel/nvidia"
        tar -xf "{{ src }}/kernel_oot_modules_src.tbz2" -C "{{ src }}/kernel/nvidia"
      args: { creates: "{{ src }}/kernel/nvidia/nvidia-oot" }

    - name: Seed KBUILD and patches
      shell: |
        mkdir -p "{{ kbuild }}"
        install -m0644 /home/ansible/files01/.config-5aug "{{ kbuild }}/.config"
        sed -i 's/^CONFIG_LOCALVERSION=.*/CONFIG_LOCALVERSION="-tegra"/' "{{ kbuild }}/.config"
        install -m0644 /home/ansible/files01/init.c.adjusted "{{ ksrc }}/arch/arm64/mm/init.c"
        install -m0644 /home/ansible/files01/gpu-Kconfig-patched "{{ ksrc }}/drivers/gpu/Kconfig"
        install -m0644 /home/ansible/files01/gpu-Makefile-patched "{{ ksrc }}/drivers/gpu/Makefile"
        install -Dm0644 "{{ src }}/hwpm/include/uapi/linux/tegra-soc-hwpm-uapi.h" \
          "{{ ksrc }}/include/uapi/linux/tegra-soc-hwpm-uapi.h"
        true

    - name: modules_prepare
      shell: make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} modules_prepare

    - name: Force bridge built-in (Track A)
      shell: |
        cat > "{{ src }}/fix-bridge-config-override.sh" <<'EOF'
        #!/usr/bin/env bash
        set -euo pipefail
        cd "$(dirname "$0")"
        cp /home/ansible/files01/.config-5aug build/.config
        mkdir -p build/include/config build/include/generated
        sed -i '/^CONFIG_BRIDGE/d;/^CONFIG_BRIDGE_NETFILTER/d' build/include/config/auto.conf 2>/dev/null || true
        cat >> build/include/config/auto.conf <<CONF
        CONFIG_BRIDGE=y
        CONFIG_BRIDGE_NETFILTER=y
        CONF
        sed -i '/CONFIG_BRIDGE/d' build/include/generated/autoconf.h 2>/dev/null || true
        cat >> build/include/generated/autoconf.h <<CONF
        #define CONFIG_BRIDGE 1
        #define CONFIG_BRIDGE_NETFILTER 1
        CONF
        EOF
        chmod +x "{{ src }}/fix-bridge-config-override.sh"
        "{{ src }}/fix-bridge-config-override.sh"

    - name: Build kernel (Track A)
      shell: |
        nohup make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} -j"$(nproc)" Image modules dtbs > "{{ kbuild }}/kernel_build.log" 2>&1 &
        while pgrep -f "Image modules dtbs" >/dev/null; do sleep 30; done
        [ -f "{{ kbuild }}/arch/arm64/boot/Image" ]
        ! grep -q '+' "{{ kbuild }}/include/config/kernel.release"

    - name: Install kernel image (optional immediate)
      shell: |
        cp /boot/Image "/boot/Image.backup-$(date +%Y%m%d_%H%M%S)"
        cp "{{ kbuild }}/arch/arm64/boot/Image" /boot/Image
      when: false   # flip true to enable Track A deployment in same run

    - name: Conftest headers for OOT
      shell: |
        mkdir -p "{{ src }}/out/nvidia-conftest/nvidia"
        rsync -a "{{ src }}/kernel/nvidia/nvidia-oot/scripts/conftest/" "{{ src }}/out/nvidia-conftest/nvidia/"
        make -j"$(nproc)" ARCH={{ arch }} src="{{ src }}/out/nvidia-conftest/nvidia" obj="{{ src }}/out/nvidia-conftest/nvidia" NV_KERNEL_SOURCES="{{ ksrc }}" NV_KERNEL_OUTPUT="{{ kbuild }}" -f "{{ src }}/out/nvidia-conftest/nvidia/Makefile"

    - name: Build HWPM
      shell: |
        sed -i '/extern unsigned int tegra_get_chip_id/d; /extern unsigned int tegra_get_platform/d' \
          "{{ src }}/hwpm/drivers/tegra/hwpm/os/linux/soc_utils_compat.h"
        make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} modules_prepare
        EXTRA_CFLAGS="-I{{ src }}/out/nvidia-conftest/nvidia -I{{ src }}/out/nvidia-conftest/nvidia/conftest" \
        make -C "{{ kbuild }}" M="{{ src }}/hwpm/drivers" CONFIG_TEGRA_HWPM=m -j"$(nproc)" modules
        install -d "/lib/modules/$(uname -r)/extra"
        install -m0644 "{{ src }}/hwpm/drivers/tegra/hwpm/nvhwpm.ko" \
          "/lib/modules/$(uname -r)/extra/nvhwpm.ko"
        depmod -a

    - name: Build NVIDIA OOT modules
      shell: |
        EXTRA_CFLAGS="-I{{ src }}/out/nvidia-conftest/nvidia -I{{ src }}/out/nvidia-conftest/nvidia/conftest" \
        make -C "{{ kbuild }}" M="{{ src }}/kernel/nvidia/nvidia-oot" CONFIG_TEGRA_OOT_MODULE=m -j"$(nproc)" modules
        make -C "{{ ksrc }}" O="{{ kbuild }}" modules_install
        depmod -a

    - name: (Track B) Build & install only bridge deps
      shell: |
        for d in net/llc net/802 net/ipv6 net/bridge net/bridge/netfilter net/netfilter net/ipv4/netfilter; do
          make -C "{{ ksrc }}" O="{{ kbuild }}" M="{{ ksrc }}/$d" -j"$(nproc)" modules
        done
        KREL=$(uname -r)
        install -D -m0644 "{{ kbuild }}/net/ipv6/ipv6.ko"                    \
          "/lib/modules/$KREL/kernel/net/ipv6/ipv6.ko"
        install -D -m0644 "{{ kbuild }}/net/llc/llc.ko"                      \
          "/lib/modules/$KREL/kernel/net/llc/llc.ko"
        install -D -m0644 "{{ kbuild }}/net/802/stp.ko"                      \
          "/lib/modules/$KREL/kernel/net/802/stp.ko"
        install -D -m0644 "{{ kbuild }}/net/bridge/bridge.ko"                \
          "/lib/modules/$KREL/kernel/net/bridge/bridge.ko"
        if [ -f "{{ kbuild }}/net/bridge/netfilter/br_netfilter.ko" ]; then
          install -D -m0644 "{{ kbuild }}/net/bridge/netfilter/br_netfilter.ko" \
            "/lib/modules/$KREL/kernel/net/bridge/netfilter/br_netfilter.ko"
        fi
        depmod -a
      when: false  # flip true to use Track B instead of Track A

  handlers: []
```

---

## 13) Final verification (production gate)

```bash
# Kernel/verm check (Track A)
uname -r | grep -x '5.15.148-tegra'
# Bridge ready (A or B)
sudo ip link add br-test type bridge && sudo ip link del br-test
# NVGPU symbols (should be present, built-in)
sudo cat /proc/kallsyms | grep -i nvgpu | head -n 5
# HWPM
lsmod | grep -i nvhwpm || sudo modprobe -v nvhwpm
sudo mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
sudo find /sys -maxdepth 4 -type d -iname '*hwpm*'
```

---

### Notes & Gotchas (read once)

* **Vermagic drift**: ensure `CONFIG_LOCALVERSION="-tegra"` and no `+dirty` in `kernel.release`. If you see `-tegra-nvgpu` or any suffix mismatch, **stop** and fix before building modules.
* **Conftest**: always feed OOT builds with `EXTRA_CFLAGS` pointing at **this workspace’s** headers; do not rely on hardcoded default paths.
* **Bridge timing**: apply the bridge fix **immediately** after `modules_prepare` and **before** the main build; otherwise it flips to modules and K3s will break.
* **Repro across Jetsons**: you can ship just `nvhwpm.ko` (same `uname -r`), or the full `/boot/Image`. For different JetPack revs/kernels, rebuild.

---

**End of Playbook v1.0**

---

## v1.1 Update — Make it Fully Reproducible (files01 pack + stricter K8s netfilter)

This update turns the guide into a single‑source, ansible‑friendly flow you can run on a **fresh Jetson** (stock 5.15.148‑tegra) and end up in the same state as our golden box.

### A) files01/ — canonical inputs we ship from the golden Jetson

Place these under `/home/ansible/files01/` on the target before running Ansible:

**Required**

* `source_sync.sh-modified`  ⇢ our fixed sync script (uses tag `jetson_36.4.4`, correct layout).
* `.config-5aug`              ⇢ master config from the golden box (NVGPU=y, bridge=y).
* `gpu-Kconfig-patched`       ⇢ expose NVGPU in Kconfig.
* `gpu-Makefile-patched`      ⇢ NVGPU Makefile patch.
* `init.c.adjusted`           ⇢ crash fix for `arch/arm64/mm/init.c`.

**Optional (wifi regdom)**

* `regd.c.modified` (rtw88)
* `atheros-ath9k-hackregd.c` (ath9k)
* `fix-regdom.sh`

**New config fragments (add these files too)**

* `00-localversion.cfg`
* `20-k8s-netfilter-builtins.cfg`
* `25-k8s-container-deps.cfg`

> We *merge* these fragments over `.config-5aug` at build time, so the result is stable and idempotent.

---

### B) Content of the new config fragments

Copy‑paste exactly as below into the corresponding files under **files01/**.

**files01/00-localversion.cfg**

```
CONFIG_LOCALVERSION="-tegra"
CONFIG_LOCALVERSION_AUTO=n
# Keep NVIDIA defaults
CONFIG_MODVERSIONS=y
```

**files01/20-k8s-netfilter-builtins.cfg**  *(Prefer built-ins to avoid runtime module CRC issues)*

```
CONFIG_NETFILTER=y
CONFIG_XTABLES=y
CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y
CONFIG_NETFILTER_XT_MATCH_MARK=y
CONFIG_NETFILTER_XT_MATCH_COMMENT=y
CONFIG_NETFILTER_XT_MATCH_MULTIPORT=y
CONFIG_NETFILTER_XT_MATCH_TCPMSS=y
CONFIG_NETFILTER_XT_MATCH_OWNER=y
CONFIG_NETFILTER_XT_TARGET_MASQUERADE=y
CONFIG_NETFILTER_XT_TARGET_REDIRECT=y
CONFIG_NETFILTER_XT_TARGET_LOG=y
CONFIG_NF_CONNTRACK=y
CONFIG_NF_DEFRAG_IPV4=y
CONFIG_NF_DEFRAG_IPV6=y
CONFIG_NF_NAT=y
CONFIG_IP_NF_IPTABLES=y
CONFIG_IP_NF_FILTER=y
CONFIG_IP_NF_NAT=y
CONFIG_IP_NF_MANGLE=y
CONFIG_IP_NF_RAW=y
# Bridge path (already y in .config-5aug, enforced again here)
CONFIG_BRIDGE=y
CONFIG_BRIDGE_NETFILTER=y
```

**files01/25-k8s-container-deps.cfg**  *(CNI basics and useful extras)*

```
CONFIG_TUN=y
CONFIG_VETH=y
CONFIG_BRIDGE_VLAN_FILTERING=y
CONFIG_NETFILTER_XT_MATCH_ADDRTYPE=y
# Often used by CNIs (Flannel/Calico) for overlays — enable if you plan to use it
CONFIG_VXLAN=y
```

> If you have a CNI that uses nftables instead of iptables, we can add an `nftables` fragment too — but the above covers the common iptables path K3s uses.

---

### C) Ansible — Production Playbook v1.1 (idempotent, Track A default)

This version:

* Installs our **modified** `source_sync.sh`.
* Seeds `.config-5aug`, then merges the fragments above.
* Forces stable `-tegra` localversion, prevents `+dirty`.
* Builds the BYOK kernel with **bridge + netfilter built-ins**.
* Builds/installs **HWPM** and **NVIDIA OOT** modules with correct conftest includes.

```yaml
- hosts: jetsons
  gather_facts: false
  vars:
    work: "/home/ansible/jetson-nvgpu-{{ lookup('pipe','date +%Y%m%d_%H%M%S') }}"
    src: "{{ work }}/Linux_for_Tegra/source"
    ksrc: "{{ src }}/kernel-jammy-src"
    kbuild: "{{ src }}/build"
    arch: arm64
    cross: aarch64-linux-gnu-
    files01: "/home/ansible/files01"
  pre_tasks:
    - name: Ensure toolchain and utils
      apt:
        name:
          - gcc-aarch64-linux-gnu
          - g++-aarch64-linux-gnu
          - build-essential
          - bc
          - bison
          - flex
          - libssl-dev
          - libncurses5-dev
          - git
          - rsync
        state: present
        update_cache: yes

    - name: Verify running kernel matches JetPack 36.4.4
      command: uname -r
      register: ker
      failed_when: ker.stdout != '5.15.148-tegra'

  tasks:
    - name: Create workspace
      file: { path: "{{ work }}", state: directory }

    - name: Extract BSP + sources
      shell: |
        set -e
        tar -xf /home/ansible/jetson-r3644-full/Jetson_Linux_R36.4.4_aarch64.tbz2 -C "{{ work }}"
        tar -xf /home/ansible/jetson-r3644-full/public_sources.tbz2 -C "{{ work }}"
        install -m0755 "{{ files01 }}/source_sync.sh-modified" "{{ src }}/source_sync.sh"
        ( cd "{{ src }}" && ./source_sync.sh -t jetson_36.4.4 )
        test -f "{{ ksrc }}/Makefile"

    - name: Seed patches & headers
      shell: |
        set -e
        install -m0644 "{{ files01 }}/init.c.adjusted" "{{ ksrc }}/arch/arm64/mm/init.c"
        install -m0644 "{{ files01 }}/gpu-Kconfig-patched"  "{{ ksrc }}/drivers/gpu/Kconfig"
        install -m0644 "{{ files01 }}/gpu-Makefile-patched" "{{ ksrc }}/drivers/gpu/Makefile"
        install -Dm0644 "{{ src }}/hwpm/include/uapi/linux/tegra-soc-hwpm-uapi.h" \
          "{{ ksrc }}/include/uapi/linux/tegra-soc-hwpm-uapi.h"
        mkdir -p "{{ kbuild }}"
        install -m0644 "{{ files01 }}/.config-5aug" "{{ kbuild }}/.config"

    - name: Prepare and normalize KBUILD
      shell: |
        set -e
        sed -i 's/^CONFIG_LOCALVERSION=.*/CONFIG_LOCALVERSION="-tegra"/' "{{ kbuild }}/.config"
        make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} modules_prepare

    - name: Merge config fragments (localversion + K8s built-ins + container deps)
      shell: |
        set -e
        "{{ ksrc }}"/scripts/kconfig/merge_config.sh -m -O "{{ kbuild }}" \
          "{{ kbuild }}/.config" \
          "{{ files01 }}/00-localversion.cfg" \
          "{{ files01 }}/20-k8s-netfilter-builtins.cfg" \
          "{{ files01 }}/25-k8s-container-deps.cfg"
        make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} olddefconfig

    - name: Assert bridge + netfilter are built-in
      shell: |
        egrep -q '^CONFIG_BRIDGE=y$'  "{{ kbuild }}/.config"
        egrep -q '^CONFIG_NETFILTER=y$' "{{ kbuild }}/.config"
        egrep -q '^CONFIG_NF_CONNTRACK=y$' "{{ kbuild }}/.config"

    - name: Build kernel (Image/modules/dtbs)
      shell: |
        set -e
        nohup make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} \
          -j"$(nproc)" Image modules dtbs > "{{ kbuild }}/kernel_build.log" 2>&1 &
        while pgrep -f "Image modules dtbs" >/dev/null; do sleep 30; done
        test -f "{{ kbuild }}/arch/arm64/boot/Image"
        ! grep -q '+' "{{ kbuild }}/include/config/kernel.release"

    - name: (Optional now) Install Image & reboot
      shell: |
        cp /boot/Image "/boot/Image.backup-$(date +%Y%m%d_%H%M%S)"
        cp "{{ kbuild }}/arch/arm64/boot/Image" /boot/Image
      when: false

    - name: Build conftest headers for OOT
      shell: |
        set -e
        mkdir -p "{{ src }}/out/nvidia-conftest/nvidia"
        rsync -a "{{ src }}/kernel/nvidia/nvidia-oot/scripts/conftest/" "{{ src }}/out/nvidia-conftest/nvidia/"
        make -j"$(nproc)" ARCH={{ arch }} src="{{ src }}/out/nvidia-conftest/nvidia" obj="{{ src }}/out/nvidia-conftest/nvidia" \
          NV_KERNEL_SOURCES="{{ ksrc }}" NV_KERNEL_OUTPUT="{{ kbuild }}" -f "{{ src }}/out/nvidia-conftest/nvidia/Makefile"

    - name: Build & install HWPM
      shell: |
        set -e
        sed -i '/extern unsigned int tegra_get_chip_id/d; /extern unsigned int tegra_get_platform/d' \
          "{{ src }}/hwpm/drivers/tegra/hwpm/os/linux/soc_utils_compat.h"
        make -C "{{ ksrc }}" O="{{ kbuild }}" ARCH={{ arch }} CROSS_COMPILE={{ cross }} modules_prepare
        EXTRA_CFLAGS="-I{{ src }}/out/nvidia-conftest/nvidia -I{{ src }}/out/nvidia-conftest/nvidia/conftest" \
        make -C "{{ kbuild }}" M="{{ src }}/hwpm/drivers" CONFIG_TEGRA_HWPM=m -j"$(nproc)" modules
        install -d "/lib/modules/$(uname -r)/extra"
        install -m0644 "{{ src }}/hwpm/drivers/tegra/hwpm/nvhwpm.ko" \
          "/lib/modules/$(uname -r)/extra/nvhwpm.ko"
        depmod -a

    - name: Build & install NVIDIA OOT modules
      shell: |
        set -e
        EXTRA_CFLAGS="-I{{ src }}/out/nvidia-conftest/nvidia -I{{ src }}/out/nvidia-conftest/nvidia/conftest" \
        make -C "{{ kbuild }}" M="{{ src }}/kernel/nvidia/nvidia-oot" CONFIG_TEGRA_OOT_MODULE=m -j"$(nproc)" modules
        make -C "{{ ksrc }}" O="{{ kbuild }}" modules_install
        depmod -a

    - name: Enable K8s bridge sysctls
      copy:
        dest: /etc/sysctl.d/99-k8s-brnf.conf
        content: |
          net.bridge.bridge-nf-call-iptables=1
          net.bridge.bridge-nf-call-ip6tables=1
      notify: [sysctl-apply]

  handlers:
    - name: sysctl-apply
      command: sysctl --system
```

---

### D) Decision guide (what you run in prod)

* **Go with Track A** (BYOK + built-in netfilter/bridge).
  **Effort:** medium, **Success odds:** \~99%, **Runtime risk:** low.
  You avoid module CRC/version mismatches and K3s works out of the box.
* Track B (stock kernel + shipping only modules) is serviceable for emergency, but **risk of CRC mismatches** is high if you ever rebuild from a different tree.

---

### E) What I still need from you to lock this down

1. Upload the exact files from your golden box so we bake them into `files01/`:

   * `/home/ansible/files01/source_sync.sh-modified`
   * `/home/ansible/files01/.config-5aug`
   * `/home/ansible/files01/gpu-Kconfig-patched`
   * `/home/ansible/files01/gpu-Makefile-patched`
   * `/home/ansible/files01/init.c.adjusted`
   * (Optionally) the two regdom files + `fix-regdom.sh`.
2. Confirm your intended CNI (Flannel/Calico/etc.). If VXLAN isn’t needed, I’ll drop it from `25-k8s-container-deps.cfg`.

Once you drop those in, you can run the playbook here as a full dress rehearsal on this Jetson. If it passes, we stamp it as v1.1 and roll to the next unit with the exact same artifacts.
