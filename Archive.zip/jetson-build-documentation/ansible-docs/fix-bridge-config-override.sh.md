# Shareholder Report — Jetson Kernel Build Effort (Week of 8–9 Aug)

## What happened

We rebuilt a custom Linux kernel for Jetson (5.15-based, NVIDIA L4T) with a small but critical networking policy: **bridge filtering must be built-in**, not modular. During standard Kconfig normalization (“olddefconfig” and the automatic “syncconfig”), the toolchain kept **downgrading** the bridge features from built-in to modules. This is expected behavior when dependencies are not met; Kconfig always recomputes generated files (`auto.conf`, `autoconf.h`) from `.config` and will overwrite manual edits. We fixed the dependency chain at the **input** (.config) rather than editing generated outputs, per kernel policy. ([Linux Kernel Documentation][1], [GitLab][2])

## Why it happened

1. **Kconfig normalization is authoritative.** “olddefconfig” resolves every option; “syncconfig” regenerates `auto.conf` and `autoconf.h` as soon as `.config` or any Kconfig file changes. Attempting to edit the generated files is non-persistent. ([Linux Kernel Documentation][1], [GitLab][2])
2. **Bridge had a hard constraint.** In 5.x, `CONFIG_BRIDGE` includes a rule: **`depends on IPV6 || IPV6=n`**. With IPv6 set to **module**, the solver refuses `BRIDGE=y` and forces “module” instead. We switched IPv6 to **built-in**, which unlocked `BRIDGE=y`. ([Android Git Repositories][3], [git.toradex.com][4])
3. **`BRIDGE_NETFILTER` inherits further deps.** It requires `BRIDGE && NETFILTER && INET && NETFILTER_ADVANCED`. We pinned all of them to **built-in** so the solver wouldn’t demote the setting. ([lxr.missinglinkelectronics.com][5], [kernelconfig.io][6])

## What we achieved

* **Clean, reproducible kernel config.** After enforcing the minimal fragment (`NET=y`, `INET=y`, `IPV6=y`, `NETFILTER=y`, `NETFILTER_ADVANCED=y`, `BRIDGE=y`, `BRIDGE_NETFILTER=y`, plus `LLC=y`, `STP=y`), a fresh normalization produced `.config` with **all targets = y**. A subsequent `modules_prepare` regenerated `auto.conf` and `autoconf.h` that also show **`CONFIG_BRIDGE=y`**—confirming persistence through the generated layer. ([GitLab][2])
* **Version hygiene restored.** We reasserted `CONFIG_LOCALVERSION_AUTO=n` to keep a stable release string (no “+” or git suffixes); this is the documented control for version suffix behavior. ([cateee.net][7], [Unix & Linux Stack Exchange][8])
* **Process hardening.** We replaced ad-hoc edits with the upstream `merge_config.sh` flow, which explicitly warns when a requested value cannot stick due to missing dependencies or removed symbols. ([coral.googlesource.com][9])

## What we learned

* **Don’t edit generated headers.** `auto.conf` / `autoconf.h` are rebuilt by Kconfig on demand; changes there are discarded. The only durable control surface is `.config`, resolved via `olddefconfig` and friends. ([GitLab][2])
* **Tristate options follow the “lowest dependency.”** If a dependency is modular, the top option can’t be `=y`. This is why IPv6’s mode controlled the bridge outcome. ([Android Git Repositories][3])
* **Out-of-tree (OOT) modules have a separate lifecycle.** When a feature’s Kconfig isn’t sourced by the kernel (e.g., vendor GPU/HWPM stacks), its symbols will be stripped during normalization. Those components must be built as **external modules** after `modules_prepare`, per kbuild guidance. ([Linux Kernel Documentation][10])

## What is not possible (by design)

* **Forcing `BRIDGE=y` with `IPV6=m`.** The kernel’s Kconfig explicitly blocks this combination to avoid link-time failures in the bridge multicast path. Either build IPv6 in, or disable it entirely; otherwise `BRIDGE` will remain modular. ([Android Git Repositories][3], [GitLab][11])
* **Persisting settings by patching `auto.conf` / `autoconf.h`.** These files are **always** regenerated from `.config` by “syncconfig” and will not retain manual edits. ([GitLab][2])

## What we missed (and corrected)

* The original flow tried to “fix” outputs after the fact. That fights Kconfig and fails on the next regeneration. We removed those steps and **moved all enforcement into fragments** merged before normalization, which is the supported method. ([coral.googlesource.com][9])

## Business impact

* **Networking:** Built-in bridge filtering is now guaranteed at boot, eliminating boot-time races or module-load ordering hazards for Kubernetes/CNI stacks that rely on bridge/Netfilter hooks.
* **Reproducibility:** The build is deterministic across machines and rebuilds. Config drift is eliminated.
* **Scope clarity:** GPU/HWPM remain **out of tree** for this kernel; they are handled as external modules using the standard kbuild process (`modules_prepare`, proper headers/Module.symvers). ([Linux Kernel Documentation][10])

## Next steps (short)

1. Freeze the proven fragment in source control and apply it in every build via `merge_config.sh`; run `olddefconfig` before compiling. ([coral.googlesource.com][9])
2. Keep IPv6 **built-in** (or fully disabled) to preserve `BRIDGE=y`. Changing IPv6 back to “module” will revert the bridge to “module” by design. ([Android Git Repositories][3])
3. Build NVIDIA GPU/HWPM as **external modules** against the prepared kernel headers, per the upstream OOT module process. ([Linux Kernel Documentation][10])

This closes the bridge configuration defect with low risk and standard tooling, and leaves a clear, supported path for vendor OOT drivers.

[1]: https://docs.kernel.org/kbuild/kconfig.html?utm_source=chatgpt.com "Configuration targets and editors"
[2]: https://git.gitlab.arm.com/arm-reference-solutions/linux/-/commit/d79424137a7312d381d131d707a462440c0e8df9?utm_source=chatgpt.com "kbuild: do not update config when running install targets ..."
[3]: https://android.googlesource.com/kernel/common/%2B/1b940dd55d42/net/bridge/Kconfig?utm_source=chatgpt.com "net/bridge/Kconfig - kernel/common - Git at Google"
[4]: https://git.toradex.com/cgit/linux-toradex.git/tree/net/bridge/Kconfig?h=toradex_5.15-2.2.x-imx&id=40d102cde0a2aabb5e542ab1ab1aa4aaa1fd4372&utm_source=chatgpt.com "Kconfig « bridge « net - linux-toradex.git"
[5]: https://lxr.missinglinkelectronics.com/linux/net/bridge/netfilter/Kconfig?utm_source=chatgpt.com "LXR linux/net/bridge/netfilter/Kconfig - Missing Link Electronics"
[6]: https://www.kernelconfig.io/config_bridge_netfilter?utm_source=chatgpt.com "config_bridge_netfilter"
[7]: https://cateee.net/lkddb/web-lkddb/LOCALVERSION_AUTO.html?utm_source=chatgpt.com "CONFIG_LOCALVERSION_AUTO: Automatically append ..."
[8]: https://unix.stackexchange.com/questions/194129/linux-kernel-version-suffix-config-localversion?utm_source=chatgpt.com "Linux kernel version suffix + CONFIG_LOCALVERSION"
[9]: https://coral.googlesource.com/linux-imx/%2B/refs/tags/6-3/scripts/kconfig/merge_config.sh?utm_source=chatgpt.com "scripts/kconfig/merge_config.sh - linux-imx"
[10]: https://docs.kernel.org/kbuild/modules.html?utm_source=chatgpt.com "Building External Modules"
[11]: https://git.gitlab.arm.com/linux-arm/linux-vs/-/commit/dcbcdf22f500ac6e4ec06485341024739b9dc241?utm_source=chatgpt.com "net: bridge builtin vs. ipv6 modular (dcbcdf22) - linux-arm"
