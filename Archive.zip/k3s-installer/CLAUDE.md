# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Common Commands

### Deployment Commands
- **Deploy the complete system**: `ansible-playbook playbooks/main.yml --ask-become-pass`
- **Test GPU functionality only**: `ansible-playbook test-gpu.yml --ask-become-pass`
- **Test networking components only**: `ansible-playbook test-networking.yml --ask-become-pass`
- **Test Phase 2 components only**: `ansible-playbook test-phase2.yml --ask-become-pass`
- **Override default power mode**: `ansible-playbook playbooks/main.yml --extra-vars "sel_nvpmodel=0" --ask-become-pass`
- **Check Ansible syntax**: `ansible-playbook --syntax-check playbooks/main.yml`
- **Dry run deployment**: `ansible-playbook --check playbooks/main.yml --ask-become-pass`

### Validation Commands
- **Week 1 validation**: `bash files/validation-week1.sh`
- **Complete system validation**: `bash files/validation-complete.sh`

### Prerequisites Setup
```bash
# Install Ansible collections
ansible-galaxy collection install kubernetes.core community.general ansible.posix

# Verify Jetson power mode
ssh ubuntu@<jetson_ip> "sudo nvpmodel -q"

# Check NVIDIA runtime
ssh ubuntu@<jetson_ip> "sudo ctr --namespace k8s.io plugins ls | grep nvidia"
```

### Post-Deployment Verification
```bash
# Set kubeconfig for local access
export KUBECONFIG=./kubeconfig

# Check GPU allocation
kubectl describe node | grep -A2 nvidia.com/gpu

# Check Linkerd health
~/.linkerd2/bin/linkerd check

# Check LoadBalancer services
kubectl get svc -A | grep LoadBalancer

# Test AI workload with TLS
TRAEFIK_IP=$(kubectl -n traefik-system get svc traefik -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
curl -k --resolve ai.edge.local:443:$TRAEFIK_IP https://ai.edge.local
```

## High-Level Architecture

This is an Ansible-automated implementation for deploying a lean single-node Kubernetes edge computing platform on Jetson Orin Nano 8GB hardware.

### Two-Phase Deployment Structure

**Phase 1 - Foundation Setup**:
- `preflight-audit`: Validates JetPack version compatibility (requires R36+)
- `jetson-optimize`: Configures performance mode, NVMe storage, zram, and kernel settings
- `k3s-install`: Installs K3s with GPU support and optimized settings
- `gpu-setup`: Configures NVIDIA device plugin and validates GPU access
- `networking`: Deploys MetalLB load balancer and Traefik ingress (Linkerd service mesh disabled due to kernel module requirements)

**Phase 2 - Workloads and Monitoring**:
- `monitoring`: Deploys VictoriaMetrics with custom Jetson hardware exporter and Grafana
- `security-foundation`: Applies Pod Security Standards across namespaces
- `ai-workloads`: Deploys GPU-accelerated PyTorch workload with TLS-enabled ingress

### Key Components and Paths

- **Storage Configuration**: Uses `/ssd` path for NVMe storage with K3s data at `/ssd/rancher/k3s`
- **Network Configuration**: Cluster CIDR `10.42.0.0/16`, Service CIDR `10.43.0.0/16`
- **Performance Tuning**: Custom zram configuration (4GB across 6 devices), jetson_clocks optimization
- **Security**: Pod Security Standards enforcement, Let's Encrypt TLS certificates (Linkerd mTLS disabled due to kernel module requirements)
- **Monitoring**: Custom Jetson hardware metrics exporter on port 9100, VictoriaMetrics scraping

### Configuration Files

- `inventory/hosts.yml`: Target Jetson device configuration and SSH settings
- `group_vars/all.yml`: Global variables including K3s version, network CIDRs, and resource limits
- `ansible.cfg`: Ansible configuration with roles path and inventory settings

### Role Structure Pattern

Each role follows standard Ansible structure:
- `tasks/main.yml`: Primary task definitions
- `handlers/main.yml`: Service restart handlers
- `templates/`: Jinja2 templates for configuration files
- `files/`: Static files for deployment

### Validation and Testing

The deployment includes comprehensive validation scripts that check:
- Jetson performance mode and GPU availability
- K3s cluster health and node labeling
- Ingress controller (Traefik) connectivity
- Load balancer IP assignment
- AI workload GPU utilization and logs
- Hardware monitoring metrics endpoint

Configuration variables in `group_vars/all.yml` must be updated for your specific network environment, particularly `metallb_ip_range` and the Jetson IP address in inventory.

### Linkerd Service Mesh (Currently Disabled)

**Important**: Linkerd service mesh is currently disabled due to kernel module requirements. The default Jetson kernel lacks the `iptables owner` module required for Linkerd's proxy initialization.

**To enable Linkerd after kernel rebuild**:
1. Ensure kernel has `iptables owner` module support
2. Uncomment Linkerd tasks in `roles/networking/tasks/main.yml`
3. Uncomment `linkerd.io/inject: enabled` in Traefik deployment configuration
4. Run: `sudo update-alternatives --set iptables /usr/sbin/iptables-legacy`
5. Run: `sudo update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy`

**Benefits of enabling Linkerd**:
- Automatic mTLS between all services
- Advanced traffic management and observability  
- Zero-trust security model
- Service mesh integration with Traefik for edge-to-backend encryption

## Recent Changes and Known Issues

### Major Changes Made During Deployment Testing:

**1. SSH Configuration (Fixed)**
- **Before**: Used default 'ubuntu' user which caused SSH connection failures
- **After**: Updated to use 'ansible' user with SSH config alias 'nanos1'
- **Files Changed**: `inventory/hosts.yml`

**2. Variable Loading Issues (Fixed)**
- **Before**: `vars_prompt` had undefined variable reference causing deployment failure
- **After**: Changed default from `"{{ jetson_performance_mode }}"` to `"2"`
- **Files Changed**: `playbooks/main.yml`

**3. nvpmodel Detection (Fixed)**
- **Before**: Invalid command syntax caused performance mode validation to fail
- **After**: Fixed parsing command to properly detect available power modes (0,1,2,3)
- **Files Changed**: `roles/jetson-optimize/tasks/main.yml`

**4. NVMe Storage Handling (Enhanced)**
- **Before**: Failed when system running from NVMe root filesystem
- **After**: Added detection and adjusted storage paths to `/var/lib/jetson`
- **Files Changed**: `roles/jetson-optimize/tasks/main.yml`

**5. GPU Setup Image Issues (Fixed)**
- **Before**: Used non-existent PyTorch image `nvcr.io/nvidia/l4t-pytorch:r36.4.0-pth2.1-py3`
- **After**: Updated to working CUDA image `nvcr.io/nvidia/l4t-cuda:12.2.12-devel`
- **Files Changed**: `roles/gpu-setup/tasks/main.yml`, `roles/ai-workloads/tasks/main.yml`

**6. Linkerd Service Mesh (Disabled)**
- **Before**: Attempted to install Linkerd but failed due to missing iptables owner module
- **After**: Commented out all Linkerd tasks, documented requirements for future kernel rebuild
- **Files Changed**: `roles/networking/tasks/main.yml`, `roles/ai-workloads/tasks/main.yml`
- **Reason**: Default Jetson kernel lacks `iptables owner` module required for Linkerd proxy initialization

**7. Container Runtime Configuration (Fixed)**
- **Before**: K3s pause image had problematic SHA hash causing container creation failures
- **After**: Removed SHA hash, using `registry.k8s.io/pause:3.9`
- **Files Changed**: `group_vars/all.yml`

**8. Monitoring Stack (Enhanced)**
- **Before**: Used VictoriaMetrics Operator which had download issues
- **After**: Simplified to standalone VictoriaMetrics with direct deployment
- **Files Changed**: `roles/monitoring/tasks/main.yml`

**9. Grafana Storage (Fixed)**
- **Before**: Used hostPath volume which violated Pod Security Standards
- **After**: Changed to emptyDir volume with proper securityContext
- **Files Changed**: `roles/monitoring/tasks/main.yml`

**10. AI Workload Enhancement (Improved)**
- **Before**: Basic Python script with minimal functionality
- **After**: Enhanced with proper GPU detection using nvidia-smi and better logging
- **Files Changed**: `roles/ai-workloads/tasks/main.yml`

**11. Security Policies (Updated)**
- **Before**: monitoring namespace used 'baseline' policy blocking hostPath volumes
- **After**: Updated monitoring to 'privileged', enabled edge-demo namespace policy
- **Files Changed**: `roles/security-foundation/tasks/main.yml`

**12. Kubeconfig Access (Automated)**
- **Before**: Manual kubeconfig copying required for local kubectl access
- **After**: Automated download with setup instructions displayed after deployment
- **Files Changed**: `playbooks/main.yml`

### Test Files Added:
- `test-gpu.yml`: Standalone GPU functionality testing
- `test-networking.yml`: Network components testing (MetalLB, Traefik)
- `test-phase2.yml`: Phase 2 components testing (monitoring, security, AI workloads)

**13. Let's Encrypt ACME (Disabled)**
- **Before**: Traefik configured with placeholder email causing potential ACME failures
- **After**: ACME disabled for local edge deployment, commented production settings
- **Files Changed**: `roles/networking/tasks/main.yml`

**14. Validation Scripts (Updated)**
- **Before**: Referenced Linkerd service mesh and hardcoded paths
- **After**: Updated to check Traefik ingress and support variable storage paths  
- **Files Changed**: `files/validation-week1.sh`, `files/validation-complete.sh`

**15. GPU Device Plugin Privileged Access (Fixed)**
- **Before**: Device plugin couldn't access GPU hardware due to insufficient permissions
- **After**: Added privileged security context and proper volume mounts for /dev and /sys
- **Result**: GPU resources properly exposed, test pods can schedule successfully  
- **Files Changed**: `roles/gpu-setup/tasks/main.yml`

**16. MetalLB IP Range Network Fix (Fixed)**
- **Before**: Used incorrect subnet `192.168.1.240-250` causing LoadBalancer IPs to be unreachable
- **After**: Updated to correct ethernet subnet `192.168.87.240-250` matching actual network
- **Result**: LoadBalancer IPs now accessible, HTTP ingress working
- **Files Changed**: `group_vars/all.yml`

**17. AI Workload HTTP API (Enhanced)**
- **Before**: Simple log-only processing demonstration
- **After**: Full HTTP API server serving live JSON data with GPU detection
- **Features**: Updates every 30 seconds, accessible via `http://ai.edge.local/`
- **Files Changed**: `roles/ai-workloads/tasks/main.yml`

**18. Timeout Handling Improvements (Fixed)**
- **Before**: Conservative timeout values causing deployment failures during image pulls
- **After**: Industry-standard `kubectl wait` with connection validation and circuit breaker patterns
- **Result**: Robust deployments that handle edge cases gracefully
- **Files Changed**: `roles/gpu-setup/tasks/main.yml`, `roles/networking/tasks/main.yml`

**19. Traefik LoadBalancer Class Issue (Fixed)**
- **Before**: Traefik service stuck in `<pending>` state due to `loadBalancerClass: metallb.io/metallb` annotation
- **After**: Added detection and removal of problematic loadBalancerClass field during deployment
- **Result**: Traefik LoadBalancer IP assigned correctly (e.g., 192.168.1.241)
- **Files Changed**: `roles/networking/tasks/main.yml`

**20. MetalLB Dual Interface Support (Enhanced)**
- **Before**: Only supported single interface (`eno1` or `wlP1p1s0`)
- **After**: L2 advertisement configured for both ethernet and wireless interfaces
- **Result**: Automatic failover between wired/wireless connectivity
- **Files Changed**: `roles/networking/tasks/main.yml`

### Current Working Configuration (Single-Shot Deployment Ready):
- **OS**: Ubuntu 22.04 on Jetson Orin Nano 8GB
- **JetPack**: R36.4.4 
- **K3s**: v1.30.0+k3s1
- **Container Images**: All using L4T R36.x compatible images
- **Network**: iptables mode (not eBPF) due to kernel limitations
- **LoadBalancer**: MetalLB L2 mode with dual interface support (eno1 + wlP1p1s0), range .240-.250
- **Ingress**: Traefik with IngressRoute (traefik.io/v1alpha1 API), loadBalancerClass issue fixed
- **GPU**: Device plugin with privileged access, resources properly exposed
- **Storage**: NVMe root filesystem with paths adjusted to `/var/lib/jetson`
- **TLS**: Let's Encrypt ACME disabled for local deployment
- **AI Workload**: HTTP API serving live GPU status via `http://ai.edge.local/`
- **Monitoring**: VictoriaMetrics + Grafana with Jetson hardware metrics
- **Security**: Pod Security Standards - edge-demo namespace set to privileged for GPU access
- **Remote Access**: SSH tunnel support for SD-WAN environments