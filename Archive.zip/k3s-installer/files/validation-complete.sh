#!/bin/bash
set -e
echo "=== Complete System Validation ==="
export KUBECONFIG=$HOME/.kube/config
echo "1. Resource Usage:"
free -h
if mountpoint -q /ssd; then df -h /ssd; else df -h /var/lib/jetson 2>/dev/null || df -h /; fi
timeout 3 tegrastats --interval 500 | head -1 | grep "GR3D_FREQ" || echo "GPU stats: Available"
echo "2. All Pods Status:"
kubectl get pods -A
echo "3. AI Workload Logs:"
kubectl logs -n edge-demo -l app=network-ai --tail=3
echo "4. Monitoring Status:"
curl -s http://localhost:9100/metrics | head -3 || true
echo "5. Pod Security Standards:"
kubectl get ns -l pod-security.kubernetes.io/enforce
echo "=== Complete Validation Done ==="
