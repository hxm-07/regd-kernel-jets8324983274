#!/bin/bash
set -e
echo "=== Week 1 Foundation Validation ==="
export KUBECONFIG=$HOME/.kube/config
echo "1. Performance Mode:"
sudo $(command -v nvpmodel) -q
echo "2. K3s Cluster Status:"
kubectl get nodes -o wide
echo "3. GPU Resources:"
kubectl describe nodes | grep nvidia.com/gpu
echo "4. Ingress Controller Status:"
kubectl get pods -n traefik-system
echo "5. Load Balancer Status:"
kubectl get svc -A | grep LoadBalancer
echo "=== Week 1 Validation Complete ==="
