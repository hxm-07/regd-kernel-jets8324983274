#!/bin/bash
# Jetson Network Connectivity Recovery and Troubleshooting Script
# Run this script on your Jetson device if you have console/UART access
# or from another machine to check connectivity remotely

echo "=========================================="
echo "Jetson Network Recovery Troubleshooting"
echo "=========================================="
echo "Version: 1.0"
echo "Date: $(date)"
echo

# Configuration variables (modify these based on your setup)
JETSON_EXPECTED_IP="192.168.87.196"  # From hosts.yml: nanos2
JETSON_HOSTNAME="nanos2"
METALLB_RANGE="192.168.87.240-192.168.87.250"
PRIMARY_INTERFACE="eno1"
WIRELESS_INTERFACE="wlan0"

# Check if running on Jetson or remote machine
if [[ $(hostname) == *"jetson"* ]] || [[ $(hostname) == "$JETSON_HOSTNAME" ]]; then
    ON_JETSON=true
    echo "✓ Running directly on Jetson device"
else
    ON_JETSON=false
    echo "⚠ Running from remote machine - will test connectivity"
fi

echo

# Function to test connectivity from remote machine
test_remote_connectivity() {
    echo "=== Remote Connectivity Tests ==="
    
    # Test different possible IP addresses
    local test_ips=("$JETSON_EXPECTED_IP" "192.168.87.100" "192.168.87.101" "192.168.87.102")
    local found_ip=""
    
    for ip in "${test_ips[@]}"; do
        echo -n "Testing connectivity to $ip... "
        if ping -c 1 -W 2 "$ip" >/dev/null 2>&1; then
            echo "✓ REACHABLE"
            found_ip="$ip"
            break
        else
            echo "✗ No response"
        fi
    done
    
    if [[ -n "$found_ip" ]]; then
        echo "✓ Found Jetson at IP: $found_ip"
        
        # Test SSH connectivity
        echo -n "Testing SSH connectivity to $found_ip... "
        if timeout 5 ssh -o ConnectTimeout=3 -o BatchMode=yes -o StrictHostKeyChecking=no ansible@"$found_ip" exit 2>/dev/null; then
            echo "✓ SSH accessible"
            echo
            echo "=== SSH ACCESS AVAILABLE ==="
            echo "You can connect with: ssh ansible@$found_ip"
            echo "Run this script directly on the Jetson for detailed diagnostics"
        else
            echo "✗ SSH not accessible"
        fi
    else
        echo "✗ Jetson not found at any expected IP address"
        echo
        echo "=== NETWORK SCAN RECOMMENDED ==="
        echo "Try scanning your network to find the Jetson:"
        echo "nmap -sn 192.168.87.0/24 | grep -B2 -A2 nvidia"
    fi
    
    echo
}

# Function to run diagnostics on Jetson
run_jetson_diagnostics() {
    echo "=== Jetson Network Diagnostics ==="
    
    # Check current kernel
    echo "1. Current Kernel Version:"
    uname -r
    CURRENT_KERNEL=$(uname -r)
    if [[ "$CURRENT_KERNEL" == *"cilium"* ]]; then
        echo "✓ Running Cilium kernel: $CURRENT_KERNEL"
        CILIUM_KERNEL=true
    else
        echo "⚠ Running original kernel: $CURRENT_KERNEL"
        CILIUM_KERNEL=false
    fi
    
    echo
    
    # Check network interfaces
    echo "2. Network Interface Status:"
    echo "Available interfaces:"
    ip link show | grep -E '^[0-9]+:' | awk '{print $2}' | sed 's/://'
    echo
    
    # Check interface details
    echo "Interface details:"
    for interface in $PRIMARY_INTERFACE $WIRELESS_INTERFACE eth0 wlan0; do
        if ip link show "$interface" >/dev/null 2>&1; then
            echo "--- $interface ---"
            ip addr show "$interface"
            echo "Status: $(ip link show "$interface" | grep -o 'state [A-Z]*' | awk '{print $2}')"
            echo
        fi
    done
    
    # Check if interfaces are up
    echo "3. Interface UP/DOWN Status:"
    for interface in $PRIMARY_INTERFACE $WIRELESS_INTERFACE eth0 wlan0; do
        if ip link show "$interface" >/dev/null 2>&1; then
            status=$(ip link show "$interface" | grep -o 'state [A-Z]*' | awk '{print $2}')
            if [[ "$status" == "UP" ]]; then
                echo "✓ $interface: UP"
            else
                echo "✗ $interface: $status"
                echo "  Attempting to bring up $interface..."
                sudo ip link set "$interface" up 2>/dev/null && echo "  ✓ Brought $interface up" || echo "  ✗ Failed to bring $interface up"
            fi
        else
            echo "✗ $interface: Not found"
        fi
    done
    
    echo
    
    # Check driver status
    echo "4. Network Driver Status:"
    echo "Loaded network modules:"
    lsmod | grep -E "e1000|igb|r8169|ath|cfg80211|mac80211" | head -10
    echo
    
    # Check for driver errors in dmesg
    echo "Recent network driver messages:"
    dmesg | grep -i -E "network|ethernet|wifi|wlan|eno1|driver" | tail -10
    echo
    
    # Check DHCP and IP assignment
    echo "5. DHCP and IP Assignment:"
    echo "Current IP addresses:"
    ip addr show | grep "inet " | grep -v "127.0.0.1"
    echo
    
    # Test connectivity
    echo "6. Connectivity Tests:"
    echo -n "Gateway connectivity: "
    gateway=$(ip route | grep default | awk '{print $3}' | head -1)
    if [[ -n "$gateway" ]]; then
        if ping -c 1 -W 2 "$gateway" >/dev/null 2>&1; then
            echo "✓ Gateway ($gateway) reachable"
        else
            echo "✗ Gateway ($gateway) unreachable"
        fi
    else
        echo "✗ No default gateway found"
    fi
    
    echo -n "DNS resolution: "
    if nslookup google.com >/dev/null 2>&1; then
        echo "✓ DNS working"
    else
        echo "✗ DNS not working"
    fi
    
    echo -n "Internet connectivity: "
    if ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1; then
        echo "✓ Internet accessible"
    else
        echo "✗ Internet not accessible"
    fi
    
    echo
    
    # Check system services
    echo "7. Network Service Status:"
    services=("networking" "NetworkManager" "systemd-networkd")
    for service in "${services[@]}"; do
        if systemctl is-enabled "$service" >/dev/null 2>&1; then
            status=$(systemctl is-active "$service")
            echo "$service: $status"
        fi
    done
    
    echo
    
    # If running Cilium kernel, check for DTB issues
    if [[ "$CILIUM_KERNEL" == true ]]; then
        echo "8. Cilium Kernel Specific Checks:"
        echo "eBPF JIT status: $(cat /proc/sys/net/core/bpf_jit_enable 2>/dev/null || echo 'unknown')"
        
        # Check for hardware initialization issues that might indicate DTB problems
        echo "Hardware initialization messages:"
        dmesg | grep -i -E "pcie|nvme|hardware|tegra" | tail -5
        
        echo "Regulatory database status:"
        dmesg | grep -i regulatory | tail -3
        
        echo
    fi
}

# Function to provide recovery recommendations
provide_recovery_recommendations() {
    echo "=== Recovery Recommendations ==="
    
    if [[ "$ON_JETSON" == true ]]; then
        echo "Since you have console access to the Jetson, try these recovery steps:"
        echo
        echo "1. IMMEDIATE NETWORK RECOVERY:"
        echo "   sudo systemctl restart networking"
        echo "   sudo systemctl restart NetworkManager"
        echo "   sudo ip link set $PRIMARY_INTERFACE up"
        echo "   sudo dhclient $PRIMARY_INTERFACE"
        echo
        
        echo "2. CHECK CURRENT KERNEL:"
        current_kernel=$(uname -r)
        if [[ "$current_kernel" == *"cilium"* ]]; then
            echo "   You're running the Cilium kernel: $current_kernel"
            echo "   If network drivers are missing, you may need to:"
            echo "   a) Reboot and select the original kernel from bootloader menu"
            echo "   b) Check if network drivers were built with the custom kernel"
            echo
            echo "   To boot original kernel:"
            echo "   - Reboot the system: sudo reboot"
            echo "   - In bootloader menu, select 'primary kernel (ORIGINAL - fallback)'"
            echo
        else
            echo "   You're running the original kernel: $current_kernel"
            echo "   Network drivers should be working normally"
        fi
        
        echo "3. DRIVER TROUBLESHOOTING:"
        echo "   Check if ethernet driver is loaded:"
        echo "   lsmod | grep -E 'e1000|igb|r8169'"
        echo
        echo "   Try to reload network drivers:"
        echo "   sudo modprobe -r e1000e && sudo modprobe e1000e"
        echo "   sudo modprobe -r igb && sudo modprobe igb"
        echo
        
        echo "4. DTB ISSUES (if on Cilium kernel):"
        echo "   If the Cilium kernel boots but network hardware isn't detected:"
        echo "   This might indicate DTB (Device Tree Blob) compatibility issues"
        echo "   Boot back to original kernel and rebuild DTB with:"
        echo "   cd /usr/src && sudo make dtbs"
        echo
        
    else
        echo "Since you don't have console access, try these remote recovery methods:"
        echo
        echo "1. POWER CYCLE:"
        echo "   If possible, power cycle the Jetson device"
        echo "   This might reset network interfaces and DHCP"
        echo
        echo "2. CHECK ROUTER/SWITCH:"
        echo "   Check your router's DHCP client list for the Jetson"
        echo "   Look for devices with 'nvidia' or 'jetson' in the name"
        echo
        echo "3. SERIAL/UART ACCESS:"
        echo "   If available, connect via serial console:"
        echo "   - USB-C to UART adapter on the Jetson dev kit"
        echo "   - 115200 baud rate"
        echo "   - This gives you direct console access"
        echo
        echo "4. BOOTLOADER RECOVERY:"
        echo "   If the Jetson is stuck on Cilium kernel with driver issues:"
        echo "   - Power cycle and watch for bootloader menu"
        echo "   - Select 'primary kernel (ORIGINAL - fallback)'"
        echo
    fi
    
    echo "5. NETWORK SCAN:"
    echo "   Scan your network to find the Jetson:"
    echo "   nmap -sn 192.168.87.0/24"
    echo "   Look for NVIDIA or unknown MAC addresses"
    echo
}

# Function to check bootloader configuration
check_bootloader_config() {
    if [[ "$ON_JETSON" == true ]] && [[ -f "/boot/extlinux/extlinux.conf" ]]; then
        echo "=== Bootloader Configuration ==="
        echo "Current bootloader config:"
        cat /boot/extlinux/extlinux.conf
        echo
        
        # Check if both kernels are available
        echo "Available kernel files:"
        ls -la /boot/Image* 2>/dev/null || echo "No additional kernel images found"
        echo
    fi
}

# Main execution
if [[ "$ON_JETSON" == false ]]; then
    test_remote_connectivity
else
    run_jetson_diagnostics
    check_bootloader_config
fi

provide_recovery_recommendations

echo "=========================================="
echo "Troubleshooting script completed"
echo "=========================================="