#!/bin/bash
# Quick Jetson Network Discovery Script
# Run this from your local machine to find and test connectivity to your Jetson

echo "=== Jetson Network Discovery ==="
echo "Date: $(date)"
echo

# Known Jetson IP from your configuration
KNOWN_IP="192.168.87.196"  # nanos2 from hosts.yml
NETWORK_BASE="192.168.87"

echo "1. Testing known Jetson IP: $KNOWN_IP"
if ping -c 2 -W 2 "$KNOWN_IP" >/dev/null 2>&1; then
    echo "✓ Jetson found at $KNOWN_IP"
    
    # Test SSH
    echo -n "   SSH test: "
    if timeout 5 ssh -o ConnectTimeout=3 -o BatchMode=yes -o StrictHostKeyChecking=no ansible@"$KNOWN_IP" exit 2>/dev/null; then
        echo "✓ SSH accessible"
        echo "   Connect with: ssh ansible@$KNOWN_IP"
    else
        echo "✗ SSH not accessible (may need password/key)"
        echo "   Try: ssh ansible@$KNOWN_IP"
    fi
else
    echo "✗ No response from $KNOWN_IP"
    echo
    
    echo "2. Scanning network for Jetson device..."
    
    # Quick scan of likely IP range
    echo "   Scanning $NETWORK_BASE.100-200..."
    found_ips=()
    
    for i in {100..200}; do
        ip="$NETWORK_BASE.$i"
        if ping -c 1 -W 1 "$ip" >/dev/null 2>&1; then
            found_ips+=("$ip")
            echo "   ✓ Found device at $ip"
        fi
    done
    
    if [[ ${#found_ips[@]} -eq 0 ]]; then
        echo "   No devices found in $NETWORK_BASE.100-200"
        echo
        echo "3. Full network scan (this may take a moment)..."
        echo "   Scanning entire $NETWORK_BASE.0/24 subnet..."
        
        # Use nmap if available, otherwise manual ping
        if command -v nmap >/dev/null 2>&1; then
            echo "   Using nmap for faster scanning..."
            nmap_results=$(nmap -sn "$NETWORK_BASE.0/24" 2>/dev/null | grep -B1 "Nmap scan report")
            if [[ -n "$nmap_results" ]]; then
                echo "$nmap_results"
            else
                echo "   No devices found via nmap"
            fi
        else
            echo "   Using ping sweep (install nmap for faster scanning)..."
            for i in {1..254}; do
                ip="$NETWORK_BASE.$i"
                if ping -c 1 -W 1 "$ip" >/dev/null 2>&1; then
                    echo "   ✓ Device found at $ip"
                fi
            done
        fi
    else
        echo
        echo "   Found ${#found_ips[@]} device(s) in scan range"
        echo "   Testing each for SSH access..."
        
        for ip in "${found_ips[@]}"; do
            echo -n "   Testing SSH to $ip: "
            if timeout 3 ssh -o ConnectTimeout=2 -o BatchMode=yes -o StrictHostKeyChecking=no ansible@"$ip" exit 2>/dev/null; then
                echo "✓ SSH accessible (likely the Jetson)"
                echo "     Connect with: ssh ansible@$ip"
            else
                echo "✗ No SSH or different credentials"
            fi
        done
    fi
fi

echo
echo "=== Router/DHCP Check Recommendation ==="
echo "Also check your router's admin interface for:"
echo "- DHCP client list"
echo "- Devices with 'nvidia', 'jetson', or similar names"
echo "- Recently connected devices"
echo

echo "=== If Jetson Found ==="
echo "If you found the Jetson, copy and run the network troubleshooting script:"
echo "scp network-recovery-troubleshoot.sh ansible@<JETSON_IP>:~/"
echo "ssh ansible@<JETSON_IP>"
echo "chmod +x network-recovery-troubleshoot.sh"
echo "./network-recovery-troubleshoot.sh"
echo

echo "=== If No Network Access ==="
echo "If the Jetson has no network connectivity:"
echo "1. Connect monitor and keyboard directly to Jetson"
echo "2. Or use USB-C to UART for serial console access"
echo "3. Run the network-recovery-troubleshoot.sh script locally"
echo "4. Check if it booted to Cilium kernel vs original kernel"
echo

echo "Discovery completed."