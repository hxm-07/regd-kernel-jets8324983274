## Latest Update

### Kernel Status after User's Recompilation:

*   **Flags now correctly set (built-in `y` or module `m` as desired):**
    *   `CONFIG_NAMESPACES=y`
    *   `CONFIG_NET_NS=y`
    *   `CONFIG_PID_NS=y`
    *   `CONFIG_IPC_NS=y`
    *   `CONFIG_UTS_NS=y`
    *   `CONFIG_USER_NS=y`
    *   `CONFIG_CGROUPS=y`
    *   `CONFIG_CGROUP_DEVICE=y`
    *   `CONFIG_CGROUP_CPUACCT=y`
    *   `CONFIG_CGROUP_FREEZER=y`
    *   `CONFIG_CGROUP_SCHED=y`
    *   `CONFIG_CGROUP_PIDS=y`
    *   `CONFIG_MEMCG=y`
    *   `CONFIG_VETH=y`
    *   `CONFIG_BRIDGE=y`
    *   `CONFIG_TUN=y`
    *   `CONFIG_MACVLAN=y`
    *   `CONFIG_OVERLAY_FS=y`
    *   `CONFIG_NETFILTER=y`
    *   `CONFIG_NETFILTER_ADVANCED=y`
    *   `CONFIG_NF_CONNTRACK=y`
    *   `CONFIG_BRIDGE_NETFILTER=y`
    *   `CONFIG_IP_NF_IPTABLES=y`
    *   `CONFIG_IP_NF_FILTER=y`
    *   `CONFIG_IP_NF_NAT=y`
    *   `CONFIG_IP_NF_TARGET_MASQUERADE=y`
    *   `CONFIG_IP_NF_TARGET_REDIRECT=y`
    *   `CONFIG_IP_NF_MANGLE=y`
    *   `CONFIG_IP6_NF_IPTABLES=y`
    *   `CONFIG_IP6_NF_FILTER=y`
    *   `CONFIG_IP6_NF_NAT=y`
    *   `CONFIG_IP6_NF_TARGET_MASQUERADE=y`
    *   `CONFIG_NETFILTER_XT_MATCH_CONNTRACK=y`
    *   `CONFIG_NETFILTER_XT_MATCH_ADDRTYPE=m`
    *   `CONFIG_NETFILTER_XT_MATCH_MARK=y`
    *   `CONFIG_NETFILTER_XT_MATCH_SOCKET=m`
    *   `CONFIG_NETFILTER_XT_MATCH_COMMENT=y`
    *   `CONFIG_NETFILTER_XT_MATCH_RECENT=m`
    *   `CONFIG_NETFILTER_XT_MATCH_STATISTIC=m`
    *   `CONFIG_NETFILTER_XT_TARGET_MARK=y`
    *   `CONFIG_NETFILTER_XT_TARGET_TPROXY=y`
    *   `CONFIG_NET_SCHED=y`
    *   `CONFIG_NET_CLS=y`
    *   `CONFIG_NET_CLS_ACT=y`
    *   `CONFIG_NET_SCH_INGRESS=m`
    *   `CONFIG_NET_SCH_CLSACT=m`
    *   `CONFIG_VXLAN=m`
    *   `CONFIG_GENEVE=m`
    *   `CONFIG_MPLS=y`
    *   `CONFIG_IP_VS=y`
    *   `CONFIG_IP_VS_PROTO_TCP=y`
    *   `CONFIG_IP_VS_PROTO_UDP=y`
    *   `CONFIG_IP_VS_RR=y`
    *   `CONFIG_IP_VS_WRR=y`
    *   `CONFIG_IP_VS_SH=y`
    *   `CONFIG_XFRM=y`
    *   `CONFIG_XFRM_USER=y`
    *   `CONFIG_INET_ESP=m`
    *   `CONFIG_INET_AH=m`
    *   `CONFIG_INET6_ESP=m`
    *   `CONFIG_INET6_AH=m`
    *   `CONFIG_CRYPTO_AEAD=y`
    *   `CONFIG_CRYPTO_GCM=y`
    *   `CONFIG_CRYPTO_CBC=y`
    *   `CONFIG_CRYPTO_HMAC=y`
    *   `CONFIG_CRYPTO_SHA256=y`
    *   `CONFIG_CRYPTO_AES=y`
    *   `CONFIG_SQUASHFS=y`
    *   `CONFIG_EXT4_FS_POSIX_ACL=y`
    *   `CONFIG_EXT4_FS_SECURITY=y`
    *   `CONFIG_PERF_EVENTS=y`
    *   `CONFIG_SCHEDSTATS=y`
    *   `CONFIG_KEYS=y`
    *   `CONFIG_SECCOMP=y`

    *   `CONFIG_XFRM_OFFLOAD` (Desired: `y`)
    *   `CONFIG_INET_XFRM_MODE_TUNNEL` (Desired: `y`)
    *   `CONFIG_GRE` (Desired: `m`)
    *   `CONFIG_IP_VS_NFCT` (Desired: `y`)
    *   `CONFIG_CRYPTO_SEQIV` (Desired: `m`)

### Actions Taken (Ansible Playbook Modifications)

1.  **`group_vars/all.yml`:**
    -   Changed `jetson_lan_ip` to dynamically select the Tailscale IP (`100.x.x.x` range) instead of relying on `192.168.x.x` range.
2.  **`roles/preflight-audit/tasks/main.yml`:**
    -   Added tasks to aggressively uninstall previous k3s installations, kill k3s processes, and remove k3s data/service files to ensure a clean slate before installation attempts.
3.  **`roles/k3s-install/tasks/main.yml`:**
    -   Moved the `lineinfile` task (which adds the `ExecStartPre` command to `k3s.service` to wait for default route) to execute *after* the `Install K3s` task. This ensures the modification is applied after the `k3s.service` file is created by the `k3s-install.sh` script.
    -   Ensured `notify: restart k3s` is correctly placed on the `Install K3s` task.
4.  **`roles/cilium-install/tasks/main.yml`:**
    -   Removed the `lineinfile` task and `meta: flush_handlers` task, as their functionality was moved to the `k3s-install` role.

### iptables Investigation and Fix

During the investigation of the k3s installation hanging, it was discovered that the `k3s` service was failing to start correctly. The logs revealed that `iptables-restore` was failing with an `unknown option "--nflog-group"` error. This was caused by `k3s` and `Cilium` requiring the `nftables` backend for `iptables`, while the system was using the `legacy` backend.

The following actions were taken to resolve this issue:

1.  **`roles/preflight-audit/tasks/main.yml`:**
    -   Added a task to check the current `iptables` alternative.
    -   Added a task to set the `iptables` alternative to `/usr/sbin/iptables-nft` if the CNI provider is Cilium (`cni_provider == '2'`). This ensures that the correct `iptables` backend is used for Cilium, while leaving the default for other CNIs like Flannel.

### Troubleshooting Methodology

When the Ansible playbook hangs or fails, the following methodology is used to troubleshoot the issue:

1.  **Analyze Playbook Logs:** The output of the `ansible-playbook` command is captured to a log file. This log is analyzed to identify the task where the execution is hanging or failing.
2.  **Live Node Investigation:** Once the failing task is identified, the investigation moves to the target node. The following checks are performed on the node using `ansible` ad-hoc commands or SSH:
    *   **Service Logs:** Check the logs of the relevant services (e.g., `k3s.service`, `containerd.service`) using `journalctl`.
    *   **Process Status:** Check for running processes related to the failing service using `ps`.
    *   **Configuration Files:** Examine the configuration files of the service to ensure they are correctly generated and applied.
    *   **System State:** Check the state of the system, such as network routes (`/proc/net/route`), `iptables` rules, and alternatives (`update-alternatives`).
3.  **Correlate and Fix:** The findings from the playbook logs and the live node investigation are correlated to identify the root cause of the issue. A fix is then implemented in the Ansible playbook to address the issue.

### Current Status

The Ansible playbook is designed to install K3s and configure a CNI (Cilium or Flannel) on a Jetson node. During recent attempts to install Cilium, the playbook encountered persistent failures related to `iptables` configuration.

**Key Issues Identified:**

*   **`iptables` Backend Conflict and `CHAIN_ADD` Errors:**
    *   **Problem:** K3s and Cilium, being modern Kubernetes components, primarily rely on the `nftables` backend for `iptables` for efficient network rule management. However, the Jetson system was configured to use the older `iptables-legacy` backend by default. This mismatch led to critical errors during K3s installation, specifically `iptables-restore v1.8.7 (nf_tables): line 49: CHAIN_ADD failed (No such file or directory): chain PREROUTING`. This error indicated that `iptables-restore` (which was using the `nftables` variant after our initial fix) was attempting to add rules to or modify chains like `PREROUTING`, `INPUT`, `OUTPUT`, and `POSTROUTING` within the `nat` table, but these chains were either not properly initialized or were in a conflicting state due to the `legacy` backend's presence.
    *   **Troubleshooting:** We confirmed the `iptables` version (`v1.8.7 (legacy)`) and the presence of both `iptables-legacy` and `iptables-nft` binaries via `update-alternatives --display iptables`. The system was symlinked to `iptables-legacy`. This confirmed the backend conflict.
    *   **Initial Attempted Fix:** Our first attempt was to explicitly set `iptables` to use the `nftables` backend using `sudo update-alternatives --set iptables /usr/sbin/iptables-nft`. While this changed the default, the `CHAIN_ADD` errors persisted, suggesting deeper `iptables` state issues.

*   **Persistent `iptables` State and Kernel Module Issues:**
    *   **Problem:** Even after switching to `iptables-nft` and attempting to uninstall previous K3s installations, residual `iptables` rules and potentially unloaded kernel modules were causing conflicts. The `iptables-restore` error `CHAIN_ADD failed (No such file or directory)` suggested that the `nat` table, or its fundamental chains, were not correctly initialized or were being interfered with.
    *   **Troubleshooting:** We observed that the `nat` table, when inspected with `sudo iptables -t nat -L -v -n --line-numbers`, appeared empty or contained unexpected `legacy` warnings, even after switching to `nftables`. This indicated that the `nftables` kernel subsystem's view of the `nat` table was not clean or complete. The `nf_nat` kernel module is essential for NAT functionality with `nftables`.
    *   **Subsequent Attempted Fixes:**
        *   **Loading `nf_nat` module:** We hypothesized that the `nf_nat` kernel module might not be loading automatically or early enough. We added a task to explicitly load `nf_nat` using `ansible.builtin.modprobe`. This was intended to ensure the necessary kernel support for `nftables` NAT operations was present.
        *   **Aggressive `iptables` Flushing:** Recognizing that `k3s-uninstall.sh` might not fully clean up `iptables` state, we introduced a task to aggressively flush *all* `iptables` rules across all tables (`filter`, `nat`, `mangle`, `raw`) for *both* `iptables-legacy` and `iptables-nft` variants. This was placed early in the `preflight-audit` role to ensure a completely clean `iptables` state before K3s attempts its own setup. This task was made conditional on `cni_provider == '2'` (Cilium) to avoid interfering with Flannel installations.
        *   **Pre-K3s `nat` table Flush:** As a final measure, we added another specific flush of the `nat` table (`iptables-nft -t nat -F`) immediately before the `Install K3s` task in the `k3s-install` role. This is a precautionary measure to prevent any transient `nat` table issues during K3s installation, also conditional on Cilium selection.

Despite these modifications, the playbook continues to fail at the `Install K3s` task with the `iptables-restore` error, indicating that the root cause is still not fully resolved or there are deeper interactions at play.

### Plan to Assess and Implement

**Goal:** Deploy a K3s cluster with Cilium CNI and an external `etcd` datastore for High Availability, specifically when `cni_provider == '2'`.

**Key Technologies:** K3s, etcd, Cilium, Ansible.

**Main Features:**
*   Multi-node K3s cluster.
*   External `etcd` cluster for K3s datastore HA.
*   Cilium as the CNI.

**Interaction:** The user will run the Ansible playbook, which will provision the `etcd` cluster and then the `k3s` cluster configured to use `etcd`.

**High-Level Steps:**

1.  **Inventory Expansion (User Action Required):** The user needs to update `inventory/hosts.yml` to include at least three `jetson_nodes` for a robust `etcd` and K3s HA setup. Each node should have a unique `ansible_host` and `ansible_user`.
2.  **`etcd` Role Development:**
    *   Create a new Ansible role `etcd-install`.
    *   Tasks to download `etcd` binaries.
    *   Tasks to generate TLS certificates for `etcd` (CA, server, client certificates).
    *   Tasks to configure `etcd` systemd services on each node, including peer discovery and client advertisements.
    *   Tasks to start and enable `etcd` services.
    *   Tasks to verify `etcd` cluster health.
3.  **`k3s-install` Role Modification:**
    *   Modify the `k3s-install` role to configure `k3s` to use the external `etcd` datastore.
    *   Update `k3s-config.yaml.j2` to include `datastore-endpoint`, `datastore-cafile`, `datastore-certfile`, and `datastore-keyfile` arguments.
    *   Ensure `etcd` client certificates are distributed to `k3s` nodes.
    *   Adjust `k3s` server arguments for HA (e.g., `cluster-init` on the first server, `server` on others).
4.  **Playbook Orchestration (`playbooks/main.yml`):**
    *   Add the `etcd-install` role to the `playbooks/main.yml` file, ensuring it runs before `k3s-install`.
    *   Add conditional logic (`when: cni_provider == '2'`) to execute the `etcd-install` role and the modified `k3s-install` tasks only when Cilium is selected.
5.  **Cilium Compatibility:** Verify that the `cilium-install` role does not conflict with the `etcd` setup and is correctly configured for the HA `k3s` cluster.

### Next Steps


The playbook has been updated to handle the `iptables` backend selection automatically. The next step is to re-run the playbook and verify that the k3s cluster comes up correctly with Cilium.
