
# JETSON R36.4.4 — POST-SALVAGE RUNBOOK & ROE

## 0) Quick analogy (to frame what happened)

Think of the Jetson as an orchestra with two conductors: **the firmware** (QSPI UEFI/BPMP) and **the kernel + DTBs** on disk. When those conductors carry **different scores** (versions), the brass (GPU) comes in on bar 12 while the strings (memory carveouts) are on bar 10—noise. Our fix was to **give both conductors the same score** (QSPI flash to R36.4.4), then make sure the players have the right chairs and music stands (extlinux, user groups, device permissions). The rest—conftest timing, OOT modules, olddefconfig landmines—is how we stopped chairs from being quietly removed mid-performance.&#x20;

---

## 1) Where we began (from the end of your last “Salvage” doc)

**What we learned in the salvage:**

* `silentoldconfig` (invoked by `modules_prepare`) **silently deletes unknown Kconfig symbols** (e.g. `CONFIG_TEGRA_NVGPU`, `CONFIG_RTW88`) if their Kconfig isn’t present yet. That was the root of the “it built, then reboot nuked it” effect. We fixed this by **applying Kconfig before config**, monitoring `.config` size, and restoring immediately when corruption occurred.
* **Conftest timing**: NVIDIA OOT modules need conftest headers **after** the kernel build but **before** any reboot destroys the build env. We moved OOT builds **before** the reboot.&#x20;
* Built a corrected pipeline: patches → config (with snapshots/guard) → build → conftest → OOT → install → reboot → validate.&#x20;

**What changed since that doc (this mission):**

* We stopped fighting symptoms (extlinux DTB paths) and proved **firmware was feeding its own DTB**. The fix was **QSPI alignment to R36.4.4**.
* After QSPI alignment and a safe/test boot setup, **GPU works** and `nvidia-smi` is clean. The remaining blocker was just **user permissions** (video/render groups), not DTB anymore.

---

## 2) enable\_oot / apply\_regdom\_fixes — behavior & when we used them

### `enable_oot`

* **false**: Use only the **stock L4T kernel + in-tree bits**. No NVIDIA OOT (nvidia-oot/hwpm/nvethernetrm). Build is simpler; avoids conftest timing; good for baseline bring-up and “is the board sane?” checks.
* **true**: Pull, branch-fix, conftest, and **build the full NVIDIA OOT module set**. This path **requires** correct branch selection (`origin/l4t/l4t-r36.4.4`), working repo symlinks, and conftest timing (build OOT **before** reboot). This was the path we stabilized in the salvage work, including the branch fix and conftest steps.

**Why this mattered:**

* When `enable_oot=true`, any mis-timing or wrong branches leads to **API mismatches** (conftest stale/not generated), or missing files (e.g., `nvethernetrm/include/config.tmk`) due to **symlink/branch** issues. We documented this failure and the branch fix loop.

### `apply_regdom_fixes=true`

* We introduced this to **patch regdomain behavior** (Realtek regdom adjustments), applied as **source changes** before the build (e.g., `regd.c` and helper script). It’s a clean toggle to include those HW/Wi-Fi region fixes without touching the build logic.&#x20;

---

## 3) The road from the last build to “it works now”

### 3.1 Safe baseline & proof flags

* Created **safe/test** labels in `extlinux.conf`, with **proof=… tags** to confirm which label actually booted. Safe label blacklists GPU for parachute boots. Test label enables GPU. (This avoids another “No root device” surprise.)
* We used **absolute root** (`/dev/nvme0n1p1`) first, then switched to **PARTUUID** once confirmed. (Safer bring-up, then robust persistent ID.)

### 3.2 We proved a real firmware/DTB mismatch

* Repeatedly compared **live DTB hash** (`/sys/firmware/fdt`) vs. our DTB file and looked for **EFI stub DTB messages**. No match; EFI wasn’t loading our file DTB; the live hash **changed between boots**—classic “firmware choosing DTB” symptom. Root cause: **QSPI firmware not aligned to R36.4.4**. (This aligns with our earlier “dependency hell” lessons: fix the root, not the symptoms.)&#x20;

### 3.3 QSPI-only flash (host) → alignment with R36.4.4

* Host ran `l4t_initrd_flash.sh` with the correct **p3768-0000+p3767-0005-qspi.conf** to flash **QSPI only**, leaving NVMe rootfs intact.
* Post-flash verification on first boot:

  1. `sha256sum /sys/firmware/fdt` vs stock DTB file in `/boot/dtb/...`
  2. `dmesg | grep -i 'EFI stub.*DTB'` to confirm **Loaded DTB from file** (or at least that firmware now cooperates).
* From that point, **GPU init worked**; `nvidia-smi` OK as root. Remaining “failure” as normal user = **group membership**. We added **video,render** to the user and `nvidia-smi` worked unprivileged.

### 3.4 Conftest/OOT status (what still applies from the Salvage)

* If/when we flip `enable_oot=true` again:

  * **Do the branch fix loop** for all NVIDIA repos (`nvidia-oot`, `nvethernetrm`, `hwpm`, `nvgpu`, `kernel-devicetree`).
  * **Run conftest** right after the kernel build, **before any reboot**, then build OOT modules. (This exact timing is the hard-won lesson.)
  * Keep the **config snapshot/guard** to catch any silent `.config` mutations.&#x20;

---

## 4) Are we ready to deploy the ML app with **k3s + Cilium**?

**Short answer:** Yes—with a few standard preflights.

**Why I’m confident now:**

* GPU stack is **healthy** (`nvidia-smi` OK, user in **video/render**).
* Kernel is **5.15.xx** (meets Cilium’s modern eBPF needs).
* JetPack 6.2.1 (R36.4.4) userspace is consistent with firmware after QSPI.
* We already proved that the **NVIDIA userspace + kernel drivers** are coherent (no NVGPU panics).

**Preflight checks I recommend before installing k3s:**

1. **eBPF sanity**: `mount | grep bpf` (should be mounted), `bpftool prog` (installed), and ensure cgroup v2 is enabled (k3s can work with cgroup v1/v2; just be consistent).
2. **container runtime**: make sure `nvidia-container-toolkit` is present and **containerd** knows about the **NVIDIA runtime** so pods can see the GPU.
3. **CNI choice**: You asked for **Cilium**—great. Verify the kernel has the usual BPF bits (5.15 has them).
4. **k3s+GPU**: Add the standard device plugin (or helm values) so workloads can request `nvidia.com/gpu`.
5. **Smoke test**: run a tiny CUDA container (`deviceQuery`) as a pod; confirm `/dev/nvhost*` + `/dev/dri/renderD*` access inside.

Given our current state, there’s no blocker to installing **k3s** and **Cilium** and deploying the ML app. The main thing is to wire up the **NVIDIA runtime** in containerd and deploy the **device plugin**. (If you want, I can drop a minimal k3s + Cilium + GPU device-plugin snippet next.)

---

## 5) What we should **automate in Ansible** next (things we did manually)

### 5.1 Firmware & DTB sanity (new role)

* **QSPI alignment precheck** (host-side): small helper that verifies `lsusb | grep 0955`, `tegrarcm --uid` reachable, and calls `l4t_initrd_flash.sh` with the right **qspi.conf** when requested. (Guardrail: **QSPI-only** unless explicitly told to flash rootfs.)
* **Post-boot verifiers** on target:

  * Compare **`/sys/firmware/fdt` hash** to file DTB hash (**report**, don’t fail hard).
  * Parse `dmesg` for **“EFI stub … DTB”** vs “Using DTB from configuration table”.
  * Record results into `/var/log/jetson/firmware_dtb_report.json`.

### 5.2 extlinux generator (idempotent)

* Generate **safe/test** entries with **proof=** flags.
* Support both `root=/dev/nvme0n1p1` **and** `root=PARTUUID=…` with auto-detect and a toggle to promote to PARTUUID after first successful boot.
* Optional: **DTB strategy variable**: `dtb_strategy=firmware|file`, and if `file`, place DTB both in `/boot/dtb/` and `/boot/efi/dtb/` (hash-checked).

### 5.3 User/device permissions

* Ensure **video,render** group membership for the target user; re-logins not required by using `newgrp` during the play run.
* Check `/dev/dri/renderD*` and `/dev/nvhost-*` **ownership & ACLs**; fix with udev rules if needed.

### 5.4 OOT pipeline hardening (existing work, codify it)

* **Branch-fix loop** for all NVIDIA repos (error if any repo not on `origin/l4t/l4t-r36.4.4`).&#x20;
* **Conftest target** runs **immediately after** kernel build and **before** any reboot; assert conftest headers exist.&#x20;
* Keep the **config guard**: snapshot `.config` size/content and restore if it changes after `modules_prepare` or during long builds.
* If `apply_regdom_fixes=true`, apply the **regdom patch set** (your `regd.c` & helper) in the patches role—not ad-hoc.&#x20;

### 5.5 Logs & proof artifacts

* Persist: `uname -a`, `/etc/nv_tegra_release`, `nvidia-smi -q`, conftest headers presence, and **DTB hash comparisons** under `/var/log/jetson/` with timestamps for audits.

---

## 6) The “why” (tying back to the docs)

* **Silent killer**: `silentoldconfig` deleting unknown symbols explained why drivers disappeared between build and reboot—and why **patch timing** had to be moved earlier.&#x20;
* **Conftest timing**: Ensuring OOT modules build in the same environment as the kernel (no reboot in between) is what made the OOT path reliable.&#x20;
* **Git branch fix**: Repos must be on the **R36.4.4** branches; we captured the exact commands and rationale (stop “missing file/symlink” fails like `nvethernetrm`).&#x20;
* **Corrected sequence**: The final working order we now live by (patches → config w/ guard → build → conftest → OOT → install → reboot → validate).&#x20;

---

## 7) “Ready now” checklist (final)

* **Firmware aligned** (QSPI → R36.4.4): ✅
* **Boot proven** (proof flags, safe/test): ✅
* **GPU healthy** (`nvidia-smi` as user, video/render groups): ✅
* **Stock kernel OK**; OOT path available when needed: ✅
* **k3s + Cilium feasibility**: ✅ (after containerd + NVIDIA runtime preflight)

---

## 8) What we’ll defer (but we’re prepared for)

* **Full OOT re-enable** (`enable_oot=true`) with the hardened sequence above.
* **nvethernetrm symlink/branch sanity** before enabling that set.&#x20;
* Optional: add a **host-side role** that packages the QSPI flash step into a one-button flow (with guardrails).

---

If you want, I can turn this into a repo-ready `POST-SALVAGE-ROE.md` plus an Ansible role skeleton (`roles/jetson_boot_safety/`) with the exact tasks (safe/test extlinux, DTB verifiers, group grants, log proofs).

