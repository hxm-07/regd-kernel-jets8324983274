Awesome—here’s a clean, repeatable framework to **back up your current kernel + modules + DTBs** from the working Jetson and **install them on another Jetson**. It’s opinionated in the same “safe/test” style you used, with belt-and-suspenders checks so you don’t get surprised by root device or DTB loading.

---

# 0) Ground rules (don’t skip)

* **Both machines must be the same JetPack/BSP**: you’re on **JetPack 6.2.1 / R36.4.4**. The *target Jetson MUST have QSPI flashed to the same release* (you just proved that’s the root of the flaky DTB behavior).
* We will **carry over three things** from source → target:

  1. the kernel **Image** (and optional `/boot/5.15.148-tegra` if that’s how you ship it),
  2. the **entire** `/lib/modules/$(uname -r)` tree (including `updates/`),
  3. the **board DTB** you want to use (we’ll keep your `kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb`).
* We’ll also copy these tiny but important files if present:

  * `/etc/modprobe.d/nvgpu-softdeps.conf`
  * any **NVIDIA provider** modules that live outside modules tree (rare; your tree already unified to `/updates`).
* We’ll **install with a safe boot entry by default** (GPU blacklisted), plus a “test” entry (GPU enabled). You flip the DEFAULT when ready.

---

# 1) On the **source** Jetson (the good one): make a golden tarball

> Run as a sudo-capable user. Adjust the DTB file name if yours differs.

```bash
# Vars
KREL="$(uname -r)"                                # e.g., 5.15.148-tegra
STAMP="$(date +%Y%m%d-%H%M%S)"
OUTDIR="/tmp/kernel-backup-${KREL}-${STAMP}"
mkdir -p "${OUTDIR}"/{boot,modules,dtb,modprobe,meta}

# 1) Collect boot assets
# If your kernel lives as /boot/Image and/or /boot/5.15.148-tegra, grab both:
cp -av /boot/Image "${OUTDIR}/boot/"             2>/dev/null || true
cp -av /boot/5.15.148-tegra "${OUTDIR}/boot/"    2>/dev/null || true
# Grab initrd if present (L4T often uses /boot/initrd)
cp -av /boot/initrd* "${OUTDIR}/boot/"           2>/dev/null || true
cp -av /boot/initrd.img-* "${OUTDIR}/boot/"      2>/dev/null || true

# 2) DTB (board-specific)
cp -av /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb "${OUTDIR}/dtb/"

# 3) Modules (entire tree for this kernel)
cp -a /lib/modules/"${KREL}" "${OUTDIR}/modules/"

# 4) Softdeps or extra knobs (if exists)
cp -av /etc/modprobe.d/nvgpu-softdeps.conf "${OUTDIR}/modprobe/" 2>/dev/null || true

# 5) Provenance/manifest (great for audits)
{
  echo "KERNEL_RELEASE=${KREL}"
  echo "HOSTNAME=$(hostname)"
  echo "DATE=${STAMP}"
  echo "JETPACK_NVTEGRA=$(cat /etc/nv_tegra_release || echo 'n/a')"
  echo "UNAME=$(uname -a)"
  echo "LIVE_DTB_SHA=$(sudo sha256sum /sys/firmware/fdt | awk '{print $1}')"
  echo "FILE_DTB_SHA=$(sha256sum ${OUTDIR}/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb | awk '{print $1}')"
  echo "IMAGE_SHA=$(sha256sum ${OUTDIR}/boot/Image 2>/dev/null | awk '{print $1}')"
} > "${OUTDIR}/meta/manifest.txt"

# 6) Pack it
tar -C "${OUTDIR}/.." -czf "/tmp/jetson-kernel-${KREL}-${STAMP}.tgz" "$(basename "${OUTDIR}")"
echo "Created: /tmp/jetson-kernel-${KREL}-${STAMP}.tgz"
```

**What you now have**: a single archive with your **Image**, **modules**, **DTB**, and a **manifest**.

---

# 2) On the **target** Jetson: preflight

1. **Align QSPI first** (you already have the correct command). Confirm after boot:

   * `cat /etc/nv_tegra_release` shows **R36.4.4**.
2. Stay on the stock **/boot/Image** for the first boot.
3. Make sure you can SSH in and `sudo` works.

---

# 3) Transfer & unpack on the **target**

Copy the tarball to the target (scp, USB, whatever), then:

```bash
# Vars
PKG="/tmp/jetson-kernel-<fill-your-file>.tgz"
WORK="/tmp/restore-kernel"
sudo rm -rf "$WORK" && mkdir -p "$WORK"
tar -C "$WORK" -xzf "$PKG"
TREE="$(find "$WORK" -maxdepth 1 -type d -name 'kernel-backup-*' | head -1)"
echo "Unpacked tree: $TREE"
```

---

# 4) Install files (non-destructive)

> We install **alongside** existing assets and wire up **safe/test** entries. We **do not** delete stock kernel.

```bash
set -euo pipefail
KREL="$(grep ^KERNEL_RELEASE= "$TREE/meta/manifest.txt" | cut -d= -f2)"
echo "Installing kernel release: $KREL"

# 4.1 Modules
sudo rsync -aH --info=stats1 "$TREE/modules/${KREL}/" "/lib/modules/${KREL}/"
# Rebuild module deps for that kernel
sudo depmod -a "${KREL}"

# 4.2 Boot bits
# Put your Image somewhere explicit to avoid clobbering stock:
if [ -f "$TREE/boot/5.15.148-tegra" ]; then
  sudo cp -av "$TREE/boot/5.15.148-tegra" "/boot/5.15.148-tegra"
fi
if [ -f "$TREE/boot/Image" ]; then
  sudo cp -av "$TREE/boot/Image" "/boot/Image-${KREL}-custom"
fi

# 4.3 Initrd: generate a new one bound to this module tree (safe, repeatable)
sudo update-initramfs -c -k "${KREL}" || sudo update-initramfs -u -k "${KREL}"
# Normal Ubuntu naming -> /boot/initrd.img-${KREL}
# Also provide a simple name that matches your style:
if [ -f "/boot/initrd.img-${KREL}" ]; then
  sudo cp -av "/boot/initrd.img-${KREL}" "/boot/initrd-${KREL}"
fi

# 4.4 DTB (board file)
sudo mkdir -p /boot/dtb
sudo cp -av "$TREE/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb" "/boot/dtb/"

# 4.5 Softdeps (optional but matches your working setup)
[ -f "$TREE/modprobe/nvgpu-softdeps.conf" ] && \
  sudo cp -av "$TREE/modprobe/nvgpu-softdeps.conf" "/etc/modprobe.d/"
```

---

# 5) extlinux: add **safe** and **test** entries (and keep stock as parachute)

We’ll **not** touch your stock entry. We’ll add two labels that point to **your** kernel+initrd+dtb and default to **safe**.

```bash
# 5.1 Identify target root PARTUUID for reliability
ROOT_PART="/dev/nvme0n1p1"                      # change if different
RUUID="$(sudo blkid -s PARTUUID -o value ${ROOT_PART})"
echo "Target root PARTUUID=${RUUID}"

# 5.2 Backup then write safe/test labels
sudo cp -av /boot/extlinux/extlinux.conf /boot/extlinux/extlinux.conf.backup.$(date +%Y%m%d-%H%M%S)

SAFE_LABEL=$(cat <<EOF
LABEL safe
  MENU LABEL Safe (GPU blacklisted)
  LINUX  /boot/5.15.148-tegra
  INITRD /boot/initrd-${KREL}
  FDT    /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
  APPEND \${cbootargs} root=PARTUUID=${RUUID} rw rootwait modprobe.blacklist=nvgpu nomodeset proof=safe-extlinux
EOF
)

TEST_LABEL=$(cat <<EOF
LABEL test
  MENU LABEL Test (GPU enabled, after QSPI alignment)
  LINUX  /boot/5.15.148-tegra
  INITRD /boot/initrd-${KREL}
  FDT    /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
  APPEND \${cbootargs} root=PARTUUID=${RUUID} rw rootwait loglevel=7 earlycon ignore_loglevel proof=test-extlinux
EOF
)

# 5.3 Append labels if not present, set DEFAULT safe
sudo awk -v s="$SAFE_LABEL" -v t="$TEST_LABEL" '
  BEGIN{printed_safe=0; printed_test=0}
  {print}
  END{
    if (!printed_safe) print s;
    if (!printed_test) print t;
  }' /boot/extlinux/extlinux.conf | \
sudo tee /boot/extlinux/extlinux.conf.new >/dev/null

# Force DEFAULT=safe and TIMEOUT=30 at file top (idempotent)
sudo awk '
  BEGIN { setD=0; setT=0 }
  /^DEFAULT/ { print "DEFAULT safe"; setD=1; next }
  /^TIMEOUT/ { print "TIMEOUT 30"; setT=1; next }
  { print }
  END {
    if (!setT) print "TIMEOUT 30";
    if (!setD) print "DEFAULT safe";
  }' /boot/extlinux/extlinux.conf.new | sudo tee /boot/extlinux/extlinux.conf >/dev/null

sudo sync
```

> If your kernel lives only as `/boot/Image-${KREL}-custom`, swap the `LINUX` lines accordingly. You already proved `/boot/5.15.148-tegra` works; keep that pattern for simplicity.

---

# 6) First reboot: into **safe**

After reboot:

```bash
# Prove we hit our entry
cat /proc/cmdline | tr ' ' '\n' | egrep 'proof=|root=|devicetree='

# Kernel release must match what you installed
uname -r    # expect the KREL you backed up (e.g. 5.15.148-tegra)

# Modules match this kernel?
modinfo /lib/modules/$(uname -r)/updates/nvgpu.ko | egrep 'vermagic|filename' || true

# DTB sanity — it’s okay if the hash doesn’t match file exactly, but record it
sudo sha256sum /sys/firmware/fdt
sha256sum /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
sudo dmesg | grep -i -E 'EFI stub.*DTB|Using DTB' | tail -1 || true
```

**Expected:**

* `proof=safe-extlinux` present.
* Kernel release matches your archive.
* No GPU drivers active (blacklist effective).

---

# 7) Flip to **test**, set GPU perms, validate GPU

```bash
# Make test the default for next boot
sudo sed -i 's/^DEFAULT .*/DEFAULT test/' /boot/extlinux/extlinux.conf
sudo sync
sudo reboot
```

Back up, then:

```bash
# Prove test entry
cat /proc/cmdline | tr ' ' '\n' | grep proof=

# Basic GPU modules + device nodes
lsmod | egrep 'nvgpu|nvmap|nvsciipc|mc_utils|nvidia_drm' || true
ls -l /dev/dri/renderD* /dev/nvhost-as-gpu /dev/nvhost-ctrl-gpu 2>/dev/null || true

# Group membership for your user (so nvidia-smi works sans sudo)
sudo usermod -aG video,render "$USER"
# open a new shell or re-login, then:
id; groups

# Final check
nvidia-smi          # should work as your user (you already validated this path)
```

---

## Optional: pack as simple .deb (nice for fleets)

If you want a clickable install:

* Build a tiny **kernel-bundle** package with this layout:

```
kernel-bundle-${KREL}/
  DEBIAN/control
  boot/5.15.148-tegra
  boot/initrd-${KREL}
  boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
  lib/modules/${KREL}/... (entire tree)
  etc/modprobe.d/nvgpu-softdeps.conf
```

**`DEBIAN/control`**:

```
Package: jetson-kbundle
Version: 1:${KREL}-1
Section: kernel
Priority: optional
Architecture: arm64
Maintainer: you <you@example.com>
Description: Jetson kernel+modules+dtb bundle for ${KREL}
```

Then:

```bash
dpkg-deb --build kernel-bundle-${KREL}.  # creates kernel-bundle-${KREL}.deb
sudo dpkg -i kernel-bundle-${KREL}.deb
sudo depmod -a "${KREL}"
```

You’ll still add the **safe/test** extlinux labels once (or ship them from a postinst script).

---

## What this process *guarantees*

* **Kernel+modules vermagic stays aligned** (we copy the exact `/lib/modules/$KREL` from the good box and do `depmod -a` on target).
* **Stock kernel remains bootable** (parachute).
* **Safe/Test flows** let you test GPU only after confirming rootfs + boot config are good.
* **DTB** is under your control (we point FDT explicitly at the file you shipped; QSPI alignment prevents the older “firmware wins” behavior you ran into).

---

## Troubleshooting fast lanes

* **“No root-device: mount failed”** → your `root=PARTUUID=` probably doesn’t match target’s NVMe partition. Run `blkid` again and rewrite the APPEND lines.
* **Modules load but `nvidia-smi` says “Permission denied”** → add user to **video,render** and re-login (you already proved this fixes it).
* **Still booting wrong DTB** → verify QSPI is R36.4.4; check `dmesg | grep -i dtb`; recheck `FDT` line in extlinux. (It’s normal for the **hashes not to match** exactly if firmware adjusts the blob; your GPU still works.)

---

## Nice-to-haves you can automate later (Ansible ideas)

* Task: **Collect kernel bundle** (exact commands from §1) and publish to an artifact store.
* Task: **Install bundle** on host, run `depmod -a`, `update-initramfs`, copy DTB.
* Task: **extlinux templating**: drop in `safe`/`test` labels with `proof=` tokens; set `DEFAULT safe` and a configurable TIMEOUT.
* Task: **QSPI version check** preflight: run remote `nv_tegra_release` and block if mismatch.
* Task: **Postflight checks**:

  * verify `uname -r == KREL`,
  * `modinfo nvgpu vermagic` contains `KREL`,
  * users added to `video,render`,
  * `nvidia-smi` OK as non-root.
* Task: **Rollback**: restore `/boot/extlinux/extlinux.conf.backup.<ts>` and `DEFAULT` to stock label.

---

That’s the full, safe framework. If you want, I can turn the above into two scripts for you right now:

* `scripts/backup_kernel_bundle.sh` (source side)
* `scripts/install_kernel_bundle.sh` (target side; adds safe/test entries)

Just say the word and I’ll drop both, ready to paste.

