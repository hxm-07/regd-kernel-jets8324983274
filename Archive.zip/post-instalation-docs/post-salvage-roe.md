# POST-SALVAGE ROE (Return of Experience)

**Target**: Jetson Orin Nano Devkit Super (p3768‑0000 + p3767‑0005) · **JetPack**: 6.2.1 · **L4T**: R36.4.4 · **Kernel**: 5.15.x tegra · **Goal**: Stable GPU bring‑up, safe boot strategy, and readiness for k3s + Cilium + ML workloads.

> This document continues from the end of your `ANSIBLE-SALVAGE-OPERATION-COMPLETE-DOCUMENTATION.md` and folds in the lessons that also appear across `CONFTEST_REBUILD_GUIDE.md`, `FINAL-COMPLETE-JETSON-NVGPU-KERNEL-BUILD-GUIDE.md`, and `BUILD-ATTEMPT-2-LESSONS.md`. It captures what we actually did, why, what to automate next, and how to verify and run GPU + k3s/Cilium cleanly.

---

## 0) Framing analogy — two conductors, one score

The Jetson boots under two "conductors": **QSPI firmware (UEFI/BPMP)** and the **kernel + DTBs on disk**. If they carry different *scores* (versions), the orchestra desynchronizes: the GPU driver (nvgpu) expects VPR/IOMMU entries the firmware DTB doesn’t provide. Our outcome: align both conductors to the *same score* (QSPI flash to R36.4.4), then enforce a safe boot runway and user/device permissions so the performance is repeatable.

---

## 1) Executive summary (what changed since the Salvage doc)

* **Root cause confirmed**: Firmware/DTB pathing confusion masked a **QSPI firmware ≠ userspace** mismatch. Firmware kept feeding its own DTB, with VPR disabled → `nvgpu` probe panics.
* **Correct fix**: **QSPI‑only flash to R36.4.4** from host → firmware now matches userspace/kernel.
* **Safe/test boot strategy**: Dual entries in `extlinux.conf` with `proof=` tags to confirm the active path, and a *parachute* entry that blacklists GPU.
* **Permissions**: Adding user to `video, render` was the final step for **non‑root `nvidia-smi`**.
* **State now**: Stable stock JetPack R36.4.4 kernel + NVIDIA stack; ready for k3s + Cilium + GPU device plugin.

---

## 2) Timeline since the last build (step‑by‑step)

### Phase A — Stabilize boot + observability

1. **Create dual boot entries** in `/boot/extlinux/extlinux.conf`:

   * `safe`: stock kernel, GPU blacklisted (`modprobe.blacklist=nvgpu nomodeset`), `proof=safe-extlinux`.
   * `test`: stock kernel, GPU enabled, `proof=test-extlinux`.
2. **Root device**: Start with `root=/dev/nvme0n1p1` to avoid PARTUUID mistakes; later promote to `root=PARTUUID=...` after a known‑good boot.
3. **DTB file duplication**: Keep DTB in `/boot/dtb/…` and copy to `/boot/efi/dtb/…` (future‑proofing when EFI‑stub loading applies).
4. **Verification signals**: On boot, confirm `proof=` in `/proc/cmdline` and check `sha256sum /sys/firmware/fdt` vs intended DTB file (just report the diff).

### Phase B — Prove the real failure mode

5. **Hashes didn’t match; no EFI‑stub DTB lines** → firmware wasn’t loading the file DTB (and was sometimes choosing different internal DTBs per boot). This is the textbook “QSPI firmware not aligned to rootfs/driver” case.

### Phase C — Align firmware (QSPI‑only flash)

6. From a **host** with R36.4.4 BSP: run `l4t_initrd_flash.sh` with `p3768-0000+p3767-0005-qspi.conf` and target `qspi`. Rootfs on NVMe remains intact.
7. **Post‑flash verification**: Boot `safe`; compare live DTB hash vs stock DTB file; check for EFI stub DTB messages; ensure system still boots with our `proof=` tag.

### Phase D — Validate GPU stack and permissions

8. **Modules**: `nvgpu, nvmap, nvsciipc, mc_utils, nvidia_drm` present.
9. **Devices**: `/dev/nvhost-*` (group `video`) and `/dev/dri/renderD*` (group `render`).
10. **Permissions**: Add runtime user to `video,render`; verify **non‑root `nvidia-smi`** works.

---

## 3) `enable_oot` vs `enable_oot=false` and `apply_regdom_fixes=true` (behavior recap)

> Cross‑refer: `FINAL-COMPLETE-JETSON-NVGPU-KERNEL-BUILD-GUIDE.md`, `CONFTEST_REBUILD_GUIDE.md`.

### `enable_oot=false`

* Uses stock L4T in‑tree drivers only. Simpler build, **fewer moving parts**; ideal for baseline bring‑up and firmware sanity checks.

### `enable_oot=true`

* Builds NVIDIA’s **out‑of‑tree** providers (nvgpu OOT path, hwpm, nvethernetrm, etc.). Requires:

  * Correct **branches** (R36.4.4) for *all* nvidia repos.
  * **Conftest timing**: run conftest *after* kernel build and *before* reboot; then build OOT modules.
  * Config‑guard (watch `.config` size/keys post‑`modules_prepare`) to prevent silent symbol loss.

**Why this matters**: OOT gives finer control and updates, but introduces ABI/branch/conftest risk. We stabilized this path in the Salvage work, but for this bring‑up the stock path + firmware fix was sufficient.

### `apply_regdom_fixes=true`

* Toggle to apply the **regulatory domain** patch set (Wi‑Fi), injected at the *patch* phase pre‑build; it stays orthogonal to kernel/OOT timing.

---

## 4) Current validated state

* **Firmware**: QSPI aligned to R36.4.4 (QSPI‑only flash).
* **Boot**: `safe/test` entries with `proof=`; default is `safe`.
* **Kernel**: Stock 5.15.x‑tegra from JetPack 6.2.1.
* **GPU**: `nvidia-smi` OK as normal user (user ∈ `video, render`); CUDA 12.6 reported.
* **DTB**: Live DTB may differ from the file hash (firmware‑provided), but **is coherent** with R36.4.4 now—no GPU probe panics.

---

## 5) Ready for k3s + Cilium + ML workloads?

**Yes.** Preflights below ensure the surface is clean.

### Preflights

1. **BPF support**: `mount | grep bpf` should show `/sys/fs/bpf`. Install `bpftool` if missing; kernel 5.15.x is fine for Cilium.
2. **Container runtime**:

   * Install **nvidia-container-toolkit**.
   * Ensure containerd has an `io.containerd.runtimes.nvidia` stanza and the K8s runtime class (or k3s’ CRI config) selects it for GPU pods.
3. **NVIDIA device plugin** in the cluster so pods can request `nvidia.com/gpu`.
4. **Smoke test**: Deploy a `deviceQuery` CUDA pod; verify it runs and `nvidia-smi` works inside the pod as non‑root.

> If you want, we can add a minimal k3s + Cilium + GPU device‑plugin recipe block in a companion doc.

---

## 6) What to automate in Ansible next (we did these manually)

> This becomes a new role later (e.g. `roles/jetson_boot_safety/`), but here are the exact behaviors.

### 6.1 extlinux generator + proofs

* Idempotent task to emit **`safe`** and **`test`** entries with `proof=` flags.
* Start with `root=/dev/nvme0n1p1` (first boot), then promote to `root=PARTUUID=…` after success.
* Optionally place DTB in both `/boot/dtb/` and `/boot/efi/dtb/` and record both file hashes.

### 6.2 Firmware/DTB verifiers

* Compare `sha256sum /sys/firmware/fdt` vs file DTB; **report only**.
* Parse `dmesg` for `EFI stub` DTB messages; log whether firmware DTB or file DTB was used.
* Persist a JSON report in `/var/log/jetson/firmware_dtb_report.json` with timestamp.

### 6.3 GPU user/device readiness

* Add target user to `video, render`.
* Verify `/dev/dri/renderD*` and `/dev/nvhost-*` permissions; drop a udev rule if needed.
* Run `nvidia-smi -q` and persist to `/var/log/jetson/nvidia_smi_$(date).txt`.

### 6.4 OOT hardening hooks (when `enable_oot=true`)

* Branch sanity for all NVIDIA repos against R36.4.4.
* Run **conftest** immediately after kernel build and assert header presence.
* `.config` guard (size + key checksum) around `modules_prepare`.
* If `apply_regdom_fixes=true`, apply the regdom patch set in the patch role.

### 6.5 Host‑side helper (optional)

* Wrapper to perform **QSPI‑only** flash with the correct board config and safety prompts; verify `tegrarcm --uid` and `lsusb` first.

---

## 7) Reasoning highlights (concise, not verbose)

* **Don’t chase file paths** when DTB hashes keep changing between boots and there’s no EFI stub DTB message; this pattern points to **firmware/bootloader deciding DTB** (mismatch) → fix firmware first.
* **Safe/test entries** de‑risk experiments: always leave a parachute (`safe`), verify with `proof=`.
* **Permissions matter**: Seeing `nvidia-smi` work as root but fail as user is commonly just groups (`video, render`) and device node ACLs, not a kernel/DTB problem.
* **OOT timing pitfalls**: conftest and `.config` guards are must‑haves when enabling OOT again.

---

## 8) Quick runbooks

### 8.1 Post‑flash verification

```bash
# Prove we booted the intended entry
cat /proc/cmdline | tr ' ' '
' | grep proof=

# Hash the live DTB
sudo sha256sum /sys/firmware/fdt

# (Optional) Check EFI stub messages
sudo dmesg | grep -i 'EFI stub' | tail -3

# GPU status as user
nvidia-smi
```

### 8.2 Safe/test extlinux template (example)

```ini
TIMEOUT 30
DEFAULT safe

LABEL safe
  MENU LABEL Safe (GPU blacklisted)
  LINUX  /boot/Image
  INITRD /boot/initrd
  FDT    /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
  APPEND ${cbootargs} root=/dev/nvme0n1p1 rw rootwait modprobe.blacklist=nvgpu nomodeset proof=safe-extlinux

LABEL test
  MENU LABEL Test (GPU enabled)
  LINUX  /boot/Image
  INITRD /boot/initrd
  FDT    /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
  APPEND ${cbootargs} root=/dev/nvme0n1p1 rw rootwait loglevel=7 earlycon ignore_loglevel proof=test-extlinux
```

### 8.3 User/device permissions

```bash
sudo usermod -aG video,render <user>
# Re‑exec shell group or re‑login
newgrp video
nvidia-smi
```

---

## 9) Troubleshooting matrix (symptom → likely cause → action)

* **`nvidia-smi` OK as root, fails as user** → user not in `video/render` → add groups; check `/dev/dri/*` ACLs.
* **`modprobe nvgpu` reboots** → DTB lacks VPR/IOMMU; or firmware DTB mismatch → align QSPI to R36.4.4.
* **`/sys/firmware/fdt` hash keeps changing between boots** → firmware selecting DTB internally → QSPI mismatch; don’t chase file paths.
* **Boot says “No root device”** → wrong root spec; start with `/dev/nvme0n1p1`, switch to PARTUUID after a good boot.
* **OOT build errors (headers/abi)** → wrong branches or conftest timing → run branch sanity + conftest before reboot; restore `.config` if `modules_prepare` shrank it.

---

## 10) What we’ll do later (deferred but planned)

* Re‑enable **OOT path** with the hardened sequence (branch checks, conftest, config guard).
* Optional **host‑side QSPI role** wrapping `l4t_initrd_flash.sh` for single‑command reflash with prompts.
* Add a **k3s + Cilium + GPU** companion doc with ready‑to‑apply manifests (device plugin, fallback runtime class, CUDA smoke test pod).

---

### Appendix A — QSPI‑only flash (host)

```bash
cd Linux_for_Tegra/tools/kernel_flash/
sudo ./l4t_initrd_flash.sh --showlogs --flash-only \
  --board-config p3768-0000+p3767-0005-qspi.conf \
  p3768-0000+p3767-0005-qspi qspi
```

### Appendix B — Minimal k3s + Cilium preflight (outline)

* Install `nvidia-container-toolkit`; confirm `/etc/containerd/config.toml` includes an `nvidia` runtime.
* Install k3s (server or agent) → deploy **Cilium** with eBPF enabled (default on 5.15).
* Deploy NVIDIA **device plugin**; run CUDA “deviceQuery” pod to validate.

---

**Status**: ✅ Firmware aligned · ✅ Safe/test boot in place · ✅ GPU healthy (non‑root) · ✅ Ready for k3s + Cilium.

