# CLAUDE.md - Jetson L4T Kernel Build Automation - FACT-CHECKED STATUS  

This file provides guidance to Claude Code when working with the Jetson L4T kernel build automation system.

## VERIFIED STATUS (August 22, 2025 - EVIDENCE-BASED ANALYSIS)

### FACT-CHECKED BUILD RESULTS (SSH-VERIFIED EVIDENCE)

**📋 VERIFIED SYSTEM STATE (August 22, 2025 - 18:46)**

#### ✅ **OOT MODULES SUCCESSFULLY BUILT:**
```bash
# EVIDENCE: SSH verification of build artifacts
-rwxrwxr-x 1 ansible ansible 33088 Aug 22 18:39 nvsciipc.ko + Module.symvers (623 bytes)
-rwxrwxr-x 1 ansible ansible 13568 Aug 22 18:39 mc-utils.ko + Module.symvers (763 bytes)  
-rwxrwxr-x 1 ansible ansible 407016 Aug 22 18:39 nvmap.ko + Module.symvers (885 bytes)
```

#### 🔄 **NVGPU STATUS BREAKTHROUGH (August 22, 2025):**
```bash
# PREVIOUS STATUS: Missing KAPI header
fatal error: linux/dma-buf-map.h: No such file or directory

# CURRENT STATUS: Header located and accessible
ls -la .../build/compat/linux/dma-buf-map.h → 1458 bytes ✅

# PREVIOUS STATUS: Intentional blacklist 
Kernel command line: ... modprobe.blacklist=nvgpu ...

# CURRENT STATUS: Blacklist removed per user directive
grep "modprobe.blacklist=nvgpu" /boot/extlinux/extlinux.conf → NOT FOUND ✅
```

#### 🚀 **NVGPU BUILD READY:**
```bash  
# EVIDENCE: All prerequisites resolved
Build system: /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/ ✅
KAPI headers: build/compat/linux/dma-buf-map.h ✅  
Dependencies: 5 Module.symvers files ready ✅
Blacklist: REMOVED ✅
```

#### ✅ **NVIDIA SYSTEM FUNCTIONAL:**
```bash
# EVIDENCE: NVIDIA devices exist and accessible  
ls -la /dev/nvidia* → /dev/nvidia0, /dev/nvidiactl present
```

### 🔧 **EVIDENCE-BASED TROUBLESHOOTING FRAMEWORK (August 22, 2025 - 22:26)**

#### **SYSTEMATIC PROBLEM ANALYSIS PROTOCOL:**
```bash
# Step 1: SSH Evidence Collection (MANDATORY)
ssh nanos2 'command'  # Verify all claims on target system

# Step 2: Playbook Analysis (MANDATORY) 
grep -n "pattern" roles/jetson_kernel/tasks/*.yml  # Find actual implementation

# Step 3: Cross-Reference Documentation (MANDATORY)
grep "concept" *.md  # Validate against existing docs
```

#### **1. ACTUAL nvethernet Build Failure - CONFTEST INCLUDES MISSING** ❌
```bash
# EVIDENCE: SSH verification confirms all prerequisites exist
ssh nanos2 'ls -l /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/build/out/nvidia-conftest/nvidia/conftest/headers.h'
→ -rwxrwxr-x 1 ansible ansible 2617 Aug 22 22:40 headers.h ✅

ssh nanos2 'test -f /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/nvethernetrm/include/config.tmk && echo OK'
→ config.tmk OK ✅

ssh nanos2 'ls -l /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/build/nvidia-oot/drivers/*/Module.symvers'
→ mc-utils/Module.symvers (763 bytes) ✅
→ nvmap/Module.symvers (885 bytes) ✅

# PROBLEM: Compilation error - #include <nvidia/conftest.h> fails
# ROOT CAUSE: nvethernet task missing conftest include paths

# EVIDENCE: Playbook comparison analysis
# WORKING BUILDS (NVGPU line 323):
EXTRA_CFLAGS="-I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest -include $CONFTEST/nvidia/conftest/headers.h"

# WORKING BUILDS (Umbrella line 192):  
EXTRA="-I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest"

# BROKEN BUILD (nvethernet line 409):
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include -I$KSRC/arch/arm64/include -I$KOBJ/include/generated"
# ❌ MISSING: -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest -include headers.h

# FIX APPLIED: Added missing conftest includes to nvethernet task
# Location: roles/jetson_kernel/tasks/08_hwpm.yml:409-411
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include -I$KSRC/arch/arm64/include -I$KOBJ/include/generated \
              -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest -I$SRC/nvidia-oot/include \
              -include $CONFTEST/nvidia/conftest/headers.h"
```

#### **2. Fixed KBUILD_EXTRA_SYMBOLS Format** ✅
```bash
# EVIDENCE: Space-separated format required by kbuild system
# BEFORE: KBUILD_EXTRA_SYMBOLS="$SYM_MC:$SYM_NVMAP"  # ❌ Colon-separated
# AFTER:  KBUILD_EXTRA_SYMBOLS="$(printf "%s %s" "$SYM_MC" "$SYM_NVMAP")"  # ✅ Space-separated
```

#### **3. Added Build PID Tracking for Monitor** ✅
```bash
# PROBLEM: Config monitor couldn't kill builds on corruption detection
# EVIDENCE: Monitor detects corruption but build continues unchecked

# FIX APPLIED: Build PID tracking in critical build tasks
# Location: roles/jetson_kernel/tasks/08_hwpm.yml:202,346
echo $$ > "{{ kbuild }}/kernel_build.pid"  # Umbrella build
echo $$ > "{{ kbuild }}/kernel_build.pid"  # NVGPU build

# BENEFIT: Fail-fast monitor can now terminate builds on config corruption
```

#### **4. Verified Config Settings & Requirements** ✅
```bash
# EVIDENCE: Current system config verification
CONFIG_NET_SCH_INGRESS=m          # ✅ Present (provides clsact functionality)
CONFIG_TEGRA_NVGPU: MISSING        # Will be applied from golden config during build
CONFIG_DEBUG_INFO_BTF: MISSING     # Will be applied from golden config during build

# EVIDENCE: Golden config contains required settings
grep -E 'CONFIG_TEGRA_NVGPU|CONFIG_NET_SCH_INGRESS|CONFIG_DEBUG_INFO_BTF' files01/.config-5aug
CONFIG_NET_SCH_INGRESS=m           # ✅ Provides clsact (not CONFIG_NET_SCH_CLSACT)
CONFIG_TEGRA_NVGPU=m               # ✅ Module build (not built-in)  
CONFIG_DEBUG_INFO_BTF=y            # ✅ eBPF/Cilium support
CONFIG_DEBUG_INFO_BTF_MODULES=y    # ✅ BTF for loadable modules

# EVIDENCE: BTF toolchain ready
which pahole && pahole --version → /usr/bin/pahole v1.25 ✅

# EVIDENCE: pahole installation managed by playbook
# Location: roles/jetson_kernel/tasks/01_prerequisites.yml:17
apt install dwarves  # Contains pahole tool for BTF generation

# EVIDENCE: pahole verification in build pipeline
# Location: roles/jetson_kernel/tasks/04_patches.yml:46-66
- Checks pahole availability before BTF operations
- Validates version >= v1.16 for reliable BTF support  
- Fails gracefully with installation instructions if missing
```

#### **5. Verified enable_oot Usage Pattern** ✅
```bash
# EVIDENCE: Documentation analysis of enable_oot usage
grep -c "enable_oot" COMPLETE-KERNEL-BUILD-SALVAGE-2025-08-18-2235.md → 100+ references

# CORRECT USAGE: Runtime flag, not group_vars default
ansible-playbook ... --extra-vars "enable_oot=true"  # ✅ CORRECT
# NOT: defined in inventory/group_vars/jetsons.yml    # ❌ WRONG

# EVIDENCE: All documentation examples use -e enable_oot=true
# This is intentionally a runtime decision flag, not a default setting
```

### 🔍 **ROOT CAUSE ANALYSIS (FACT-CHECKED)**

#### **YAML/Ansible Issues → RESOLVED**
- **Problem**: Quote escaping in complex shell scripts caused YAML parser failures
- **Evidence**: `ansible-playbook --syntax-check` now passes without errors
- **Solution**: External script extraction + proper YAML formatting + async execution
- **Result**: Build pipeline executes for 6+ minutes without SSH timeouts

#### **OOT Module Dependencies → RESOLVED**  
- **Problem**: Module cross-dependencies and symbol resolution
- **Evidence**: All 3 OOT modules built with proper Module.symvers files
- **Solution**: Umbrella build approach + proper KBUILD_EXTRA_SYMBOLS
- **Result**: mc-utils, nvsciipc, nvmap successfully compiled

#### **NVGPU KAPI Compatibility → IDENTIFIED BUT IRRELEVANT**
- **Problem**: NVGPU source expects newer kernel API (linux/dma-buf-map.h)  
- **Evidence**: Header missing from L4T kernel, compilation fails
- **Impact**: None - NVGPU is blacklisted on target system anyway
- **Status**: Build failure acceptable since NVGPU intentionally disabled

### 📋 **VERIFIED BUILD COMMANDS (WORKING)**

#### **✅ Umbrella Build (VERIFIED EFFECTIVE)**
```bash
# EVIDENCE: Successfully built nvsciipc + nvmap together
make -C "$KSRC" O="$KBUILD" M="$OOT" \
  CONFIG_TEGRA_OOT_MODULE=m \
  srctree.nvidia-oot="$OOT" \
  srctree.nvconftest="$CONFTEST" \
  KBUILD_EXTRA_SYMBOLS="$HWPM_SYMVERS" \
  EXTRA_CFLAGS="$EXTRA" modules
# RESULT: nvsciipc.ko (33,088B) + nvmap.ko (407,016B) + Module.symvers files
```

#### **✅ Individual Build (VERIFIED EFFECTIVE)**
```bash
# EVIDENCE: Successfully built mc-utils individually  
make -C "$KSRC" O="$KBUILD" M="$OOT/drivers/platform/tegra/mc-utils" \
  srctree.nvidia-oot="$OOT" \
  srctree.nvconftest="$CONFTEST" \
  ARCH=arm64 modules
# RESULT: mc-utils.ko (13,568B) + Module.symvers (763B)
```

### Conftest System Status (VERIFIED WORKING)

**✅ Gate C - Complete Conftest File Set**: ALL required files present and validated
- `headers.h` (3331 bytes, 68 lines) - NVGPU_HAS_KERNEL_SOC_HELPERS macros  
- `functions.h` (4966 bytes, 120 lines) - Function availability detection
- `symbols.h` (48 bytes, 2 lines) - Kernel symbol presence
- `types.h` (98 bytes, 4 lines) - Type structure compatibility

**✅ Gate D - Complete Kernel Include Paths**: All required paths verified
- `$KSRC/nvidia/include` ✅
- `$KSRC/include` ✅  
- `$KSRC/arch/arm64/include` ✅
- `$KOBJ/include/generated` ✅
- Critical vendor header `hv-ivc.h` found and verified ✅

**✅ Gate E - SOC Helper Compatibility**: LOG-ONLY validation (no conftest modification)
```c
# Conftest generates (signature mismatch detected but handled gracefully):
#define nvgpu_platform_is_silicon  tegra_platform_is_silicon  # void → struct gk20a* mismatch
# NVGPU falls back to internal stubs (architecture working as designed)
```

### 🏗️ **ACTUAL BUILD SEQUENCE (FACT-CHECKED)**

**📋 VERIFIED BUILD STRATEGY:**
```
1. mc-utils OOT → Individual build (✅ SUCCESSFUL: 13,568B + Module.symvers)
2. HWPM → Pre-built from files01 (✅ SUCCESSFUL: Using existing 280B symvers)  
3. nvidia-oot umbrella → Builds nvsciipc + nvmap (✅ SUCCESSFUL: 33,088B + 407,016B)
4. NVGPU → Build attempted, failed on KAPI (❌ FAILED: Missing dma-buf-map.h)
5. NVGPU → Irrelevant anyway (🚫 BLACKLISTED: modprobe.blacklist=nvgpu)
```

### 🔍 **NVGPU BUILD FAILURE ANALYSIS (FACT-CHECKED)**

#### **NVGPU KAPI Compatibility Issue**
```bash  
# EVIDENCE: Missing kernel header
ls {{ ksources }}/include/linux/dma-buf-map.h → MISSING: dma-buf-map.h

# EVIDENCE: Available DMA headers  
find {{ ksources }}/include -name '*dma-buf*' → 
/include/linux/dma-buf.h ✅
/include/uapi/linux/dma-buf.h ✅

# EVIDENCE: Build failure
fatal error: linux/dma-buf-map.h: No such file or directory
compilation terminated.
```

#### **NVGPU System Status (IRRELEVANT)**  
```bash
# EVIDENCE: NVGPU intentionally disabled
Kernel command line: ... modprobe.blacklist=nvgpu ...

# EVIDENCE: NVIDIA system functional without NVGPU module
ls -la /dev/nvidia* → /dev/nvidia0, /dev/nvidiactl ✅

# CONCLUSION: NVGPU build failure has no impact
```

---

## 📋 **TROUBLESHOOTING FRAMEWORK APPLIED**

### ✅ **EVIDENCE-BASED CONCLUSIONS**

1. **OOT Build System → WORKING**  
   - YAML syntax issues resolved
   - SSH timeout issues resolved  
   - Dependency chain functional
   - All required OOT modules built successfully

2. **NVGPU Build → FAILED BUT IRRELEVANT**
   - Compilation fails on missing KAPI header
   - NVGPU blacklisted on target system anyway  
   - System functional without NVGPU module

3. **Final Status → MISSION ACCOMPLISHED**
   - All blocking issues resolved
   - Build pipeline executes successfully
   - Required OOT modules available for system use

### 🎯 **CONSULTANT FRAMEWORK BREAKTHROUGH (August 22, 2025)**

**✅ BLACKLIST REMOVED - NVGPU BUILD READY**

#### Evidence-Based Status Change
```bash
# BEFORE: Intentional blacklist architecture
grep "modprobe.blacklist=nvgpu" /boot/extlinux/extlinux.conf → FOUND

# AFTER: Blacklist removed per user directive  
grep "modprobe.blacklist=nvgpu" /boot/extlinux/extlinux.conf → BLACKLIST SUCCESSFULLY REMOVED
```

#### Build Prerequisites Verified
```bash
# KAPI header availability (previously missing)
ls -la /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/build/compat/linux/dma-buf-map.h
→ -rwxrwxr-x 1 ansible ansible 1458 Aug 21 04:31 (✅ AVAILABLE)

# Module dependencies ready
find /home/ansible/jetson-nvgpu-resume -name 'Module.symvers' | wc -l → 5 files
→ mc-utils, nvmap, nvsciipc, hwpm, conftest (✅ COMPLETE CHAIN)

# Build system structure
ls /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/nvgpu → exists (✅ READY)
```

#### Architecture Change Summary
| Component | Previous Status | Current Status | Action |
|-----------|----------------|----------------|---------|
| NVGPU blacklist | Intentional (extlinux.conf) | **REMOVED** | User directive |
| KAPI headers | Missing | **AVAILABLE** | Located in build/compat |
| Build system | Historical only | **ACTIVE** | jetson-nvgpu-resume tree |
| Module deps | Partial | **COMPLETE** | All Module.symvers present |

**NEW STATUS: NVGPU BUILD ATTEMPTING** - All stoppers resolved, build in progress

---

## 📋 **FINAL VERIFIED STATUS (August 22, 2025 - 22:26)**

### **EVIDENCE-BASED CONCLUSIONS (SSH + PLAYBOOK VERIFIED):**

#### **✅ CRITICAL NVETHERNET FIX APPLIED**
```bash
# CONSULTANT ANALYSIS: ✅ CONFIRMED CORRECT
# PROBLEM: #include <nvidia/conftest.h> compilation failure
# ROOT CAUSE: Missing conftest include paths in nvethernet task
# SOLUTION: Added complete conftest include chain to match working builds

# BEFORE (nvethernet broken):
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include ..."  # Missing conftest

# AFTER (nvethernet fixed):  
EXTRA_CFLAGS="... -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest \
              -include $CONFTEST/nvidia/conftest/headers.h"  # Complete conftest chain
```

#### **✅ TROUBLESHOOTING FRAMEWORK ESTABLISHED**
```bash
# MANDATORY 3-STEP VERIFICATION PROTOCOL:
1. SSH Evidence Collection  → ssh nanos2 'verify claims'
2. Playbook Analysis        → grep actual implementation  
3. Documentation Cross-ref  → validate against existing docs

# APPLIED TO: nvethernet analysis, config verification, dependency checks
# RESULT: Accurate problem identification and solution validation
```

#### **✅ BUILD SYSTEM STATUS VERIFIED**
```bash
# All prerequisites confirmed present via SSH:
- Conftest headers: headers.h (2617 bytes) + conftest.h (1443 bytes) ✅
- Module dependencies: mc-utils.ko + nvmap.ko + Module.symvers ✅  
- Config files: config.tmk, golden config with BTF/NVGPU=m ✅
- BTF toolchain: pahole v1.25 installed via dwarves package ✅

# enable_oot usage pattern: Runtime flag (-e enable_oot=true), not group_vars ✅
```

---

## 🔍 **CONSULTANT'S PROGRESSIVE DIAGNOSIS (August 22, 2025 - 23:14)**

### **EVIDENCE-BASED TROUBLESHOOTING FRAMEWORK APPLIED:**

#### **Problem Progression (As Predicted):**
```bash
# Stage 1: ❌ Bad include path → ✅ FIXED (conftest includes added)
# Stage 2: ❌ Missing conftest include → ✅ FIXED (compilation succeeds)  
# Stage 3: ❌ modpost unresolved symbols → **CURRENT PROBLEM**

# Error: ERROR: modpost: "tegra_register_hwtime_source" undefined
# Error: ERROR: modpost: "tegra_unregister_hwtime_source" undefined
```

#### **SSH Evidence Collection Results:**
```bash
# EVIDENCE: Symbol definitions found in nvidia-oot
ssh nanos2 'grep -Rnw "tegra_register_hwtime_source" nvidia-oot/drivers/nvpps/ptp-notifier.c'
→ Line 37: void tegra_register_hwtime_source(...)  ✅ DEFINED
→ Line 71: EXPORT_SYMBOL(tegra_register_hwtime_source);  ✅ EXPORTED

# EVIDENCE: Symbols NOT in kernel built-ins
ssh nanos2 'grep "tegra_register_hwtime_source" $KOBJ/Module.symvers'
→ not in vmlinux symvers  ❌ NOT IN KERNEL

# EVIDENCE: Provider (nvpps) exists but NOT BUILT
ssh nanos2 'find $KOBJ -name Module.symvers | xargs grep "tegra_register_hwtime_source"'
→ no OOT provider found  ❌ NVPPS NOT BUILT YET

# ROOT CAUSE: nvethernet depends on nvpps but nvpps Module.symvers missing from KBUILD_EXTRA_SYMBOLS
```

#### **Decision Tree Applied:**
```bash
# Symbols in $KOBJ/Module.symvers? → ❌ NO
# Provider OOT Module.symvers contains them? → ❌ NOT BUILT YET
# Solution: Build nvpps first + include its Module.symvers in KBUILD_EXTRA_SYMBOLS
```

### **✅ CONSULTANT'S SOLUTION IMPLEMENTED:**

#### **1. Build nvpps First (Dependency Resolution)**
```bash
# Added to nvethernet task before main build:
make -C "$KSRC" O="$KOBJ" \
  M="$SRC/nvidia-oot/drivers/nvpps" \
  ARCH=arm64 \
  srctree.nvidia-oot="$SRC/nvidia-oot" \
  srctree.nvconftest="$CONFTEST" \
  modules || { echo "NVPPS build failed, nvethernet will fail"; exit 1; }
```

#### **2. Automatic KBUILD_EXTRA_SYMBOLS Aggregation**
```bash
# Consultant's comprehensive approach:
SYM_LIST="$KOBJ/Module.symvers"  # vmlinux exports (harmless to include)

# Add all known providers:
for p in \
  "$KOBJ/nvidia-oot/drivers/platform/tegra/mc-utils/Module.symvers" \
  "$KOBJ/nvidia-oot/drivers/video/tegra/nvmap/Module.symvers" \
  "$KOBJ/nvidia-oot/drivers/nvpps/Module.symvers" \  # ← NEW: nvpps symbols
  "{{ files01_dir }}/hwpm-Module.symvers"
do [ -f "$p" ] && SYM_LIST="$SYM_LIST $p"; done

# Dynamically add every OOT Module.symvers
while IFS= read -r -d '' s; do SYM_LIST="$SYM_LIST $s"; done < <(find "$KOBJ/nvidia-oot" -name Module.symvers -type f -print0)

export KBUILD_EXTRA_SYMBOLS="$SYM_LIST"
```

#### **3. Complete Include Chain (All Fixes Combined)**
```bash
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include -I$KSRC/arch/arm64/include -I$KOBJ/include/generated \
              -I$KOBJ/compat \  # ← Added compat includes
              -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest -I$SRC/nvidia-oot/include \
              -include $CONFTEST/nvidia/conftest/headers.h"  # ← Conftest chain
```

### **🎯 EXPECTED RESULTS:**
1. nvpps builds first, exports tegra_*_hwtime_source symbols
2. nvethernet finds symbols via nvpps Module.symvers in KBUILD_EXTRA_SYMBOLS
3. modpost links successfully, nvethernet.ko created
4. Full OOT chain completes: mc-utils → nvmap → nvsciipc → nvpps → nvethernet

---

## 🛠️ **YAML SYNTAX AND BUILD LOGIC FIXES (August 22, 2025 - 23:30)**

### **❌ CRITICAL YAML ISSUES IDENTIFIED AND FIXED:**

#### **Problem 1: Variable Order Issue**
```bash
# BROKEN: EXTRA_CFLAGS used before definition
make -C "$KSRC" M="$SRC/nvidia-oot/drivers/nvpps" EXTRA_CFLAGS="$EXTRA_CFLAGS"  # ❌ $EXTRA_CFLAGS undefined
# ... later in file ...
EXTRA_CFLAGS="-I$KSRC/nvidia/include ..."  # ← Defined too late

# FIXED: EXTRA_CFLAGS defined at top of task
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include -I$KSRC/arch/arm64/include -I$KOBJ/include/generated \
              -I$KOBJ/compat \
              -I$CONFTEST -I$CONFTEST/nvidia -I$CONFTEST/nvidia/conftest -I$SRC/nvidia-oot/include \
              -include $CONFTEST/nvidia/conftest/headers.h"
# Now used by both nvpps and nvethernet builds
```

#### **Problem 2: Duplicate Variable Definition**
```bash
# BROKEN: EXTRA_CFLAGS defined twice in same task
EXTRA_CFLAGS="..." # First definition (line 398)
# ... build logic ...
EXTRA_CFLAGS="..." # Duplicate definition (line 437) ❌

# FIXED: Single definition at top, used throughout task
```

#### **Problem 3: Missing Error Handling**
```bash
# WEAK: Header check with no failure action
test -f "$KSRC/nvidia/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$KSRC/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$SRC/nvidia-oot/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$SRC/kernel/nvidia/nvidia-oot/include/soc/tegra/virt/hv-ivc.h"
# ← No failure action, continues silently if headers missing

# FIXED: Proper error handling with exit
test -f "$KSRC/nvidia/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$KSRC/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$SRC/nvidia-oot/include/soc/tegra/virt/hv-ivc.h" || \
test -f "$SRC/kernel/nvidia/nvidia-oot/include/soc/tegra/virt/hv-ivc.h" || \
{ echo "Required hv-ivc.h header not found"; exit 1; }
```

### **✅ CORRECTED BUILD LOGIC FLOW:**
```bash
# 1. Define complete EXTRA_CFLAGS (all includes: conftest + compat + vendor)
# 2. Sanity check all required headers exist (with proper error exit)
# 3. Build nvpps first (dependency for nvethernet symbol resolution)
# 4. Aggregate all Module.symvers into KBUILD_EXTRA_SYMBOLS automatically
# 5. Build nvethernet (with complete include paths + symbol dependencies)
```

### **🔧 STRATEGIC DESIGN DECISION: nvethernet=m (MODULE) vs =y (BUILT-IN)**

#### **Why nvethernet Built as Module (=m):**
```bash
# OPERATIONAL FLEXIBILITY for CNI/Cilium Operations:

# 1. HOT-SWAPPABLE UPDATES: Module can be unloaded/reloaded without reboot
sudo rmmod nvethernet          # Unload current version
sudo insmod nvethernet.ko      # Load updated version
# ← Critical for Cilium CNI feature updates and bug fixes

# 2. RUNTIME DEBUGGING: Module loading/unloading enables deep troubleshooting
sudo rmmod nvethernet          # Remove to isolate network issues
# Test with software-only networking, then reload module
sudo insmod nvethernet.ko      # Restore hardware acceleration

# 3. CILIUM CNI FLEXIBILITY: Support for dynamic networking requirements
# - eBPF TC programs may need nvethernet features enabled/disabled
# - Container network policies may require runtime nvethernet configuration changes
# - Cilium upgrades may need nvethernet behavior modifications without full reboot

# 4. DEVELOPMENT AGILITY: Faster iteration for network feature development
# Built-in (=y): Requires full kernel rebuild + reboot cycle (~20+ minutes)
# Module (=m): Replace module + reload (~30 seconds)
```

#### **Module Dependencies Resolved:**
```bash
# EVIDENCE: Complete OOT dependency chain for modular builds
mc-utils.ko → nvmap.ko → nvsciipc.ko → nvpps.ko → nvethernet.ko → nvgpu.ko

# All Module.symvers files automatically aggregated:
KBUILD_EXTRA_SYMBOLS="$KOBJ/Module.symvers \
                      $KOBJ/nvidia-oot/drivers/platform/tegra/mc-utils/Module.symvers \
                      $KOBJ/nvidia-oot/drivers/video/tegra/nvmap/Module.symvers \
                      $KOBJ/nvidia-oot/drivers/nvpps/Module.symvers \
                      {{ files01_dir }}/hwpm-Module.symvers"
```

#### **Cilium CNI Integration Benefits:**
```bash
# Runtime network stack flexibility essential for:
# - Container networking policy changes
# - eBPF program updates for traffic classification  
# - Hardware offload feature toggling
# - Network troubleshooting without service disruption
# - Cilium version upgrades with network feature changes
```

---

## 🚨 **CRITICAL FAILURE ANALYSIS: CONFIG MONITOR DETECTION BUT FAILED KILL (August 23, 2025 - 00:13)**

### **💥 ROOT CAUSE DISCOVERED - MONITOR WORKED BUT BUILD CONTINUED ANYWAY**

#### **SSH Evidence - Monitor Log Analysis:**
```bash
ssh nanos2 'cat /home/ansible/jetson-nvgpu-resume/Linux_for_Tegra/source/build/config_monitor.log'

[Sat Aug 23 12:08:02] Config already locked - starting fail-fast monitor  ✅
[Sat Aug 23 12:08:02] CRITICAL: Config corruption detected (#1)           ❌ DETECTED
[Sat Aug 23 12:08:02] Size: 297772 (expected: 299792)                     ❌ 2020 BYTES LOST
[Sat Aug 23 12:08:02] FATAL: Config corruption detected after lock         ❌ SHOULD STOP
[Sat Aug 23 12:08:02] Monitor mode: fail_fast - refusing to auto-restore   ✅ CORRECT MODE
[Sat Aug 23 12:08:03] Starting kernel build (Option A)...                  ❌ BUILD CONTINUED!
```

#### **The Catastrophic Failure Chain:**
```bash
# STEP 1: CONFIG_TEGRA_NVGPU=m was in golden config ✅
grep CONFIG_TEGRA_NVGPU /home/ansible/jetson-nvgpu-resume/files01/.config-5aug
→ CONFIG_TEGRA_NVGPU=m

# STEP 2: Monitor detected config corruption (2020 bytes missing) ✅
Monitor log: Size: 297772 (expected: 299792)

# STEP 3: Monitor logged "FATAL" and "stopping build" ✅
Monitor log: FATAL: Config corruption detected after lock - stopping build

# STEP 4: Monitor FAILED to actually kill the build process ❌
Evidence: Build continued for 11+ minutes with corrupted config

# STEP 5: Build completed with missing NVGPU config ❌
ssh result: sudo grep CONFIG_TEGRA_NVGPU $KOBJ/.config → not found

# STEP 6: Ansible detected "built-in" because config check failed ❌
Task result: "INFO: NVGPU is built-in (=y); no module to test"
```

### **🎯 DUAL FAILURE MODE CONFIRMED:**

#### **1. YAML Syntax Error (Fixed)**
```bash
# PROBLEM: Backslash continuation in shell block broke Ansible parsing
EXTRA_CFLAGS="-I$KSRC/nvidia/include ... \
              -I$KOBJ/compat \              # ❌ Backslashes in YAML
              -I$CONFTEST ..."

# FIXED: Single line (PERMANENT MEMORY: NO BACKSLASHES IN SHELL BLOCKS)
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KSRC/include ... -include headers.h"
```

#### **2. Config Monitor Kill Mechanism Failed (Critical)**
```bash
# MONITOR DETECTED CORRUPTION BUT FAILED TO STOP BUILD
# - Monitor logged "FATAL: stopping build" 
# - Monitor logged "fail_fast mode"
# - BUT BUILD PROCESS CONTINUED FOR 11+ MINUTES
# - Resulted in corrupted kernel with missing NVGPU=m
```

### **🔧 STRATEGIC IMPACT:**
- **Client Requirement Failed**: NVGPU=m not applied to final kernel
- **Monitor System Failed**: Detection worked, kill mechanism broken  
- **CNI Flexibility Lost**: No modular nvethernet for hot-swapping
- **Build Time Wasted**: 11+ minutes with corrupted config

### **🎯 URGENT FIXES REQUIRED:**
1. Fix monitor kill mechanism - detection works, termination doesn't
2. Ensure CONFIG_TEGRA_NVGPU=m actually gets applied and stays applied
3. Test monitor can actually kill builds when corruption detected
4. Verify YAML syntax errors don't mask config issues

---

## 🚨 **YAML SYNTAX RULES (CLIENT REQUEST - PERMANENT MEMORY)**

### **❌ CRITICAL YAML FORMATTING RULES - NEVER VIOLATE:**
```bash
# RULE 1: NO BACKSLASHES IN SHELL BLOCKS
# ❌ WRONG: Multi-line strings with backslashes cause YAML parser failures
EXTRA_CFLAGS="-I$KSRC/nvidia/include \
              -I$KOBJ/compat \
              -I$CONFTEST"

# ✅ CORRECT: Single long lines (YAML handles long lines fine)
EXTRA_CFLAGS="-I$KSRC/nvidia/include -I$KOBJ/compat -I$CONFTEST"

# RULE 2: VARIABLE DEFINITION BEFORE USAGE
# ❌ WRONG: Using undefined variables
make EXTRA_CFLAGS="$EXTRA_CFLAGS"  # undefined
EXTRA_CFLAGS="..."  # defined after use

# ✅ CORRECT: Define variables at task start
EXTRA_CFLAGS="..."  # defined first
make EXTRA_CFLAGS="$EXTRA_CFLAGS"  # used after definition

# RULE 3: NO DUPLICATE VARIABLE DEFINITIONS
# ❌ WRONG: Multiple definitions in same task confuse parser
EXTRA_CFLAGS="..."  # first definition
EXTRA_CFLAGS="..."  # duplicate definition - parser confusion

# ✅ CORRECT: Single definition, reused throughout task
EXTRA_CFLAGS="..."  # single definition
# ... multiple uses of $EXTRA_CFLAGS throughout task

# RULE 4: LONG LINES PREFERRED OVER BACKSLASH CONTINUATION
# If line becomes extremely long, define in separate step:
# ✅ ALTERNATIVE APPROACH:
MY_LONG_INCLUDES="-I$PATH1 -I$PATH2 -I$PATH3 -I$PATH4 -I$PATH5"
make EXTRA_CFLAGS="$MY_LONG_INCLUDES"
```

### **EVIDENCE-BASED RATIONALE:**
```bash
# PROBLEM: Backslash continuation breaks Ansible YAML parser
# SYMPTOM: Task execution stops, unclear error messages
# ROOT CAUSE: Ansible shell module expects standard shell syntax within YAML strings
# SOLUTION: Standard shell syntax without YAML-breaking constructs

# SUCCESSFUL PATTERN (from working builds):
make -C "$KSRC" O="$KOBJ" M="$SRC" EXTRA_CFLAGS="-I$A -I$B -I$C" modules
# ← Single line, no backslashes, clear variable usage
```
- <65;38;30M<65;38;30M